import fs from 'node:fs';
import path from 'node:path';

interface FirebaseAppletConfig {
  projectId: string;
  apiKey: string;
  firestoreDatabaseId: string;
}

const GATEWAY_KEY = 'e80fd54f326d29eb49b6458ccc5a5fca27c8997e1bf76191';

let cachedConfig: FirebaseAppletConfig | null = null;

function getConfig(): FirebaseAppletConfig {
  if (cachedConfig) return cachedConfig;
  const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
  const raw = fs.readFileSync(configPath, 'utf8');
  const parsed = JSON.parse(raw) as FirebaseAppletConfig;
  if (!parsed.projectId || !parsed.apiKey || !parsed.firestoreDatabaseId) {
    throw new Error('firebase-applet-config.json to\'liq emas');
  }
  cachedConfig = parsed;
  return cachedConfig;
}

function getDocumentsRoot(): string {
  const cfg = getConfig();
  return `projects/${cfg.projectId}/databases/${cfg.firestoreDatabaseId}/documents`;
}

function getBaseUrl(): string {
  return `https://firestore.googleapis.com/v1/${getDocumentsRoot()}`;
}

function getGatewayDocPath(collection: string, docId: string): string {
  return `${getDocumentsRoot()}/backends/${GATEWAY_KEY}/${collection}/${docId}`;
}

type FirestoreValue =
  | { stringValue: string }
  | { integerValue: string }
  | { doubleValue: number }
  | { booleanValue: boolean }
  | { nullValue: null }
  | { arrayValue: { values?: FirestoreValue[] } }
  | { mapValue: { fields?: Record<string, FirestoreValue> } };

function toFirestoreValue(val: unknown): FirestoreValue {
  if (val === null || val === undefined) {
    return { nullValue: null };
  }
  if (typeof val === 'string') {
    return { stringValue: val };
  }
  if (typeof val === 'boolean') {
    return { booleanValue: val };
  }
  if (typeof val === 'number') {
    if (!Number.isFinite(val)) return { doubleValue: 0 };
    if (Number.isInteger(val)) {
      return { integerValue: String(val) };
    }
    return { doubleValue: val };
  }
  if (Array.isArray(val)) {
    return {
      arrayValue: {
        values: val.filter((v) => v !== undefined).map((v) => toFirestoreValue(v)),
      },
    };
  }
  if (typeof val === 'object') {
    return {
      mapValue: {
        fields: toFirestoreFields(val as Record<string, unknown>),
      },
    };
  }
  return { stringValue: String(val) };
}

function toFirestoreFields(obj: Record<string, unknown>): Record<string, FirestoreValue> {
  const fields: Record<string, FirestoreValue> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v === undefined || v === null) continue;
    fields[k] = toFirestoreValue(v);
  }
  return fields;
}

function fromFirestoreValue(val: FirestoreValue | undefined): unknown {
  if (!val) return undefined;
  if ('stringValue' in val) return val.stringValue;
  if ('booleanValue' in val) return val.booleanValue;
  if ('integerValue' in val) return Number(val.integerValue);
  if ('doubleValue' in val) return Number(val.doubleValue);
  if ('nullValue' in val) return null;
  if ('arrayValue' in val) {
    return (val.arrayValue.values || []).map((v) => fromFirestoreValue(v));
  }
  if ('mapValue' in val) {
    return fromFirestoreFields(val.mapValue.fields || {});
  }
  return undefined;
}

function fromFirestoreFields<T = Record<string, unknown>>(
  fields: Record<string, FirestoreValue> | undefined
): T {
  const out: Record<string, unknown> = {};
  if (!fields) return out as T;
  for (const [k, v] of Object.entries(fields)) {
    out[k] = fromFirestoreValue(v);
  }
  return out as T;
}

async function fetchWithRetry(url: string, init?: RequestInit, attempt = 0): Promise<Response> {
  const res = await fetch(url, init);
  if ((res.status === 429 || res.status === 503) && attempt < 3) {
    await new Promise((r) => setTimeout(r, 250 * Math.pow(2, attempt)));
    return fetchWithRetry(url, init, attempt + 1);
  }
  return res;
}

export async function validateFirestoreConnection(): Promise<void> {
  const cfg = getConfig();
  const url = `${getBaseUrl()}/backends/${GATEWAY_KEY}/config/meta?key=${encodeURIComponent(cfg.apiKey)}`;
  const res = await fetchWithRetry(url);
  if (!res.ok && res.status !== 404) {
    const body = await res.text();
    throw new Error(`Firestore ulanish xatoligi (${res.status}): ${body}`);
  }
}

export async function getFirestoreDoc<T = Record<string, unknown>>(
  collection: string,
  docId: string
): Promise<T | null> {
  const cfg = getConfig();
  const url = `${getBaseUrl()}/backends/${GATEWAY_KEY}/${collection}/${encodeURIComponent(docId)}?key=${encodeURIComponent(cfg.apiKey)}`;
  const res = await fetchWithRetry(url);
  if (res.status === 404) return null;
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Firestore o'qish xatoligi (${collection}/${docId}): ${res.status} ${body}`);
  }
  const doc = (await res.json()) as { fields?: Record<string, FirestoreValue> };
  return fromFirestoreFields<T>(doc.fields);
}

export async function setFirestoreDoc(
  collection: string,
  docId: string,
  data: Record<string, unknown>
): Promise<void> {
  const cfg = getConfig();
  const url = `${getBaseUrl()}/backends/${GATEWAY_KEY}/${collection}/${encodeURIComponent(docId)}?key=${encodeURIComponent(cfg.apiKey)}`;
  const res = await fetchWithRetry(url, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ fields: toFirestoreFields(data) }),
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Firestore yozish xatoligi (${collection}/${docId}): ${res.status} ${body}`);
  }
}

export async function deleteFirestoreDoc(collection: string, docId: string): Promise<void> {
  const cfg = getConfig();
  const url = `${getBaseUrl()}/backends/${GATEWAY_KEY}/${collection}/${encodeURIComponent(docId)}?key=${encodeURIComponent(cfg.apiKey)}`;
  const res = await fetchWithRetry(url, { method: 'DELETE' });
  if (!res.ok && res.status !== 404) {
    const body = await res.text();
    throw new Error(`Firestore o'chirish xatoligi (${collection}/${docId}): ${res.status} ${body}`);
  }
}

export async function listFirestoreCollection<T = Record<string, unknown>>(
  collection: string
): Promise<T[]> {
  const cfg = getConfig();
  const items: T[] = [];
  let pageToken = '';

  do {
    const params = new URLSearchParams({
      key: cfg.apiKey,
      pageSize: '300',
    });
    if (pageToken) {
      params.set('pageToken', pageToken);
    }
    const url = `${getBaseUrl()}/backends/${GATEWAY_KEY}/${collection}?${params.toString()}`;
    const res = await fetchWithRetry(url);
    if (!res.ok) {
      const body = await res.text();
      throw new Error(`Firestore ro'yxat olish xatoligi (${collection}): ${res.status} ${body}`);
    }
    const json = (await res.json()) as {
      documents?: Array<{ fields?: Record<string, FirestoreValue> }>;
      nextPageToken?: string;
    };
    if (Array.isArray(json.documents)) {
      for (const doc of json.documents) {
        items.push(fromFirestoreFields<T>(doc.fields));
      }
    }
    pageToken = json.nextPageToken || '';
  } while (pageToken);

  return items;
}

export type BatchWriteOp =
  | { type: 'set'; collection: string; id: string; data: Record<string, unknown> }
  | { type: 'delete'; collection: string; id: string };

export async function commitFirestoreBatch(ops: BatchWriteOp[]): Promise<void> {
  if (ops.length === 0) return;
  const cfg = getConfig();
  const url = `https://firestore.googleapis.com/v1/${getDocumentsRoot()}:commit?key=${encodeURIComponent(cfg.apiKey)}`;

  const CHUNK_SIZE = 400;
  for (let i = 0; i < ops.length; i += CHUNK_SIZE) {
    const slice = ops.slice(i, i + CHUNK_SIZE);
    const writes = slice.map((op) => {
      const name = getGatewayDocPath(op.collection, op.id);
      if (op.type === 'delete') {
        return { delete: name };
      }
      return {
        update: {
          name,
          fields: toFirestoreFields(op.data),
        },
      };
    });

    const res = await fetchWithRetry(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ writes }),
    });
    if (!res.ok) {
      const body = await res.text();
      throw new Error(`Firestore batch yozish xatoligi: ${res.status} ${body}`);
    }
  }
}
