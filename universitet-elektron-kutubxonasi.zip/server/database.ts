import crypto from 'node:crypto';
import type {
  ActivityLog,
  AdminAccount,
  Book,
  BookCategory,
  Faculty,
  Librarian,
  Loan,
  Reservation,
  SiteSettings,
  Specialty,
  Student,
  UserRole,
} from '../src/types/library.ts';
import {
  DEFAULT_SITE_SETTINGS,
  INITIAL_ADMIN,
} from '../src/data/initialData.ts';
import {
  calculateDaysOverdue,
  calculateFine,
  calculateLoanStatus,
  mergeSiteSettings,
} from '../src/utils/libraryRules.ts';
import { hashPassword, setSessionSecret } from './auth.ts';
import {
  type BatchWriteOp,
  commitFirestoreBatch,
  getFirestoreDoc,
  listFirestoreCollection,
  validateFirestoreConnection,
} from './firestoreClient.ts';

export interface StoredFileMeta {
  id: string;
  fileName: string;
  mimeType: string;
  size: number;
  chunkCount?: number;
  createdAt: string;
}

export interface LibraryDatabaseState {
  faculties: Faculty[];
  specialties: Specialty[];
  categories: BookCategory[];
  books: Book[];
  students: Student[];
  librarians: Librarian[];
  adminAccount: AdminAccount;
  loans: Loan[];
  reservations: Reservation[];
  logs: ActivityLog[];
  siteSettings: SiteSettings;
}

interface MetaPayload {
  seeded: boolean;
  revision: number;
  sessionSecret: string;
}

interface ConfigDoc {
  id: string;
  payload: string;
  updatedAt: string;
}

interface FileChunkDoc {
  fileId: string;
  chunkIndex: number;
  data: string;
}

export const DATA_DIR = '.unilib-data';

const META_CHECK_TTL_MS = 2500;
const RAW_CHUNK_BYTES = 420 * 1024; // ~560KB base64 per Firestore chunk document
const MAX_FILE_CACHE = 60;

let cachedState: LibraryDatabaseState | null = null;
let cachedRevision = 0;
let lastMetaCheckAt = 0;
let initPromise: Promise<void> | null = null;
let writeQueue: Promise<unknown> = Promise.resolve();
let logSeq = 0;

const fileCache = new Map<string, { meta: StoredFileMeta; buffer: Buffer }>();

function cacheFile(id: string, value: { meta: StoredFileMeta; buffer: Buffer }) {
  if (fileCache.has(id)) {
    fileCache.delete(id);
  } else if (fileCache.size >= MAX_FILE_CACHE) {
    const oldestKey = fileCache.keys().next().value;
    if (oldestKey) fileCache.delete(oldestKey);
  }
  fileCache.set(id, value);
}

function cloneState(state: LibraryDatabaseState): LibraryDatabaseState {
  return JSON.parse(JSON.stringify(state)) as LibraryDatabaseState;
}

function refreshLoanStatuses(loans: Loan[]): Loan[] {
  return loans.map((loan) => {
    if (loan.status === 'returned') return loan;
    const status = calculateLoanStatus(loan.dueDate, loan.returnDate);
    const days = calculateDaysOverdue(loan.dueDate);
    const fineAmount = calculateFine(days);
    return { ...loan, status, fineAmount };
  });
}

function normalizeState(raw: LibraryDatabaseState): LibraryDatabaseState {
  return {
    faculties: raw.faculties || [],
    specialties: raw.specialties || [],
    categories: raw.categories || [],
    books: (raw.books || []).map((b) => ({
      ...b,
      allowPdfDownload: Boolean(b.allowPdfDownload),
      viewsCount: b.viewsCount ?? 0,
      favoritesCount: b.favoritesCount ?? 0,
      favoritedBy: b.favoritedBy ?? [],
    })),
    students: raw.students || [],
    librarians: raw.librarians || [],
    adminAccount: raw.adminAccount,
    loans: refreshLoanStatuses(raw.loans || []),
    reservations: raw.reservations || [],
    logs: [...(raw.logs || [])].sort((a, b) => b.id.localeCompare(a.id)),
    siteSettings: mergeSiteSettings(DEFAULT_SITE_SETTINGS, raw.siteSettings),
  };
}

function parseConfigPayload<T>(doc: ConfigDoc | null, fallback: T): T {
  if (!doc?.payload) return fallback;
  try {
    return JSON.parse(doc.payload) as T;
  } catch {
    return fallback;
  }
}

async function readMeta(): Promise<MetaPayload | null> {
  const doc = await getFirestoreDoc<ConfigDoc>('config', 'meta');
  if (!doc) return null;
  return parseConfigPayload<MetaPayload | null>(doc, null);
}

async function loadAllFromFirestore(): Promise<LibraryDatabaseState> {
  const [
    adminDoc,
    settingsDoc,
    faculties,
    specialties,
    categories,
    books,
    students,
    librarians,
    loans,
    reservations,
    logs,
  ] = await Promise.all([
    getFirestoreDoc<ConfigDoc>('config', 'adminAccount'),
    getFirestoreDoc<ConfigDoc>('config', 'siteSettings'),
    listFirestoreCollection<Faculty>('faculties'),
    listFirestoreCollection<Specialty>('specialties'),
    listFirestoreCollection<BookCategory>('categories'),
    listFirestoreCollection<Book>('books'),
    listFirestoreCollection<Student>('students'),
    listFirestoreCollection<Librarian>('librarians'),
    listFirestoreCollection<Loan>('loans'),
    listFirestoreCollection<Reservation>('reservations'),
    listFirestoreCollection<ActivityLog>('logs'),
  ]);

  const defaultAdmin: AdminAccount = {
    ...INITIAL_ADMIN,
    password: hashPassword(INITIAL_ADMIN.password || 'admin123'),
  };

  const adminAccount = parseConfigPayload<AdminAccount>(adminDoc, defaultAdmin);
  const rawSettings = parseConfigPayload<Partial<SiteSettings>>(settingsDoc, DEFAULT_SITE_SETTINGS);

  return normalizeState({
    faculties,
    specialties,
    categories,
    books,
    students,
    librarians,
    adminAccount,
    loans,
    reservations,
    logs,
    siteSettings: mergeSiteSettings(DEFAULT_SITE_SETTINGS, rawSettings),
  });
}

async function seedZeroBaselineInFirestore(): Promise<{
  state: LibraryDatabaseState;
  meta: MetaPayload;
}> {
  const nowIso = new Date().toISOString();
  const seededAdmin: AdminAccount = {
    ...INITIAL_ADMIN,
    password: hashPassword(INITIAL_ADMIN.password || 'admin123'),
  };
  const sessionSecret = crypto.randomBytes(32).toString('hex');
  const meta: MetaPayload = {
    seeded: true,
    revision: 1,
    sessionSecret,
  };

  await commitFirestoreBatch([
    {
      type: 'set',
      collection: 'config',
      id: 'adminAccount',
      data: {
        id: 'adminAccount',
        payload: JSON.stringify(seededAdmin),
        updatedAt: nowIso,
      },
    },
    {
      type: 'set',
      collection: 'config',
      id: 'siteSettings',
      data: {
        id: 'siteSettings',
        payload: JSON.stringify(DEFAULT_SITE_SETTINGS),
        updatedAt: nowIso,
      },
    },
    {
      type: 'set',
      collection: 'config',
      id: 'meta',
      data: {
        id: 'meta',
        payload: JSON.stringify(meta),
        updatedAt: nowIso,
      },
    },
  ]);

  const state = normalizeState({
    faculties: [],
    specialties: [],
    categories: [],
    books: [],
    students: [],
    librarians: [],
    adminAccount: seededAdmin,
    loans: [],
    reservations: [],
    logs: [],
    siteSettings: DEFAULT_SITE_SETTINGS,
  });

  return { state, meta };
}

export async function initDatabase(): Promise<void> {
  if (cachedState) return;
  if (initPromise) return initPromise;

  initPromise = (async () => {
    await validateFirestoreConnection();
    const meta = await readMeta();
    if (!meta || !meta.seeded) {
      const seeded = await seedZeroBaselineInFirestore();
      setSessionSecret(seeded.meta.sessionSecret);
      cachedState = seeded.state;
      cachedRevision = seeded.meta.revision;
      lastMetaCheckAt = Date.now();
    } else {
      if (meta.sessionSecret) {
        setSessionSecret(meta.sessionSecret);
      }
      cachedState = await loadAllFromFirestore();
      cachedRevision = meta.revision || 1;
      lastMetaCheckAt = Date.now();
    }
  })();

  try {
    await initPromise;
  } finally {
    initPromise = null;
  }
}

export async function ensureFreshState(force = false): Promise<LibraryDatabaseState> {
  if (!cachedState) {
    await initDatabase();
  }
  const now = Date.now();
  if (force || now - lastMetaCheckAt > META_CHECK_TTL_MS) {
    const meta = await readMeta();
    if (meta) {
      if (meta.sessionSecret) {
        setSessionSecret(meta.sessionSecret);
      }
      if (meta.revision !== cachedRevision) {
        cachedState = await loadAllFromFirestore();
        cachedRevision = meta.revision;
      }
    }
    lastMetaCheckAt = Date.now();
  }
  if (!cachedState) {
    throw new Error("Ma'lumotlar bazasi ishga tushmadi");
  }
  cachedState = {
    ...cachedState,
    loans: refreshLoanStatuses(cachedState.loans),
  };
  return cachedState;
}

export function getFullState(): LibraryDatabaseState {
  if (!cachedState) {
    throw new Error("Ma'lumotlar bazasi hali yuklanmagan");
  }
  return {
    ...cachedState,
    loans: refreshLoanStatuses(cachedState.loans),
  };
}

function diffCollectionOps<T extends { id: string }>(
  collection: string,
  prevItems: T[],
  nextItems: T[]
): BatchWriteOp[] {
  const ops: BatchWriteOp[] = [];
  const prevMap = new Map<string, string>();
  const nextIds = new Set<string>();

  for (const item of prevItems) {
    prevMap.set(item.id, JSON.stringify(item));
  }

  for (const item of nextItems) {
    nextIds.add(item.id);
    const serialized = JSON.stringify(item);
    if (prevMap.get(item.id) !== serialized) {
      ops.push({
        type: 'set',
        collection,
        id: item.id,
        data: item as unknown as Record<string, unknown>,
      });
    }
  }

  for (const prevItem of prevItems) {
    if (!nextIds.has(prevItem.id)) {
      ops.push({
        type: 'delete',
        collection,
        id: prevItem.id,
      });
    }
  }

  return ops;
}

export function updateStateAsync<T>(
  mutator: (state: LibraryDatabaseState) => T | Promise<T>
): Promise<{ result: T; state: LibraryDatabaseState }> {
  const run = writeQueue.then(async () => {
    const current = await ensureFreshState(true);
    const prevSnapshot = cloneState(current);
    const working = cloneState(current);

    const result = await mutator(working);
    const normalizedNext = normalizeState(working);

    const ops: BatchWriteOp[] = [
      ...diffCollectionOps('faculties', prevSnapshot.faculties, normalizedNext.faculties),
      ...diffCollectionOps('specialties', prevSnapshot.specialties, normalizedNext.specialties),
      ...diffCollectionOps('categories', prevSnapshot.categories, normalizedNext.categories),
      ...diffCollectionOps('books', prevSnapshot.books, normalizedNext.books),
      ...diffCollectionOps('students', prevSnapshot.students, normalizedNext.students),
      ...diffCollectionOps('librarians', prevSnapshot.librarians, normalizedNext.librarians),
      ...diffCollectionOps('loans', prevSnapshot.loans, normalizedNext.loans),
      ...diffCollectionOps('reservations', prevSnapshot.reservations, normalizedNext.reservations),
      ...diffCollectionOps('logs', prevSnapshot.logs, normalizedNext.logs),
    ];

    const nowIso = new Date().toISOString();

    if (JSON.stringify(prevSnapshot.adminAccount) !== JSON.stringify(normalizedNext.adminAccount)) {
      ops.push({
        type: 'set',
        collection: 'config',
        id: 'adminAccount',
        data: {
          id: 'adminAccount',
          payload: JSON.stringify(normalizedNext.adminAccount),
          updatedAt: nowIso,
        },
      });
    }

    if (JSON.stringify(prevSnapshot.siteSettings) !== JSON.stringify(normalizedNext.siteSettings)) {
      ops.push({
        type: 'set',
        collection: 'config',
        id: 'siteSettings',
        data: {
          id: 'siteSettings',
          payload: JSON.stringify(normalizedNext.siteSettings),
          updatedAt: nowIso,
        },
      });
    }

    if (ops.length > 0) {
      const metaDoc = await readMeta();
      const nextRevision = (metaDoc?.revision || cachedRevision || 1) + 1;
      const nextMeta: MetaPayload = {
        seeded: true,
        revision: nextRevision,
        sessionSecret: metaDoc?.sessionSecret || crypto.randomBytes(32).toString('hex'),
      };
      setSessionSecret(nextMeta.sessionSecret);
      ops.push({
        type: 'set',
        collection: 'config',
        id: 'meta',
        data: {
          id: 'meta',
          payload: JSON.stringify(nextMeta),
          updatedAt: nowIso,
        },
      });

      await commitFirestoreBatch(ops);
      cachedRevision = nextRevision;
    }

    cachedState = normalizedNext;
    lastMetaCheckAt = Date.now();
    return { result, state: normalizedNext };
  });

  writeQueue = run.catch(() => {});
  return run;
}

export function appendLog(
  state: LibraryDatabaseState,
  action: ActivityLog['action'],
  performerName: string,
  performerRole: UserRole,
  details: string
) {
  const now = new Date();
  const timestamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
    now.getDate()
  ).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  logSeq = (logSeq + 1) % 1000;
  const seqStr = String(logSeq).padStart(3, '0');
  const entry: ActivityLog = {
    id: `log-${Date.now()}-${seqStr}-${Math.random().toString(36).slice(2, 5)}`,
    timestamp,
    action,
    performerName,
    performerRole,
    details,
  };
  state.logs = [entry, ...state.logs].slice(0, 250);
}

export function sanitizeStudent(student: Student): Omit<Student, 'password'> {
  const { password: _pw, ...safe } = student;
  return safe;
}

export function sanitizeLibrarian(lib: Librarian): Omit<Librarian, 'password'> {
  const { password: _pw, ...safe } = lib;
  return safe;
}

export function sanitizeAdmin(admin: AdminAccount): Omit<AdminAccount, 'password'> {
  const { password: _pw, ...safe } = admin;
  return safe;
}

export function getScopedState(role: UserRole | null, userId: string | null) {
  const state = getFullState();

  const publicBase = {
    faculties: state.faculties,
    specialties: state.specialties,
    categories: state.categories,
    books: state.books,
    siteSettings: state.siteSettings,
    stats: {
      studentsCount: state.students.length,
    },
  };

  if (!role || !userId) {
    return {
      ...publicBase,
      students: [] as Student[],
      librarians: [] as Librarian[],
      adminAccount: null as AdminAccount | null,
      loans: [] as Loan[],
      reservations: [] as Reservation[],
      logs: [] as ActivityLog[],
    };
  }

  if (role === 'student') {
    const me = state.students.find((s) => s.id === userId);
    return {
      ...publicBase,
      students: me ? [sanitizeStudent(me)] : [],
      librarians: [] as Librarian[],
      adminAccount: null as AdminAccount | null,
      loans: state.loans.filter((l) => l.studentId === userId),
      reservations: state.reservations.filter((r) => r.studentId === userId),
      logs: [] as ActivityLog[],
    };
  }

  if (role === 'librarian') {
    return {
      ...publicBase,
      students: state.students.map(sanitizeStudent),
      librarians: state.librarians.map(sanitizeLibrarian),
      adminAccount: null as AdminAccount | null,
      loans: state.loans,
      reservations: state.reservations,
      logs: [] as ActivityLog[],
    };
  }

  // Admin
  return {
    ...publicBase,
    students: state.students.map(sanitizeStudent),
    librarians: state.librarians.map(sanitizeLibrarian),
    adminAccount: sanitizeAdmin(state.adminAccount),
    loans: state.loans,
    reservations: state.reservations,
    logs: state.logs,
  };
}

export async function saveUploadedFileAsync(params: {
  id: string;
  fileName: string;
  mimeType: string;
  buffer: Buffer;
}): Promise<StoredFileMeta> {
  const safeId = params.id.replace(/[^a-zA-Z0-9_-]/g, '');
  const createdAt = new Date().toISOString();

  const chunks: string[] = [];
  for (let offset = 0; offset < params.buffer.length; offset += RAW_CHUNK_BYTES) {
    chunks.push(params.buffer.subarray(offset, offset + RAW_CHUNK_BYTES).toString('base64'));
  }
  if (chunks.length === 0) {
    chunks.push('');
  }

  const meta: StoredFileMeta = {
    id: safeId,
    fileName: params.fileName.slice(0, 290),
    mimeType: params.mimeType,
    size: params.buffer.length,
    chunkCount: chunks.length,
    createdAt,
  };

  const ops: BatchWriteOp[] = [
    {
      type: 'set',
      collection: 'file_meta',
      id: safeId,
      data: meta as unknown as Record<string, unknown>,
    },
    ...chunks.map((chunkData, idx) => ({
      type: 'set' as const,
      collection: 'file_chunks',
      id: `${safeId}__${idx}`,
      data: {
        fileId: safeId,
        chunkIndex: idx,
        data: chunkData,
      },
    })),
  ];

  await commitFirestoreBatch(ops);
  cacheFile(safeId, { meta, buffer: params.buffer });
  return meta;
}

export async function readUploadedFileAsync(
  id: string
): Promise<{ meta: StoredFileMeta; buffer: Buffer } | null> {
  const safeId = id.replace(/[^a-zA-Z0-9_-]/g, '');
  const cached = fileCache.get(safeId);
  if (cached) return cached;

  const meta = await getFirestoreDoc<StoredFileMeta>('file_meta', safeId);
  if (!meta) return null;

  const chunkCount = Math.max(1, Number(meta.chunkCount || 1));
  const chunkDocs = await Promise.all(
    Array.from({ length: chunkCount }, (_, idx) =>
      getFirestoreDoc<FileChunkDoc>('file_chunks', `${safeId}__${idx}`)
    )
  );

  if (chunkDocs.some((c) => !c)) {
    return null;
  }

  const buffers = chunkDocs.map((c) => Buffer.from(c!.data || '', 'base64'));
  const combined = Buffer.concat(buffers);
  const assembled = { meta, buffer: combined };
  cacheFile(safeId, assembled);
  return assembled;
}
