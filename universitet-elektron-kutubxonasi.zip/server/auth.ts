import crypto from 'node:crypto';
import type { UserRole } from '../src/types/library.ts';

export interface AuthTokenPayload {
  userId: string;
  role: UserRole;
  iat: number;
  exp: number;
}

const TOKEN_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days

let sharedSessionSecret: string =
  process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 16
    ? process.env.SESSION_SECRET
    : crypto.randomBytes(32).toString('hex');

export function setSessionSecret(secret: string) {
  if (process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 16) {
    sharedSessionSecret = process.env.SESSION_SECRET;
    return;
  }
  if (secret && secret.length >= 16) {
    sharedSessionSecret = secret;
  }
}

export function getSessionSecret(): string {
  return sharedSessionSecret;
}

export function hashPassword(password: string): string {
  if (password.startsWith('scrypt$')) return password;
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${derived}`;
}

export function verifyPassword(candidate: string, storedHashOrPlain: string): boolean {
  if (!storedHashOrPlain) return false;
  if (!storedHashOrPlain.startsWith('scrypt$')) {
    const a = Buffer.from(candidate);
    const b = Buffer.from(storedHashOrPlain);
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  }
  const parts = storedHashOrPlain.split('$');
  if (parts.length !== 3) return false;
  const [, salt, hexKey] = parts;
  const derived = crypto.scryptSync(candidate, salt, 64);
  const expected = Buffer.from(hexKey, 'hex');
  if (derived.length !== expected.length) return false;
  return crypto.timingSafeEqual(derived, expected);
}

export function signAuthToken(userId: string, role: UserRole, _dataDir?: string): string {
  const now = Date.now();
  const payload: AuthTokenPayload = {
    userId,
    role,
    iat: now,
    exp: now + TOKEN_TTL_MS,
  };
  const encodedPayload = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const signature = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encodedPayload)
    .digest('base64url');
  return `${encodedPayload}.${signature}`;
}

export function verifyAuthToken(token: string | undefined | null, _dataDir?: string): AuthTokenPayload | null {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encodedPayload, signature] = parts;
  const expectedSig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encodedPayload)
    .digest('base64url');

  const sigBuf = Buffer.from(signature);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }

  try {
    const decoded = JSON.parse(Buffer.from(encodedPayload, 'base64url').toString('utf8')) as AuthTokenPayload;
    if (!decoded.userId || !decoded.role || !decoded.exp || Date.now() > decoded.exp) {
      return null;
    }
    return decoded;
  } catch {
    return null;
  }
}
