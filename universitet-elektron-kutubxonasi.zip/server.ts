import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import { WebSocketServer, WebSocket } from 'ws';
import type {
  Book,
  BookCategory,
  Faculty,
  Librarian,
  Loan,
  Reservation,
  SiteSettings,
  Specialty,
  Student,
  UserRole,
} from './src/types/library.ts';
import {
  calculateDaysOverdue,
  calculateFine,
  calculateLoanStatus,
  canDownloadBookPdf,
  canIssueBook,
  canIssueMultipleBooks,
  generateStudentId,
  mergeSiteSettings,
} from './src/utils/libraryRules.ts';
import {
  DATA_DIR,
  appendLog,
  ensureFreshState,
  getFullState,
  getScopedState,
  initDatabase,
  readUploadedFileAsync,
  sanitizeAdmin,
  sanitizeLibrarian,
  sanitizeStudent,
  saveUploadedFileAsync,
  updateStateAsync,
} from './server/database.ts';
import {
  hashPassword,
  signAuthToken,
  verifyAuthToken,
  verifyPassword,
} from './server/auth.ts';

interface AuthenticatedActor {
  id: string;
  role: UserRole;
  name: string;
  email: string;
  phone?: string;
  avatarUrl: string;
  studentData?: Omit<Student, 'password'>;
  librarianData?: Omit<Librarian, 'password'>;
  adminData?: ReturnType<typeof sanitizeAdmin>;
}

interface AuthedRequest extends express.Request {
  actor?: AuthenticatedActor | null;
}

type AsyncRouteHandler = (
  req: AuthedRequest,
  res: express.Response,
  next: express.NextFunction
) => Promise<void> | void;

const wrapAsync =
  (fn: AsyncRouteHandler): express.RequestHandler =>
  (req, res, next) => {
    Promise.resolve(fn(req as AuthedRequest, res, next)).catch(next);
  };

function extractToken(req: express.Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  const queryToken = req.query.token;
  if (typeof queryToken === 'string' && queryToken.trim()) {
    return queryToken.trim();
  }
  return null;
}

function resolveActorFromToken(token: string | null): AuthenticatedActor | null {
  const payload = verifyAuthToken(token, DATA_DIR);
  if (!payload) return null;

  const state = getFullState();
  if (payload.role === 'admin' && state.adminAccount.id === payload.userId) {
    const admin = sanitizeAdmin(state.adminAccount);
    return {
      id: admin.id,
      role: 'admin',
      name: admin.name,
      email: admin.email,
      phone: admin.phone,
      avatarUrl: admin.avatarUrl || '',
      adminData: admin,
    };
  }
  if (payload.role === 'librarian') {
    const lib = state.librarians.find((l) => l.id === payload.userId);
    if (!lib) return null;
    const safe = sanitizeLibrarian(lib);
    return {
      id: safe.id,
      role: 'librarian',
      name: safe.name,
      email: safe.email,
      phone: safe.phone,
      avatarUrl: safe.avatarUrl || '',
      librarianData: safe,
    };
  }
  if (payload.role === 'student') {
    const stu = state.students.find((s) => s.id === payload.userId);
    if (!stu || stu.status === 'blocked') return null;
    const safe = sanitizeStudent(stu);
    return {
      id: safe.id,
      role: 'student',
      name: safe.name,
      email: safe.email,
      phone: safe.phone,
      avatarUrl: safe.avatarUrl || '',
      studentData: safe,
    };
  }
  return null;
}

async function startServer() {
  // Initialize shared Firestore DB & zero-baseline seed if brand new
  await initDatabase();

  const app = express();
  app.use(express.json({ limit: '60mb' }));

  const httpServer = http.createServer(app);
  const wss = new WebSocketServer({ noServer: true });

  httpServer.on('upgrade', (request, socket, head) => {
    const reqUrl = new URL(request.url || '/', `http://${request.headers.host || 'localhost'}`);
    if (reqUrl.pathname === '/ws') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    }
  });

  const broadcastStateChange = (reason: string) => {
    const payload = JSON.stringify({
      type: 'STATE_UPDATED',
      reason,
      timestamp: Date.now(),
    });
    for (const client of wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
      }
    }
  };

  wss.on('connection', (ws) => {
    ws.send(JSON.stringify({ type: 'CONNECTED', timestamp: Date.now() }));
  });

  // Sync fresh shared DB state & attach optional actor middleware
  app.use(
    '/api',
    wrapAsync(async (req: AuthedRequest, _res, next) => {
      if (req.path !== '/health') {
        await ensureFreshState(false);
      }
      req.actor = resolveActorFromToken(extractToken(req));
      next();
    })
  );

  const requireAuth = (req: AuthedRequest, res: express.Response): AuthenticatedActor | null => {
    if (!req.actor) {
      res.status(401).json({ error: 'Avtorizatsiya talab qilinadi. Iltimos, profilingizga kiring.' });
      return null;
    }
    return req.actor;
  };

  const requireRole = (
    req: AuthedRequest,
    res: express.Response,
    roles: UserRole[]
  ): AuthenticatedActor | null => {
    const actor = requireAuth(req, res);
    if (!actor) return null;
    if (!roles.includes(actor.role)) {
      res.status(403).json({ error: 'Ushbu amalni bajarish uchun ruxsatingiz yetarli emas.' });
      return null;
    }
    return actor;
  };

  // Health
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  // Auth: Login
  app.post(
    '/api/auth/login',
    wrapAsync(async (req, res) => {
      const { login, password } = req.body as { login?: string; password?: string };
      const cleanLogin = String(login || '').trim().toLowerCase();
      const rawPassword = String(password || '');

      if (!cleanLogin || !rawPassword) {
        res.status(400).json({ error: 'Iltimos, login va parolni kiriting!' });
        return;
      }

      const state = await ensureFreshState(true);

      // Check Admin
      if (
        (cleanLogin === 'admin' || cleanLogin === state.adminAccount.email.toLowerCase()) &&
        verifyPassword(rawPassword, state.adminAccount.password || '')
      ) {
        const now = new Date();
        const loginTime = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
          now.getDate()
        ).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        await updateStateAsync((s) => {
          s.adminAccount = { ...s.adminAccount, lastLogin: loginTime };
        });
        const token = signAuthToken(state.adminAccount.id, 'admin', DATA_DIR);
        const actor = resolveActorFromToken(token);
        res.json({ token, user: actor });
        return;
      }

      // Check Librarians
      const lib = state.librarians.find(
        (l) => l.email.toLowerCase() === cleanLogin || l.id.toLowerCase() === cleanLogin
      );
      if (lib && verifyPassword(rawPassword, lib.password || '')) {
        const token = signAuthToken(lib.id, 'librarian', DATA_DIR);
        const actor = resolveActorFromToken(token);
        res.json({ token, user: actor });
        return;
      }

      // Check Students
      const stu = state.students.find(
        (s) => s.studentId.toLowerCase() === cleanLogin || s.email.toLowerCase() === cleanLogin
      );
      if (stu) {
        if (stu.status === 'blocked') {
          res.status(403).json({ error: "Ushbu talaba hisobi ma'muriyat tomonidan bloklangan." });
          return;
        }
        if (verifyPassword(rawPassword, stu.password || '')) {
          const token = signAuthToken(stu.id, 'student', DATA_DIR);
          const actor = resolveActorFromToken(token);
          res.json({ token, user: actor });
          return;
        }
      }

      res.status(401).json({ error: "Login yoki parol noto'g'ri kiritildi!" });
    })
  );

  // Auth: Current user
  app.get('/api/auth/me', (req: AuthedRequest, res) => {
    if (!req.actor) {
      res.status(401).json({ error: 'Sessiya muddati tugagan yoki tizimga kirilmagan.' });
      return;
    }
    res.json({ user: req.actor });
  });

  // Scoped State
  app.get(
    '/api/state',
    wrapAsync(async (req: AuthedRequest, res) => {
      await ensureFreshState(true);
      req.actor = resolveActorFromToken(extractToken(req));
      const scoped = getScopedState(req.actor?.role || null, req.actor?.id || null);
      res.json(scoped);
    })
  );

  // Uploaded files (Profile avatars for all roles; Covers, PDFs, Banner media for admin/librarian)
  app.post(
    '/api/files',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireAuth(req, res);
      if (!actor) return;

      const { dataUrl, fileName, mimeType } = req.body as {
        dataUrl?: string;
        fileName?: string;
        mimeType?: string;
      };
      if (!dataUrl || typeof dataUrl !== 'string') {
        res.status(400).json({ error: "Fayl ma'lumoti topilmadi." });
        return;
      }

      const match = /^data:([^;]+);base64,(.+)$/.exec(dataUrl);
      if (!match) {
        res.status(400).json({ error: "Noto'g'ri fayl formati." });
        return;
      }
      const detectedMime = (mimeType || match[1] || '').toLowerCase();
      const buffer = Buffer.from(match[2], 'base64');
      const lowerName = (fileName || '').toLowerCase();
      const isImage = detectedMime.startsWith('image/');
      const isPdf = detectedMime === 'application/pdf' || lowerName.endsWith('.pdf');
      const isVideo =
        detectedMime.startsWith('video/') ||
        lowerName.endsWith('.mp4') ||
        lowerName.endsWith('.webm') ||
        lowerName.endsWith('.ogg') ||
        lowerName.endsWith('.mov');

      if (!isImage && !isPdf && !isVideo) {
        res.status(400).json({ error: 'Faqat rasm, video (MP4/WebM) yoki PDF fayl yuklash mumkin.' });
        return;
      }

      if (actor.role === 'student' && !isImage) {
        res.status(403).json({ error: 'Talabalar faqat profil rasmi (image) yuklashlari mumkin.' });
        return;
      }

      if (actor.role === 'student' && buffer.length > 5 * 1024 * 1024) {
        res.status(400).json({ error: 'Profil rasmi hajmi 5 MB dan oshmasligi kerak.' });
        return;
      }

      const normalizedMime = isPdf
        ? 'application/pdf'
        : isVideo
        ? detectedMime.startsWith('video/')
          ? detectedMime
          : lowerName.endsWith('.webm')
          ? 'video/webm'
          : 'video/mp4'
        : detectedMime;
      const prefix = isPdf ? 'pdf' : isVideo ? 'vid' : 'img';
      const defaultExt = isPdf ? 'pdf' : isVideo ? 'mp4' : 'jpg';
      const id = `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const meta = await saveUploadedFileAsync({
        id,
        fileName: (fileName || `${id}.${defaultExt}`).slice(0, 180),
        mimeType: normalizedMime,
        buffer,
      });

      res.status(201).json({
        ...meta,
        url: `/api/files/${meta.id}`,
      });
    })
  );

  app.get(
    '/api/files/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const found = await readUploadedFileAsync(req.params.id);
      if (!found) {
        res.status(404).json({ error: 'Fayl topilmadi.' });
        return;
      }
      if (found.meta.mimeType === 'application/pdf') {
        if (!req.actor) {
          res.status(401).json({ error: "PDF faylni o'qish uchun tizimdagi profilingizga kiring." });
          return;
        }
        if (req.query.download === '1' && req.actor.role === 'student') {
          const state = getFullState();
          const linkedBook = state.books.find((b) => b.pdfFileId === found.meta.id);
          if (linkedBook && !canDownloadBookPdf(linkedBook, req.actor.role)) {
            res.status(403).json({
              error: "Ushbu kitob faqat sayt ichida o'qish uchun belgilangan, yuklab olishga ruxsat yo'q.",
            });
            return;
          }
        }
        res.setHeader('Content-Disposition', 'inline');
      }

      const total = found.buffer.length;
      const range = req.headers.range;
      res.setHeader('Accept-Ranges', 'bytes');
      res.setHeader('Content-Type', found.meta.mimeType);
      res.setHeader('Cache-Control', 'public, max-age=3600');

      if (range && range.startsWith('bytes=')) {
        const parts = range.replace(/bytes=/, '').split('-');
        const start = Math.max(0, parseInt(parts[0], 10) || 0);
        const end = parts[1] ? Math.min(total - 1, parseInt(parts[1], 10)) : total - 1;
        if (start >= total || end < start) {
          res.status(416).setHeader('Content-Range', `bytes */${total}`).end();
          return;
        }
        const chunk = found.buffer.subarray(start, end + 1);
        res.status(206);
        res.setHeader('Content-Range', `bytes ${start}-${end}/${total}`);
        res.setHeader('Content-Length', String(chunk.length));
        res.send(chunk);
        return;
      }

      res.setHeader('Content-Length', String(total));
      res.send(found.buffer);
    })
  );

  // ==========================================
  // FACULTIES (Admin CRUD)
  // ==========================================
  app.post(
    '/api/faculties',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const { name, shortName, dean } = req.body as {
        name?: string;
        shortName?: string;
        dean?: string;
      };
      const cleanName = String(name || '').trim();
      if (!cleanName) {
        res.status(400).json({ error: 'Fakultet nomi kiritilishi shart!' });
        return;
      }

      const { result } = await updateStateAsync((state) => {
        if (state.faculties.some((f) => f.name.toLowerCase() === cleanName.toLowerCase())) {
          return { error: `"${cleanName}" nomli fakultet allaqachon mavjud!` };
        }
        const created: Faculty = {
          id: `fac-${Date.now()}`,
          name: cleanName,
          shortName: String(shortName || '').trim() || undefined,
          dean: String(dean || '').trim() || undefined,
          createdAt: new Date().toISOString().split('T')[0],
        };
        state.faculties = [created, ...state.faculties];
        appendLog(state, 'FAKULTET_YARATILDI', actor.name, actor.role, `Yangi fakultet yaratildi: "${created.name}"`);
        return { faculty: created };
      });

      if ('error' in result) {
        res.status(409).json({ error: result.error });
        return;
      }
      broadcastStateChange('faculties:create');
      res.status(201).json(result.faculty);
    })
  );

  app.patch(
    '/api/faculties/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const { name, shortName, dean } = req.body as {
        name?: string;
        shortName?: string;
        dean?: string;
      };
      const cleanName = String(name || '').trim();
      if (!cleanName) {
        res.status(400).json({ error: "Fakultet nomi bo'sh bo'lmasligi kerak!" });
        return;
      }

      const { result } = await updateStateAsync((state) => {
        const target = state.faculties.find((f) => f.id === req.params.id);
        if (!target) return { status: 404, error: 'Fakultet topilmadi!' };

        const duplicate = state.faculties.some(
          (f) => f.id !== target.id && f.name.toLowerCase() === cleanName.toLowerCase()
        );
        if (duplicate) {
          return { status: 409, error: `"${cleanName}" nomli fakultet allaqachon mavjud!` };
        }

        const oldName = target.name;
        target.name = cleanName;
        target.shortName = String(shortName || '').trim() || undefined;
        target.dean = String(dean || '').trim() || undefined;

        if (oldName !== cleanName) {
          state.specialties = state.specialties.map((s) =>
            s.faculty === oldName ? { ...s, faculty: cleanName } : s
          );
          state.students = state.students.map((st) =>
            st.faculty === oldName ? { ...st, faculty: cleanName } : st
          );
          state.books = state.books.map((b) =>
            b.faculty === oldName ? { ...b, faculty: cleanName } : b
          );
          state.loans = state.loans.map((l) =>
            l.studentFaculty === oldName ? { ...l, studentFaculty: cleanName } : l
          );
        }

        appendLog(
          state,
          'FAKULTET_TAHRIRLANDI',
          actor.name,
          actor.role,
          `Fakultet tahrirlandi: "${oldName}" → "${cleanName}"`
        );
        return { status: 200, faculty: target };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('faculties:update');
      res.json(result.faculty);
    })
  );

  app.delete(
    '/api/faculties/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const { result } = await updateStateAsync((state) => {
        const target = state.faculties.find((f) => f.id === req.params.id);
        if (!target) return { status: 404, error: 'Fakultet topilmadi!' };

        const hasStudents = state.students.some((s) => s.faculty === target.name);
        const hasSpecialties = state.specialties.some((s) => s.faculty === target.name);
        if (hasStudents || hasSpecialties) {
          return {
            status: 400,
            error: `"${target.name}" fakultetiga biriktirilgan yo'nalish yoki talabalar mavjud! Avval ularni o'zgartiring.`,
          };
        }

        state.faculties = state.faculties.filter((f) => f.id !== target.id);
        appendLog(state, 'FAKULTET_OCHIRILDI', actor.name, actor.role, `Fakultet o'chirildi: "${target.name}"`);
        return { status: 200 };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('faculties:delete');
      res.json({ ok: true });
    })
  );

  // ==========================================
  // SPECIALTIES (Admin CRUD)
  // ==========================================
  app.post(
    '/api/specialties',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const { code, name, faculty } = req.body as Partial<Specialty>;
      const cleanCode = String(code || '').trim();
      const cleanName = String(name || '').trim();
      const cleanFaculty = String(faculty || '').trim();
      if (!cleanCode || !cleanName || !cleanFaculty) {
        res.status(400).json({ error: "Yo'nalish shifri, nomi va fakulteti kiritilishi shart!" });
        return;
      }

      const { result } = await updateStateAsync((state) => {
        if (state.specialties.some((s) => s.code.toLowerCase() === cleanCode.toLowerCase())) {
          return { error: `"${cleanCode}" shifrli yo'nalish allaqachon mavjud!` };
        }
        const created: Specialty = {
          id: `spec-${Date.now()}`,
          code: cleanCode,
          name: cleanName,
          faculty: cleanFaculty,
        };
        state.specialties = [created, ...state.specialties];
        appendLog(
          state,
          'YONALISH_YARATILDI',
          actor.name,
          actor.role,
          `Yangi yo'nalish qo'shildi: [${created.code}] ${created.name}`
        );
        return { specialty: created };
      });

      if ('error' in result) {
        res.status(409).json({ error: result.error });
        return;
      }
      broadcastStateChange('specialties:create');
      res.status(201).json(result.specialty);
    })
  );

  app.patch(
    '/api/specialties/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const { code, name, faculty } = req.body as Partial<Specialty>;
      const cleanCode = String(code || '').trim();
      const cleanName = String(name || '').trim();
      const cleanFaculty = String(faculty || '').trim();
      if (!cleanCode || !cleanName || !cleanFaculty) {
        res.status(400).json({ error: "Yo'nalish shifri, nomi va fakulteti bo'sh bo'lmasligi kerak!" });
        return;
      }

      const { result } = await updateStateAsync((state) => {
        const target = state.specialties.find((s) => s.id === req.params.id);
        if (!target) return { status: 404, error: "Yo'nalish topilmadi!" };

        const duplicate = state.specialties.some(
          (s) => s.id !== target.id && s.code.toLowerCase() === cleanCode.toLowerCase()
        );
        if (duplicate) {
          return { status: 409, error: `"${cleanCode}" shifrli yo'nalish allaqachon mavjud!` };
        }

        const oldCode = target.code;
        const oldName = target.name;
        target.code = cleanCode;
        target.name = cleanName;
        target.faculty = cleanFaculty;

        state.students = state.students.map((st) =>
          st.specialtyCode === oldCode || st.specialty === oldName
            ? { ...st, specialtyCode: cleanCode, specialty: cleanName, faculty: cleanFaculty }
            : st
        );

        appendLog(
          state,
          'YONALISH_TAHRIRLANDI',
          actor.name,
          actor.role,
          `Yo'nalish tahrirlandi: [${oldCode}] ${oldName} → [${cleanCode}] ${cleanName}`
        );
        return { status: 200, specialty: target };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('specialties:update');
      res.json(result.specialty);
    })
  );

  app.delete(
    '/api/specialties/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const { result } = await updateStateAsync((state) => {
        const target = state.specialties.find((s) => s.id === req.params.id);
        if (!target) return { status: 404, error: "Yo'nalish topilmadi!" };
        state.specialties = state.specialties.filter((s) => s.id !== target.id);
        appendLog(
          state,
          'YONALISH_OCHIRILDI',
          actor.name,
          actor.role,
          `Yo'nalish o'chirildi: [${target.code}] ${target.name}`
        );
        return { status: 200 };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('specialties:delete');
      res.json({ ok: true });
    })
  );

  // ==========================================
  // CATEGORIES (Admin / Librarian CRUD)
  // ==========================================
  app.post(
    '/api/categories',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin', 'librarian']);
      if (!actor) return;

      const { name, description, imageUrl } = req.body as {
        name?: string;
        description?: string;
        imageUrl?: string;
      };
      const cleanName = String(name || '').trim();
      if (!cleanName) {
        res.status(400).json({ error: 'Kategoriya nomi kiritilishi shart!' });
        return;
      }

      const { result } = await updateStateAsync((state) => {
        if (state.categories.some((c) => c.name.toLowerCase() === cleanName.toLowerCase())) {
          return { error: `"${cleanName}" nomli kategoriya allaqachon mavjud!` };
        }
        const created: BookCategory = {
          id: `cat-${Date.now()}`,
          name: cleanName,
          description: String(description || '').trim() || `${cleanName} yo'nalishidagi adabiyotlar`,
          imageUrl: imageUrl?.trim() || undefined,
          createdAt: new Date().toISOString().split('T')[0],
        };
        state.categories = [created, ...state.categories];
        appendLog(
          state,
          'KATEGORIYA_YARATILDI',
          actor.name,
          actor.role,
          `Yangi kitob kategoriyasi yaratildi: "${created.name}"`
        );
        return { category: created };
      });

      if ('error' in result) {
        res.status(409).json({ error: result.error });
        return;
      }
      broadcastStateChange('categories:create');
      res.status(201).json(result.category);
    })
  );

  app.patch(
    '/api/categories/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin', 'librarian']);
      if (!actor) return;

      const { name, description, imageUrl } = req.body as {
        name?: string;
        description?: string;
        imageUrl?: string;
      };
      const cleanName = String(name || '').trim();
      if (!cleanName) {
        res.status(400).json({ error: 'Kategoriya nomi kiritilishi shart!' });
        return;
      }

      const { result } = await updateStateAsync((state) => {
        const target = state.categories.find((c) => c.id === req.params.id);
        if (!target) return { status: 404, error: 'Kategoriya topilmadi!' };

        const duplicate = state.categories.some(
          (c) => c.id !== target.id && c.name.toLowerCase() === cleanName.toLowerCase()
        );
        if (duplicate) return { status: 409, error: `"${cleanName}" nomli kategoriya allaqachon mavjud!` };

        const oldName = target.name;
        target.name = cleanName;
        target.description = String(description || '').trim() || target.description;
        if (imageUrl !== undefined) {
          target.imageUrl = imageUrl.trim() || undefined;
        }

        if (oldName !== cleanName) {
          state.books = state.books.map((b) =>
            b.category === oldName ? { ...b, category: cleanName } : b
          );
        }

        appendLog(
          state,
          'KATEGORIYA_TAHRIRLANDI',
          actor.name,
          actor.role,
          `Kitob kategoriyasi tahrirlandi: "${oldName}" → "${cleanName}"`
        );
        return { status: 200, category: target };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('categories:update');
      res.json(result.category);
    })
  );

  app.delete(
    '/api/categories/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin', 'librarian']);
      if (!actor) return;

      const { result } = await updateStateAsync((state) => {
        const cat = state.categories.find((c) => c.id === req.params.id);
        if (!cat) return { status: 404, error: 'Kategoriya topilmadi!' };
        if (state.books.some((b) => b.category === cat.name)) {
          return {
            status: 400,
            error: `"${cat.name}" kategoriyasiga biriktirilgan kitoblar mavjud!`,
          };
        }
        state.categories = state.categories.filter((c) => c.id !== cat.id);
        appendLog(
          state,
          'KATEGORIYA_OCHIRILDI',
          actor.name,
          actor.role,
          `Kitob kategoriyasi o'chirildi: "${cat.name}"`
        );
        return { status: 200 };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('categories:delete');
      res.json({ ok: true });
    })
  );

  // ==========================================
  // BOOKS
  // ==========================================
  app.post(
    '/api/books',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin', 'librarian']);
      if (!actor) return;

      const data = req.body as Omit<Book, 'id' | 'viewsCount' | 'favoritesCount' | 'favoritedBy'>;
      if (!data.title?.trim() || !data.author?.trim()) {
        res.status(400).json({ error: 'Kitob nomi va muallifi kiritilishi shart!' });
        return;
      }

      const { result } = await updateStateAsync((state) => {
        const newBook: Book = {
          ...data,
          id: `book-${Date.now()}`,
          title: data.title.trim(),
          author: data.author.trim(),
          category: (data.category || '').trim(),
          faculty: data.faculty?.trim() || undefined,
          allowPdfDownload: Boolean(data.allowPdfDownload),
          barcode:
            data.barcode ||
            `INV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
          availableCopies: data.availableCopies ?? data.totalCopies ?? 1,
          viewsCount: 0,
          favoritesCount: 0,
          favoritedBy: [],
        };
        state.books = [newBook, ...state.books];
        appendLog(
          state,
          "KITOB_QO'SHILDI",
          actor.name,
          actor.role,
          `Yangi kitob fondga kiritildi: "${newBook.title}" (${newBook.category || 'Kategoriyasiz'})`
        );
        return newBook;
      });

      broadcastStateChange('books:create');
      res.status(201).json(result);
    })
  );

  app.patch(
    '/api/books/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin', 'librarian']);
      if (!actor) return;

      const updates = req.body as Partial<Book>;
      const { result } = await updateStateAsync((state) => {
        const idx = state.books.findIndex((b) => b.id === req.params.id);
        if (idx === -1) return { status: 404, error: 'Kitob topilmadi!' };

        const existing = state.books[idx];
        const nextBook: Book = {
          ...existing,
          ...updates,
          id: existing.id,
          allowPdfDownload:
            updates.allowPdfDownload !== undefined
              ? Boolean(updates.allowPdfDownload)
              : Boolean(existing.allowPdfDownload),
          viewsCount: existing.viewsCount,
          favoritesCount: existing.favoritesCount,
          favoritedBy: existing.favoritedBy,
        };
        state.books[idx] = nextBook;
        appendLog(
          state,
          'KITOB_TAHRIRLANDI',
          actor.name,
          actor.role,
          `Kitob ma'lumotlari tahrirlandi: "${nextBook.title}"`
        );
        return { status: 200, book: nextBook };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('books:update');
      res.json(result.book);
    })
  );

  app.delete(
    '/api/books/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin', 'librarian']);
      if (!actor) return;

      const { result } = await updateStateAsync((state) => {
        const book = state.books.find((b) => b.id === req.params.id);
        if (!book) return { status: 404, error: 'Kitob topilmadi!' };
        const hasActive = state.loans.some((l) => l.bookId === book.id && l.status !== 'returned');
        if (hasActive) {
          return {
            status: 400,
            error: "Ushbu kitob hozirda ijarada turibdi, o'chirish mumkin emas!",
          };
        }
        state.books = state.books.filter((b) => b.id !== book.id);
        state.reservations = state.reservations.filter((r) => r.bookId !== book.id);
        appendLog(
          state,
          'KITOB_OCHIRILDI',
          actor.name,
          actor.role,
          `Kitob fonddan o'chirildi: "${book.title}"`
        );
        return { status: 200 };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('books:delete');
      res.json({ ok: true });
    })
  );

  app.post(
    '/api/books/:id/view',
    wrapAsync(async (req, res) => {
      const { result } = await updateStateAsync((state) => {
        const book = state.books.find((b) => b.id === req.params.id);
        if (!book) return null;
        book.viewsCount = (book.viewsCount || 0) + 1;
        return book.viewsCount;
      });
      if (result === null) {
        res.status(404).json({ error: 'Kitob topilmadi!' });
        return;
      }
      broadcastStateChange('books:view');
      res.json({ viewsCount: result });
    })
  );

  app.post(
    '/api/books/:id/favorite',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireAuth(req, res);
      if (!actor) return;

      const { result } = await updateStateAsync((state) => {
        const book = state.books.find((b) => b.id === req.params.id);
        if (!book) return null;
        const list = book.favoritedBy || [];
        const already = list.includes(actor.id);
        const nextList = already ? list.filter((id) => id !== actor.id) : [...list, actor.id];
        const nextCount = already
          ? Math.max(0, (book.favoritesCount || 0) - 1)
          : (book.favoritesCount || 0) + 1;
        book.favoritedBy = nextList;
        book.favoritesCount = nextCount;
        return { favorited: !already, favoritesCount: nextCount };
      });

      if (!result) {
        res.status(404).json({ error: 'Kitob topilmadi!' });
        return;
      }
      broadcastStateChange('books:favorite');
      res.json(result);
    })
  );

  // ==========================================
  // STUDENTS (Admin CRUD + Bulk Import)
  // ==========================================
  app.post(
    '/api/students',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const data = req.body as Omit<Student, 'id' | 'registeredAt'>;
      if (!data.name?.trim()) {
        res.status(400).json({ error: 'Talaba ismi kiritilishi shart!' });
        return;
      }

      const { result } = await updateStateAsync((state) => {
        const studentId = (data.studentId || '').trim() || generateStudentId(state.students.length);
        if (state.students.some((s) => s.studentId.toLowerCase() === studentId.toLowerCase())) {
          return { error: `"${studentId}" ID raqamli talaba allaqachon mavjud!` };
        }
        const rawPass = (data.password || '').trim() || 'student123';
        const newStudent: Student = {
          ...data,
          id: `stu-${Date.now()}`,
          studentId,
          name: data.name.trim(),
          email: (data.email || '').trim() || `${studentId.toLowerCase()}@tdtu-chirchiq.uz`,
          registeredAt: new Date().toISOString().split('T')[0],
          password: hashPassword(rawPass),
          avatarUrl: (data.avatarUrl || '').trim(),
        };
        state.students = [newStudent, ...state.students];
        appendLog(
          state,
          'TALABA_YARATILDI',
          actor.name,
          actor.role,
          `Yangi talaba qo'shildi: ${newStudent.name} (${newStudent.studentId}, Yo'nalish: ${
            newStudent.specialtyCode || ''
          } ${newStudent.specialty})`
        );
        return { student: sanitizeStudent(newStudent) };
      });

      if ('error' in result) {
        res.status(409).json({ error: result.error });
        return;
      }
      broadcastStateChange('students:create');
      res.status(201).json(result.student);
    })
  );

  app.post(
    '/api/students/bulk',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const { items } = req.body as { items?: Array<Omit<Student, 'id' | 'registeredAt'>> };
      if (!Array.isArray(items) || items.length === 0) {
        res.status(400).json({ error: "Import uchun talabalar ro'yxati bo'sh!" });
        return;
      }

      const { result } = await updateStateAsync((state) => {
        const now = new Date().toISOString().split('T')[0];
        const base = Date.now();
        const existingIds = new Set(state.students.map((s) => s.studentId.toLowerCase()));
        const created: Student[] = [];

        items.forEach((item, idx) => {
          const sid = (item.studentId || '').trim() || generateStudentId(state.students.length + idx);
          if (existingIds.has(sid.toLowerCase())) return;
          existingIds.add(sid.toLowerCase());
          created.push({
            ...item,
            id: `stu-${base}-${idx}`,
            studentId: sid,
            registeredAt: now,
            password: hashPassword((item.password || '').trim() || 'student123'),
            avatarUrl: (item.avatarUrl || '').trim(),
          });
        });

        state.students = [...created, ...state.students];
        appendLog(
          state,
          'TALABALAR_IMPORT_QILINDI',
          actor.name,
          actor.role,
          `Excel orqali ${created.length} nafar yangi talaba tizimga import qilindi.`
        );
        return created.length;
      });

      broadcastStateChange('students:bulk');
      res.status(201).json({ count: result });
    })
  );

  app.patch(
    '/api/students/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const updates = req.body as Partial<Student>;
      const { result } = await updateStateAsync((state) => {
        const idx = state.students.findIndex((s) => s.id === req.params.id);
        if (idx === -1) return { status: 404, error: 'Talaba topilmadi!' };

        const existing = state.students[idx];
        if (
          updates.studentId &&
          updates.studentId.trim().toLowerCase() !== existing.studentId.toLowerCase() &&
          state.students.some(
            (s) => s.id !== existing.id && s.studentId.toLowerCase() === updates.studentId!.trim().toLowerCase()
          )
        ) {
          return { status: 409, error: `"${updates.studentId}" ID raqamli talaba allaqachon mavjud!` };
        }

        const nextPassword =
          updates.password && updates.password.trim()
            ? hashPassword(updates.password.trim())
            : existing.password;

        const updated: Student = {
          ...existing,
          ...updates,
          id: existing.id,
          password: nextPassword,
        };
        state.students[idx] = updated;

        state.loans = state.loans.map((l) =>
          l.studentId === updated.id
            ? {
                ...l,
                studentName: updated.name,
                studentGroup: updated.group,
                studentFaculty: updated.faculty,
              }
            : l
        );
        state.reservations = state.reservations.map((r) =>
          r.studentId === updated.id ? { ...r, studentName: updated.name } : r
        );

        appendLog(
          state,
          'TALABA_TAHRIRLANDI',
          actor.name,
          actor.role,
          `Talaba ma'lumotlari tahrirlandi: ${updated.name} (${updated.studentId})`
        );
        return { status: 200, student: sanitizeStudent(updated) };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('students:update');
      res.json(result.student);
    })
  );

  app.patch(
    '/api/students/:id/status',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const { result } = await updateStateAsync((state) => {
        const stu = state.students.find((s) => s.id === req.params.id);
        if (!stu) return null;
        stu.status = stu.status === 'active' ? 'blocked' : 'active';
        appendLog(
          state,
          'TALABA_TAHRIRLANDI',
          actor.name,
          actor.role,
          `Talaba holati o'zgartirildi: ${stu.name} (${stu.studentId}) → ${
            stu.status === 'active' ? 'Faol' : 'Bloklangan'
          }`
        );
        return stu.status;
      });

      if (!result) {
        res.status(404).json({ error: 'Talaba topilmadi!' });
        return;
      }
      broadcastStateChange('students:status');
      res.json({ status: result });
    })
  );

  app.delete(
    '/api/students/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const { result } = await updateStateAsync((state) => {
        const stu = state.students.find((s) => s.id === req.params.id);
        if (!stu) return { status: 404, error: 'Talaba topilmadi!' };
        const hasActive = state.loans.some((l) => l.studentId === stu.id && l.status !== 'returned');
        if (hasActive) {
          return {
            status: 400,
            error: "Talabada topshirilmagan kitoblar mavjud! Avval kitoblarni qaytarish zarur.",
          };
        }
        state.students = state.students.filter((s) => s.id !== stu.id);
        state.reservations = state.reservations.filter((r) => r.studentId !== stu.id);
        appendLog(
          state,
          'TALABA_OCHIRILDI',
          actor.name,
          actor.role,
          `Talaba hisobi o'chirildi: ${stu.name} (${stu.studentId})`
        );
        return { status: 200 };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('students:delete');
      res.json({ ok: true });
    })
  );

  // ==========================================
  // LIBRARIANS (Admin CRUD)
  // ==========================================
  app.post(
    '/api/librarians',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const { name, email, phone, department, shift, password, avatarUrl } =
        req.body as Partial<Librarian>;
      if (!name?.trim() || !email?.trim()) {
        res.status(400).json({ error: 'Xodim ismi va emaili kiritilishi shart!' });
        return;
      }

      const { result } = await updateStateAsync((state) => {
        if (state.librarians.some((l) => l.email.toLowerCase() === email.trim().toLowerCase())) {
          return { error: `"${email}" email bilan xodim allaqachon mavjud!` };
        }
        const created: Librarian = {
          id: `lib-${Date.now()}`,
          name: name.trim(),
          email: email.trim(),
          phone: (phone || '').trim() || '+998 70 200 00 00',
          department: (department || '').trim() || "Asosiy o'quv zali",
          shift: (shift || '').trim() || 'Kunduzgi (08:30 - 17:30)',
          avatarUrl: (avatarUrl || '').trim(),
          password: hashPassword((password || '').trim() || 'lib123'),
        };
        state.librarians = [created, ...state.librarians];
        appendLog(
          state,
          'XODIM_YARATILDI',
          actor.name,
          actor.role,
          `Yangi kutubxonachi qo'shildi: ${created.name} (${created.email})`
        );
        return { librarian: sanitizeLibrarian(created) };
      });

      if ('error' in result) {
        res.status(409).json({ error: result.error });
        return;
      }
      broadcastStateChange('librarians:create');
      res.status(201).json(result.librarian);
    })
  );

  app.patch(
    '/api/librarians/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const updates = req.body as Partial<Librarian>;
      const { result } = await updateStateAsync((state) => {
        const idx = state.librarians.findIndex((l) => l.id === req.params.id);
        if (idx === -1) return { status: 404, error: 'Xodim topilmadi!' };
        const existing = state.librarians[idx];
        const nextPass =
          updates.password && updates.password.trim()
            ? hashPassword(updates.password.trim())
            : existing.password;
        const updated: Librarian = {
          ...existing,
          ...updates,
          id: existing.id,
          password: nextPass,
        };
        state.librarians[idx] = updated;
        appendLog(
          state,
          'XODIM_TAHRIRLANDI',
          actor.name,
          actor.role,
          `Kutubxonachi ma'lumotlari tahrirlandi: ${updated.name} (${updated.email})`
        );
        return { status: 200, librarian: sanitizeLibrarian(updated) };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('librarians:update');
      res.json(result.librarian);
    })
  );

  app.delete(
    '/api/librarians/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const { result } = await updateStateAsync((state) => {
        const target = state.librarians.find((l) => l.id === req.params.id);
        if (!target) return { status: 404, error: 'Xodim topilmadi!' };
        state.librarians = state.librarians.filter((l) => l.id !== target.id);
        appendLog(
          state,
          'XODIM_OCHIRILDI',
          actor.name,
          actor.role,
          `Kutubxonachi hisobi o'chirildi: ${target.name} (${target.email})`
        );
        return { status: 200 };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('librarians:delete');
      res.json({ ok: true });
    })
  );

  // ==========================================
  // SITE SETTINGS (Admin)
  // ==========================================
  app.patch(
    '/api/site-settings',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin']);
      if (!actor) return;

      const incoming = req.body as Partial<SiteSettings>;
      if (!incoming || typeof incoming !== 'object') {
        res.status(400).json({ error: "Noto'g'ri sozlama ma'lumotlari." });
        return;
      }

      const { result } = await updateStateAsync((state) => {
        const updated = mergeSiteSettings(state.siteSettings, incoming);
        state.siteSettings = updated;
        appendLog(
          state,
          'SAYT_SOZLAMALARI_YANGILANDI',
          actor.name,
          actor.role,
          'Sayt sozlamalari (banner, footer, xizmatlar, qoidalar yoki aloqa) yangilandi.'
        );
        return updated;
      });

      broadcastStateChange('site-settings:update');
      res.json(result);
    })
  );

  // ==========================================
  // LOANS & RESERVATIONS
  // ==========================================
  app.post(
    '/api/loans/issue',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin', 'librarian']);
      if (!actor) return;

      const { bookId, bookIds, studentId, days, notes } = req.body as {
        bookId?: string;
        bookIds?: string[];
        studentId?: string;
        days?: number;
        notes?: string;
      };

      const requestedIds = Array.from(
        new Set(
          Array.isArray(bookIds) && bookIds.length > 0
            ? bookIds.filter((id): id is string => typeof id === 'string' && id.trim().length > 0)
            : bookId
            ? [bookId]
            : []
        )
      );

      const { result } = await updateStateAsync((state) => {
        const student = state.students.find((s) => s.id === studentId || s.studentId === studentId);
        if (!student) return { status: 404, error: 'Talaba topilmadi!' };
        if (requestedIds.length === 0) {
          return { status: 400, error: 'Iltimos, kamida bitta kitobni tanlang!' };
        }

        const selectedBooks: Book[] = [];
        for (const id of requestedIds) {
          const foundBook = state.books.find((b) => b.id === id);
          if (!foundBook) {
            return { status: 404, error: 'Tanlangan kitoblardan biri tizimda topilmadi!' };
          }
          selectedBooks.push(foundBook);
        }

        const studentActive = state.loans.filter(
          (l) => l.studentId === student.id && l.status !== 'returned'
        );
        const hasOverdue = studentActive.some((l) => l.status === 'overdue');

        const eligibility =
          selectedBooks.length === 1
            ? canIssueBook(selectedBooks[0], student, studentActive.length, hasOverdue)
            : canIssueMultipleBooks(selectedBooks, student, studentActive.length, hasOverdue);

        if (!eligibility.allowed) {
          return { status: 400, error: eligibility.reason || 'Kitob berish rad etildi' };
        }

        const loanDays = Number(days) || 14;
        const today = new Date();
        const issueDateStr = today.toISOString().split('T')[0];
        const dueDate = new Date(today);
        dueDate.setDate(dueDate.getDate() + loanDays);
        const dueDateStr = dueDate.toISOString().split('T')[0];

        const createdLoans: Loan[] = [];
        selectedBooks.forEach((book, idx) => {
          const newLoan: Loan = {
            id: `loan-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 5)}`,
            bookId: book.id,
            bookTitle: book.title,
            bookAuthor: book.author,
            bookCoverUrl: book.coverUrl,
            studentId: student.id,
            studentName: student.name,
            studentGroup: student.group,
            studentFaculty: student.faculty,
            librarianId: actor.role === 'librarian' ? actor.id : state.librarians[0]?.id || actor.id,
            librarianName: actor.name,
            issueDate: issueDateStr,
            dueDate: dueDateStr,
            status: 'active',
            fineAmount: 0,
            notes: notes || '',
            renewedCount: 0,
          };
          book.availableCopies = Math.max(0, book.availableCopies - 1);
          state.reservations = state.reservations.filter(
            (r) => !(r.bookId === book.id && r.studentId === student.id)
          );
          createdLoans.push(newLoan);
        });

        state.loans = [...createdLoans, ...state.loans];
        const titlesSummary = createdLoans.map((l) => `"${l.bookTitle}"`).join(', ');
        appendLog(
          state,
          'KITOB_BERILDI',
          actor.name,
          actor.role,
          `${createdLoans.length} ta kitob (${titlesSummary}) ${student.name}ga (${student.group}) ${loanDays} kunga ijaraga berildi.`
        );
        return { status: 201, loans: createdLoans, loan: createdLoans[0] };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('loans:issue');
      res.status(201).json(result.loans.length === 1 ? result.loan : { loans: result.loans, loan: result.loan });
    })
  );

  app.post(
    '/api/loans/:id/return',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['admin', 'librarian']);
      if (!actor) return;

      const { condition, notes } = req.body as {
        condition?: "a'lo" | 'yaxshi' | 'zararlangan' | "yo'qolgan";
        notes?: string;
      };

      const { result } = await updateStateAsync((state) => {
        const loan = state.loans.find((l) => l.id === req.params.id);
        if (!loan) return { status: 404, error: 'Ijara yozuvi topilmadi!' };
        if (loan.status === 'returned') {
          return { status: 400, error: 'Ushbu kitob allaqachon qaytarilgan!' };
        }

        const todayStr = new Date().toISOString().split('T')[0];
        const daysOverdue = calculateDaysOverdue(loan.dueDate);
        const calculatedFine = calculateFine(daysOverdue);
        const cond = condition || 'yaxshi';

        loan.returnDate = todayStr;
        loan.status = 'returned';
        loan.conditionOnReturn = cond;
        loan.fineAmount = calculatedFine;
        if (notes) {
          loan.notes = loan.notes ? `${loan.notes}; ${notes}` : notes;
        }

        const book = state.books.find((b) => b.id === loan.bookId);
        if (book) {
          if (cond !== "yo'qolgan") {
            book.availableCopies = Math.min(book.totalCopies, book.availableCopies + 1);
          } else {
            book.totalCopies = Math.max(0, book.totalCopies - 1);
          }
        }

        appendLog(
          state,
          'KITOB_QAYTARILDI',
          actor.name,
          actor.role,
          `"${loan.bookTitle}" kitobi ${loan.studentName} tomonidan qaytarildi. Holati: ${cond}.`
        );
        return { status: 200, loan };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('loans:return');
      res.json(result.loan);
    })
  );

  app.post(
    '/api/loans/:id/prolong',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireAuth(req, res);
      if (!actor) return;

      const extraDays = Number((req.body as { extraDays?: number })?.extraDays || 7);

      const { result } = await updateStateAsync((state) => {
        const loan = state.loans.find((l) => l.id === req.params.id);
        if (!loan || loan.status === 'returned') {
          return { status: 400, error: 'Ijara yozuvi yaroqsiz!' };
        }
        if (actor.role === 'student' && loan.studentId !== actor.id) {
          return { status: 403, error: "Faqat o'z kitobingiz muddatini uzaytirishingiz mumkin!" };
        }
        if (loan.renewedCount >= 2) {
          return { status: 400, error: "Kitob muddatini ko'pi bilan 2 marta uzaytirish mumkin!" };
        }

        const currentDue = new Date(loan.dueDate);
        currentDue.setDate(currentDue.getDate() + extraDays);
        const newDueDateStr = currentDue.toISOString().split('T')[0];

        loan.dueDate = newDueDateStr;
        loan.status = calculateLoanStatus(newDueDateStr);
        loan.fineAmount = 0;
        loan.renewedCount += 1;

        appendLog(
          state,
          'MUDDAT_UZAYTIRILDI',
          actor.name,
          actor.role,
          `"${loan.bookTitle}" (${loan.studentName}) muddati +${extraDays} kunga uzaytirildi.`
        );
        return { status: 200, loan };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('loans:prolong');
      res.json(result.loan);
    })
  );

  app.post(
    '/api/reservations',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireRole(req, res, ['student', 'admin', 'librarian']);
      if (!actor) return;

      const { bookId, studentId } = req.body as { bookId?: string; studentId?: string };
      const targetStudentId = actor.role === 'student' ? actor.id : studentId || actor.id;

      const { result } = await updateStateAsync((state) => {
        const book = state.books.find((b) => b.id === bookId);
        const student = state.students.find((s) => s.id === targetStudentId);
        if (!book || !student) return { status: 404, error: "Ma'lumot topilmadi!" };

        const existing = state.reservations.find(
          (r) => r.bookId === book.id && r.studentId === student.id && r.status === 'kutilmoqda'
        );
        if (existing) {
          return { status: 409, error: 'Siz allaqachon ushbu kitobni band qilgansiz!' };
        }

        const today = new Date();
        const expiry = new Date(today);
        expiry.setDate(expiry.getDate() + 3);

        const newRes: Reservation = {
          id: `res-${Date.now()}`,
          bookId: book.id,
          bookTitle: book.title,
          studentId: student.id,
          studentName: student.name,
          requestDate: today.toISOString().split('T')[0],
          expiryDate: expiry.toISOString().split('T')[0],
          status: 'kutilmoqda',
        };

        state.reservations = [newRes, ...state.reservations];
        appendLog(
          state,
          'BRON_QILINDI',
          actor.name,
          actor.role,
          `Talaba ${student.name} "${book.title}" kitobini 3 kunga band qildi.`
        );
        return { status: 201, reservation: newRes };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('reservations:create');
      res.status(201).json(result.reservation);
    })
  );

  app.delete(
    '/api/reservations/:id',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireAuth(req, res);
      if (!actor) return;

      const { result } = await updateStateAsync((state) => {
        const target = state.reservations.find((r) => r.id === req.params.id);
        if (!target) return { status: 404, error: 'Buyurtma topilmadi!' };
        if (actor.role === 'student' && target.studentId !== actor.id) {
          return { status: 403, error: 'Ruxsat rad etildi!' };
        }
        state.reservations = state.reservations.filter((r) => r.id !== target.id);
        appendLog(
          state,
          'BRON_OCHIRILDI',
          actor.name,
          actor.role,
          `Kitob band qilinishi bekor qilindi: "${target.bookTitle}" (${target.studentName})`
        );
        return { status: 200 };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      broadcastStateChange('reservations:delete');
      res.json({ ok: true });
    })
  );

  // ==========================================
  // PROFILE & PASSWORD
  // ==========================================
  app.patch(
    '/api/profile',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireAuth(req, res);
      if (!actor) return;

      const { name, email, phone, avatarUrl } = req.body as {
        name?: string;
        email?: string;
        phone?: string;
        avatarUrl?: string;
      };

      await updateStateAsync((state) => {
        const updates: { name?: string; email?: string; phone?: string; avatarUrl?: string } = {};
        if (name?.trim()) updates.name = name.trim();
        if (email?.trim()) updates.email = email.trim();
        if (phone !== undefined) updates.phone = phone.trim();
        if (avatarUrl !== undefined) updates.avatarUrl = avatarUrl.trim();

        const nextName = updates.name || actor.name;

        if (actor.role === 'admin') {
          state.adminAccount = { ...state.adminAccount, ...updates };
        } else if (actor.role === 'librarian') {
          state.librarians = state.librarians.map((l) =>
            l.id === actor.id ? { ...l, ...updates } : l
          );
          if (updates.name) {
            state.loans = state.loans.map((l) =>
              l.librarianId === actor.id ? { ...l, librarianName: updates.name! } : l
            );
          }
        } else {
          state.students = state.students.map((s) =>
            s.id === actor.id ? { ...s, ...updates } : s
          );
          if (updates.name) {
            state.loans = state.loans.map((l) =>
              l.studentId === actor.id ? { ...l, studentName: updates.name! } : l
            );
            state.reservations = state.reservations.map((r) =>
              r.studentId === actor.id ? { ...r, studentName: updates.name! } : r
            );
          }
        }

        appendLog(
          state,
          'PROFIL_YANGILANDI',
          nextName,
          actor.role,
          `${nextName} shaxsiy profil ma'lumotlarini (F.I.Sh. / aloqa / rasm) yangiladi.`
        );
      });

      broadcastStateChange('profile:update');
      res.json({ ok: true });
    })
  );

  app.post(
    '/api/profile/password',
    wrapAsync(async (req: AuthedRequest, res) => {
      const actor = requireAuth(req, res);
      if (!actor) return;

      const { oldPass, newPass } = req.body as { oldPass?: string; newPass?: string };
      if (!newPass || newPass.length < 4) {
        res.status(400).json({ error: "Yangi parol kamida 4 ta belgidan iborat bo'lishi kerak!" });
        return;
      }

      const { result } = await updateStateAsync((state) => {
        if (actor.role === 'admin') {
          if (!verifyPassword(oldPass || '', state.adminAccount.password || '')) {
            return { status: 400, error: "Eski parol noto'g'ri kiritildi!" };
          }
          state.adminAccount.password = hashPassword(newPass);
          appendLog(
            state,
            'PROFIL_YANGILANDI',
            actor.name,
            actor.role,
            'Administrator kirish parolini yangiladi.'
          );
          return { status: 200 };
        }
        if (actor.role === 'librarian') {
          const lib = state.librarians.find((l) => l.id === actor.id);
          if (!lib || !verifyPassword(oldPass || '', lib.password || '')) {
            return { status: 400, error: "Eski parol noto'g'ri kiritildi!" };
          }
          lib.password = hashPassword(newPass);
          appendLog(
            state,
            'PROFIL_YANGILANDI',
            actor.name,
            actor.role,
            `${lib.name} kirish parolini yangiladi.`
          );
          return { status: 200 };
        }
        const stu = state.students.find((s) => s.id === actor.id);
        if (!stu || !verifyPassword(oldPass || '', stu.password || '')) {
          return { status: 400, error: "Eski parol noto'g'ri kiritildi!" };
        }
        stu.password = hashPassword(newPass);
        appendLog(
          state,
          'PROFIL_YANGILANDI',
          actor.name,
          actor.role,
          `Talaba ${stu.name} (${stu.studentId}) kirish parolini yangiladi.`
        );
        return { status: 200 };
      });

      if ('error' in result) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      res.json({ ok: true });
    })
  );

  // API JSON Error Handler
  app.use(
    '/api',
    (
      err: unknown,
      _req: express.Request,
      res: express.Response,
      _next: express.NextFunction
    ) => {
      console.error('API Error:', err);
      const message = err instanceof Error ? err.message : 'Server xatoligi yuz berdi';
      if (!res.headersSent) {
        res.status(500).json({ error: message });
      }
    }
  );

  // Mount Vite middleware in dev or serve dist in production
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found. Run npm run build.');
      }
    });
  }

  const port = Number(process.env.PORT) || 3000;
  httpServer.listen(port, '0.0.0.0', () => {
    console.log(`TDTU Chirchiq filiali Elektron Kutubxona server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
