import React, { useEffect, useState } from 'react';
import { ChevronDown, ChevronRight, Menu, X } from 'lucide-react';

export interface SidebarSubMenuItem {
  id: string;
  label: string;
  icon?: React.ReactNode;
}

export interface SidebarMenuItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  badge?: number | string;
  children?: SidebarSubMenuItem[];
}

interface DashboardLayoutProps {
  accentColor: 'purple' | 'blue' | 'emerald';
  panelTitle: string;
  panelSubtitle?: string;
  menuItems: SidebarMenuItem[];
  activeMenuId: string;
  onSelectMenu: (id: string) => void;
  sidebarFooter?: React.ReactNode;
  children: React.ReactNode;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  accentColor,
  panelTitle,
  panelSubtitle,
  menuItems,
  activeMenuId,
  onSelectMenu,
  sidebarFooter,
  children,
}) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [expandedParents, setExpandedParents] = useState<Record<string, boolean>>({});

  useEffect(() => {
    for (const item of menuItems) {
      if (item.children?.some((c) => c.id === activeMenuId)) {
        setExpandedParents((prev) => (prev[item.id] ? prev : { ...prev, [item.id]: true }));
      }
    }
  }, [activeMenuId, menuItems]);

  const accentStyles = {
    purple: {
      activeItem: 'bg-purple-600 text-white shadow-md shadow-purple-600/20',
      activeParent: 'bg-purple-50 text-purple-800 border border-purple-200',
      activeSubItem: 'bg-purple-600 text-white shadow-xs',
      activeBadge: 'bg-white/20 text-white',
      inactiveBadge: 'bg-purple-50 text-purple-700',
      headerBadge: 'bg-purple-50 text-purple-700 border-purple-200',
      mobileBtn: 'bg-purple-600 text-white',
    },
    blue: {
      activeItem: 'bg-blue-600 text-white shadow-md shadow-blue-600/20',
      activeParent: 'bg-blue-50 text-blue-800 border border-blue-200',
      activeSubItem: 'bg-blue-600 text-white shadow-xs',
      activeBadge: 'bg-white/20 text-white',
      inactiveBadge: 'bg-blue-50 text-blue-700',
      headerBadge: 'bg-blue-50 text-blue-700 border-blue-200',
      mobileBtn: 'bg-blue-600 text-white',
    },
    emerald: {
      activeItem: 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20',
      activeParent: 'bg-emerald-50 text-emerald-800 border border-emerald-200',
      activeSubItem: 'bg-emerald-600 text-white shadow-xs',
      activeBadge: 'bg-white/20 text-white',
      inactiveBadge: 'bg-emerald-50 text-emerald-700',
      headerBadge: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      mobileBtn: 'bg-emerald-600 text-white',
    },
  }[accentColor];

  let activeItemLabel = menuItems.find((m) => m.id === activeMenuId)?.label;
  if (!activeItemLabel) {
    for (const item of menuItems) {
      const sub = item.children?.find((c) => c.id === activeMenuId);
      if (sub) {
        activeItemLabel = `${item.label} • ${sub.label}`;
        break;
      }
    }
  }

  const renderMenuList = (isMobile = false) => (
    <nav aria-label={panelTitle} className="space-y-1.5">
      {menuItems.map((item) => {
        const hasChildren = Boolean(item.children && item.children.length > 0);
        const childActive = Boolean(item.children?.some((c) => c.id === activeMenuId));
        const isExpanded = Boolean(expandedParents[item.id] || childActive);
        const isActive = item.id === activeMenuId;

        if (hasChildren && item.children) {
          return (
            <div key={item.id} className="space-y-1">
              <button
                type="button"
                aria-expanded={isExpanded}
                onClick={() => {
                  if (!isExpanded && !childActive) {
                    setExpandedParents((prev) => ({ ...prev, [item.id]: true }));
                    onSelectMenu(item.children![0].id);
                  } else {
                    setExpandedParents((prev) => ({ ...prev, [item.id]: !isExpanded }));
                  }
                }}
                className={`w-full flex items-center justify-between gap-2.5 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all text-left ${
                  childActive
                    ? accentStyles.activeParent
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <span className="flex items-center gap-2.5 min-w-0">
                  <span className="flex-shrink-0">{item.icon}</span>
                  <span className="truncate">{item.label}</span>
                </span>
                {isExpanded ? (
                  <ChevronDown className="w-4 h-4 flex-shrink-0 opacity-70" />
                ) : (
                  <ChevronRight className="w-4 h-4 flex-shrink-0 opacity-70" />
                )}
              </button>

              {isExpanded && (
                <div className="pl-4 ml-3 border-l border-slate-200 space-y-1">
                  {item.children.map((sub) => {
                    const subIsActive = sub.id === activeMenuId;
                    return (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => {
                          onSelectMenu(sub.id);
                          if (isMobile) setMobileOpen(false);
                        }}
                        className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold transition-all text-left ${
                          subIsActive
                            ? accentStyles.activeSubItem
                            : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                        }`}
                      >
                        {sub.icon && <span className="flex-shrink-0">{sub.icon}</span>}
                        <span className="truncate">{sub.label}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        }

        return (
          <button
            key={item.id}
            type="button"
            onClick={() => {
              onSelectMenu(item.id);
              if (isMobile) setMobileOpen(false);
            }}
            className={`w-full flex items-center justify-between gap-2.5 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all text-left ${
              isActive
                ? accentStyles.activeItem
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <span className="flex items-center gap-2.5 min-w-0">
              <span className="flex-shrink-0">{item.icon}</span>
              <span className="truncate">{item.label}</span>
            </span>
            {item.badge !== undefined && (
              <span
                className={`px-2 py-0.5 rounded-lg text-[11px] font-bold tabular-nums flex-shrink-0 ${
                  isActive ? accentStyles.activeBadge : accentStyles.inactiveBadge
                }`}
              >
                {item.badge}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );

  return (
    <div className="flex flex-col lg:flex-row gap-6 items-start">
      {/* Mobile Sidebar Bar */}
      <div className="w-full lg:hidden flex items-center justify-between bg-white px-4 py-3 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className={`px-2.5 py-1 rounded-lg text-xs font-bold border ${accentStyles.headerBadge}`}>
            {panelTitle}
          </span>
          <span className="text-sm font-bold text-slate-800 truncate">
            {activeItemLabel}
          </span>
        </div>
        <button
          type="button"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Menyuni ochish"
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold ${accentStyles.mobileBtn}`}
        >
          {mobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          <span>Menyu</span>
        </button>
      </div>

      {/* Mobile Dropdown Drawer */}
      {mobileOpen && (
        <div className="w-full lg:hidden bg-white rounded-2xl border border-slate-200 shadow-md p-3 space-y-3">
          {renderMenuList(true)}
          {sidebarFooter && <div className="pt-3 border-t border-slate-100">{sidebarFooter}</div>}
        </div>
      )}

      {/* Desktop Left Sidebar */}
      <aside className="hidden lg:flex flex-col w-68 xl:w-72 flex-shrink-0 bg-white rounded-2xl border border-slate-200 shadow-xs p-4 sticky top-20 space-y-4">
        <div className="pb-3 border-b border-slate-100">
          <div className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-[11px] font-bold border ${accentStyles.headerBadge}`}>
            {panelTitle}
          </div>
          {panelSubtitle && (
            <p className="text-xs text-slate-500 mt-1.5 leading-snug">{panelSubtitle}</p>
          )}
        </div>

        {renderMenuList(false)}

        {sidebarFooter && (
          <div className="pt-3 border-t border-slate-100">
            {sidebarFooter}
          </div>
        )}
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 w-full space-y-6">
        {children}
      </div>
    </div>
  );
};
