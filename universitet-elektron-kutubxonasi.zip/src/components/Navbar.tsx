import React from 'react';
import { useLibrary } from '../context/LibraryContext';
import type { UserRole } from '../types/library';
import { UserAvatar } from './common/UserAvatar';
import {
  GraduationCap,
  Shield,
  BookOpen,
  AlertTriangle,
  LogOut,
  Home,
} from 'lucide-react';

interface NavbarProps {
  onOpenOverdue?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenOverdue }) => {
  const {
    activeRole,
    currentUser,
    loans,
    siteSettings,
    setCurrentView,
    setShowProfileModal,
    logout,
  } = useLibrary();

  if (!currentUser || !activeRole) return null;

  const overdueLoansCount = loans.filter((l) => l.status === 'overdue').length;

  const roleLabels: Record<UserRole, { label: string; icon: React.ReactNode; badgeClass: string }> = {
    admin: {
      label: 'Administrator Paneli',
      icon: <Shield className="w-3.5 h-3.5" />,
      badgeClass: 'bg-purple-500/25 text-purple-100 border-purple-300/40 shadow-[0_0_12px_rgba(192,132,252,0.28)]',
    },
    librarian: {
      label: 'Kutubxonachi Paneli',
      icon: <BookOpen className="w-3.5 h-3.5" />,
      badgeClass: 'bg-cyan-500/20 text-cyan-100 border-cyan-300/40 shadow-[0_0_12px_rgba(34,211,238,0.28)]',
    },
    student: {
      label: 'Talaba Kabineti',
      icon: <GraduationCap className="w-3.5 h-3.5" />,
      badgeClass: 'bg-emerald-500/20 text-emerald-100 border-emerald-300/40 shadow-[0_0_12px_rgba(52,211,153,0.28)]',
    },
  };

  const roleMeta = roleLabels[activeRole];

  return (
    <header className="sticky top-0 z-40 bg-linear-to-r from-slate-950 via-blue-950 to-indigo-950 border-b-2 border-cyan-400/35 shadow-xl text-white">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between min-h-17 py-2 gap-3">
          {/* Logo & Portal Home Link */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setCurrentView('landing')}
              title="Kutubxona bosh sahifasiga o'tish"
              className="flex items-center gap-2.5 text-left group min-w-0"
            >
              {siteSettings.header.logoUrl ? (
                <div className="w-11 h-11 rounded-full bg-white p-0.5 ring-2 ring-cyan-300/70 shadow-[0_0_16px_rgba(34,211,238,0.45)] flex-shrink-0 overflow-hidden">
                  <img
                    src={siteSettings.header.logoUrl}
                    alt={siteSettings.header.brandName}
                    className="w-full h-full rounded-full object-contain"
                  />
                </div>
              ) : (
                <div className="w-10 h-10 rounded-full bg-linear-to-br from-cyan-500 via-blue-600 to-indigo-700 flex items-center justify-center text-white ring-2 ring-cyan-300/60 shadow-[0_0_14px_rgba(34,211,238,0.4)] flex-shrink-0">
                  <GraduationCap className="w-5 h-5" />
                </div>
              )}
              <span className="font-extrabold text-xs sm:text-sm lg:text-base text-white tracking-tight group-hover:text-cyan-200 transition-colors line-clamp-2 lg:whitespace-nowrap">
                {siteSettings.header.brandName}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setCurrentView('landing')}
              className="hidden lg:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-cyan-300/35 bg-blue-900/50 hover:bg-blue-700/75 text-white text-xs font-semibold shadow-[0_0_12px_rgba(56,189,248,0.22)] hover:shadow-[0_0_18px_rgba(56,189,248,0.45)] transition-all whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Home className="w-3.5 h-3.5 text-cyan-300" />
              <span>Bosh sahifa</span>
            </button>
          </div>

          {/* Authenticated Role Badge */}
          <div className="hidden xl:flex items-center shrink-0">
            <span
              className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border text-xs font-bold ${roleMeta.badgeClass}`}
            >
              {roleMeta.icon}
              <span>{roleMeta.label}</span>
            </span>
          </div>

          {/* Right section: Overdue alert, Profile & Logout */}
          <div className="flex items-center gap-2 shrink-0">
            {overdueLoansCount > 0 && activeRole !== 'student' && (
              <button
                type="button"
                onClick={onOpenOverdue}
                title="Muddati o'tgan talabalar ro'yxatini ko'rish"
                className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/35 text-rose-100 border border-rose-400/50 text-xs font-semibold shadow-[0_0_14px_rgba(244,63,94,0.3)] transition-all cursor-pointer"
              >
                <AlertTriangle className="w-3.5 h-3.5 text-rose-300" />
                <span>{overdueLoansCount} kechikkan</span>
              </button>
            )}

            {/* Profile trigger button */}
            <button
              type="button"
              onClick={() => setShowProfileModal(true)}
              title="Profil panelini ochish"
              data-testid="navbar-profile-button"
              className="flex items-center gap-2 p-1.5 pr-3 rounded-xl bg-white/10 hover:bg-white/20 border border-cyan-300/35 shadow-[0_0_12px_rgba(56,189,248,0.2)] transition-all text-left cursor-pointer"
            >
              <UserAvatar
                name={currentUser.name}
                avatarUrl={currentUser.avatarUrl}
                sizeClass="w-8 h-8"
                textClass="text-xs"
                roundedClass="rounded-lg"
                className="ring-1 ring-white/40"
              />
              <div className="hidden md:block">
                <div className="text-xs font-bold text-white leading-tight max-w-[160px] truncate">
                  {currentUser.name}
                </div>
                <div className="text-[10px] text-cyan-300 font-semibold">
                  Mening profilim
                </div>
              </div>
            </button>

            {/* Logout button */}
            <button
              type="button"
              onClick={logout}
              title="Tizimdan chiqish"
              aria-label="Chiqish"
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-rose-300/40 bg-rose-500/20 hover:bg-rose-600/80 text-white text-xs font-semibold shadow-[0_0_12px_rgba(244,63,94,0.22)] transition-all cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Chiqish</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
