import React, { useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import type { Loan } from '../../types/library';
import {
  calculateDaysOverdue,
  calculateFine,
  formatUzbekCurrency,
  formatUzbekDate,
} from '../../utils/libraryRules';
import { X, CheckCircle2, AlertTriangle, BookCheck } from 'lucide-react';

interface ReturnBookModalProps {
  loan: Loan;
  onClose: () => void;
}

export const ReturnBookModal: React.FC<ReturnBookModalProps> = ({ loan, onClose }) => {
  const { returnBook } = useLibrary();

  const daysOverdue = calculateDaysOverdue(loan.dueDate);
  const overdueFine = calculateFine(daysOverdue);

  const [condition, setCondition] = useState<"a'lo" | 'yaxshi' | 'zararlangan' | "yo'qolgan">("a'lo");
  const [notes, setNotes] = useState('');
  const [finePaid, setFinePaid] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const damagePenalty = condition === 'zararlangan' ? 50000 : condition === "yo'qolgan" ? 150000 : 0;
  const totalFine = overdueFine + damagePenalty;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await returnBook({
        loanId: loan.id,
        condition,
        notes: notes.trim()
          ? `${notes.trim()}${
              totalFine > 0
                ? ` (Jarima: ${formatUzbekCurrency(totalFine)} ${finePaid ? "to'landi" : 'qarzdor'})`
                : ''
            }`
          : totalFine > 0
          ? `Jarima: ${formatUzbekCurrency(totalFine)} ${finePaid ? "to'landi" : 'qarzdor'}`
          : undefined,
      });
      if (res.success) {
        onClose();
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-linear-to-r from-emerald-700 to-teal-700 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/20 backdrop-blur-xs">
              <BookCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-lg">Kitobni qabul qilish</h2>
              <p className="text-xs text-emerald-100">Kutubxonaga kitobni qaytarib olish va ro'yxatdan chiqarish</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Yopish"
            className="p-1.5 rounded-lg hover:bg-white/20 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Book & Student Summary */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex gap-3">
            <img
              src={loan.bookCoverUrl}
              alt={loan.bookTitle}
              className="w-14 h-18 object-cover rounded-lg shadow-xs flex-shrink-0"
            />
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-sm text-slate-900 line-clamp-1">{loan.bookTitle}</h3>
              <p className="text-xs text-slate-500">{loan.bookAuthor}</p>

              <div className="mt-2 text-xs text-slate-700 space-y-0.5">
                <div>
                  Talaba: <span className="font-bold">{loan.studentName}</span> ({loan.studentGroup})
                </div>
                <div className="text-[11px] text-slate-500">
                  Olingan sana: {formatUzbekDate(loan.issueDate)} • Topshirish muddati:{' '}
                  {formatUzbekDate(loan.dueDate)}
                </div>
              </div>
            </div>
          </div>

          {/* Overdue Warning & Fine Alert */}
          {daysOverdue > 0 && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
              <div className="text-xs">
                <div className="font-bold text-rose-900">
                  Topshirish muddati {daysOverdue} kunga kechikkan!
                </div>
                <div className="text-rose-700 mt-0.5">
                  Kechikish jarimasi (kuniga 2,000 so'mdan):{' '}
                  <span className="font-bold text-sm">{formatUzbekCurrency(overdueFine)}</span>
                </div>
              </div>
            </div>
          )}

          {/* Book Condition Picker */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Qaytarilgan kitob holati *
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: "a'lo", label: "A'lo (yangi kabi)", desc: 'Hech qanday zararsiz' },
                { id: 'yaxshi', label: 'Yaxshi', desc: 'Tabiiy ishlatilgan' },
                { id: 'zararlangan', label: 'Zararlangan', desc: "+50,000 so'm jarima" },
                { id: "yo'qolgan", label: "Yo'qolgan", desc: "+150,000 so'm qoplama" },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setCondition(item.id as typeof condition)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    condition === item.id
                      ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-500/20'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="font-bold text-xs text-slate-900">{item.label}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">{item.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {totalFine > 0 && (
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs flex items-center justify-between">
              <div>
                <span className="font-semibold text-amber-900">Jami jarima / to'lov:</span>
                <span className="font-bold text-amber-950 ml-2 text-sm">{formatUzbekCurrency(totalFine)}</span>
              </div>
              <label className="flex items-center gap-2 cursor-pointer font-medium text-amber-900">
                <input
                  type="checkbox"
                  checked={finePaid}
                  onChange={(e) => setFinePaid(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span>To'lov qabul qilindi</span>
              </label>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Qabul qilish izohi (ixtiyoriy)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
              placeholder="Masalan: Kitob toza qaytarildi, javonga joylashtirildi"
            />
          </div>

          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-colors"
            >
              Bekor qilish
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold shadow-md shadow-emerald-500/20 transition-all"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'Saqlanmoqda...' : 'Qaytarib olishni tasdiqlash'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
