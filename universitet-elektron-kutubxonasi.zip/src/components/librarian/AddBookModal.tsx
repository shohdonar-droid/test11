import React, { useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import type { Book } from '../../types/library';
import { formatFileSize, readFileAsDataUrl } from '../../utils/fileStorage';
import { X, BookPlus, Check, AlertCircle, Image as ImageIcon, FileText, Upload, Pencil, Download, Lock } from 'lucide-react';

interface AddBookModalProps {
  onClose: () => void;
  editingBook?: Book;
}

const DEFAULT_COVER =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 320"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#1e3a8a"/><stop offset="100%" stop-color="#0f172a"/></linearGradient></defs><rect width="240" height="320" rx="16" fill="url(#g)"/><rect x="18" y="18" width="204" height="284" rx="10" fill="none" stroke="#38bdf8" stroke-opacity="0.45" stroke-width="2"/><text x="120" y="148" text-anchor="middle" fill="#e0f2fe" font-family="sans-serif" font-size="18" font-weight="bold">TDTU</text><text x="120" y="176" text-anchor="middle" fill="#7dd3fc" font-family="sans-serif" font-size="13">ELEKTRON KITOB</text></svg>`
  );

async function resizeImageToDataUrl(file: File, maxWidth = 420): Promise<string> {
  const dataUrl = await readFileAsDataUrl(file);
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxWidth / img.width);
      const w = Math.round(img.width * scale);
      const h = Math.round(img.height * scale);
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', 0.82));
      } else {
        resolve(dataUrl);
      }
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

export const AddBookModal: React.FC<AddBookModalProps> = ({ onClose, editingBook }) => {
  const { addBook, updateBook, uploadServerFile, categories } = useLibrary();

  const isEditMode = Boolean(editingBook);

  const [title, setTitle] = useState(editingBook?.title || '');
  const [author, setAuthor] = useState(editingBook?.author || '');
  const [isbn, setIsbn] = useState(
    editingBook?.isbn ||
      `978-9943-${Math.floor(10 + Math.random() * 89)}-${Math.floor(100 + Math.random() * 899)}-1`
  );
  const [category, setCategory] = useState(
    editingBook?.category || categories[0]?.name || ''
  );
  const [year, setYear] = useState(editingBook?.year || 2024);
  const [pages, setPages] = useState(editingBook?.pages || 320);
  const [totalCopies, setTotalCopies] = useState(editingBook?.totalCopies || 10);
  const [building, setBuilding] = useState(editingBook?.location?.building || 'Bosh bino (A blok)');
  const [floor, setFloor] = useState(editingBook?.location?.floor || 2);
  const [shelf, setShelf] = useState(editingBook?.location?.shelf || 'Javon 18');
  const [section, setSection] = useState(editingBook?.location?.section || 'Tokcha B-2');
  const [coverUrl, setCoverUrl] = useState(editingBook?.coverUrl || DEFAULT_COVER);
  const [coverDataUrl, setCoverDataUrl] = useState<string | null>(null);
  const [coverFileName, setCoverFileName] = useState('');
  const [pdfFile, setPdfFile] = useState<{ id?: string; name: string; size: number; mimeType?: string } | null>(
    editingBook?.pdfFileId && editingBook?.pdfFileName
      ? { id: editingBook.pdfFileId, name: editingBook.pdfFileName, size: editingBook.pdfFileSize || 0 }
      : null
  );
  const [pdfDataUrl, setPdfDataUrl] = useState<string | null>(null);
  const [allowPdfDownload, setAllowPdfDownload] = useState<boolean>(
    Boolean(editingBook?.allowPdfDownload)
  );
  const [description, setDescription] = useState(editingBook?.description || '');
  const [sampleChapterContent, setSampleChapterContent] = useState(
    editingBook?.ebookChapters?.[0]?.content || ''
  );
  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Muqova uchun faqat rasm faylini (JPG, PNG, WEBP) tanlang!');
      return;
    }
    setError('');
    try {
      const optimized = await resizeImageToDataUrl(file);
      setCoverUrl(optimized);
      setCoverDataUrl(optimized);
      setCoverFileName(file.name);
    } catch {
      setError("Muqova rasmini o'qishda xatolik yuz berdi.");
    }
  };

  const handlePdfUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
      setError('Elektron variant uchun faqat PDF (.pdf) faylini yuklang!');
      return;
    }
    setError('');
    try {
      const dataUrl = await readFileAsDataUrl(file);
      setPdfDataUrl(dataUrl);
      setPdfFile({ name: file.name, size: file.size, mimeType: 'application/pdf' });
    } catch {
      setError('PDF faylini yuklashda xatolik yuz berdi.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!title.trim() || !author.trim()) {
      setError('Iltimos, kitob nomi va muallifini kiriting!');
      return;
    }
    if (!category) {
      setError('Iltimos, kitob kategoriyasini tanlang!');
      return;
    }

    setIsSaving(true);
    try {
      let finalCoverUrl = coverUrl.trim() || DEFAULT_COVER;
      if (coverDataUrl && coverFileName) {
        const uploadedCover = await uploadServerFile(coverDataUrl, coverFileName, 'image/jpeg');
        if (!uploadedCover) {
          setError('Muqova rasmini serverga yuklashda xatolik yuz berdi.');
          return;
        }
        finalCoverUrl = uploadedCover.url;
      }

      let finalPdfId = editingBook?.pdfFileId;
      let finalPdfName = editingBook?.pdfFileName;
      let finalPdfSize = editingBook?.pdfFileSize;

      if (pdfDataUrl && pdfFile) {
        const uploadedPdf = await uploadServerFile(pdfDataUrl, pdfFile.name, 'application/pdf');
        if (!uploadedPdf) {
          setError('PDF faylini serverga yuklashda xatolik yuz berdi.');
          return;
        }
        finalPdfId = uploadedPdf.id;
        finalPdfName = uploadedPdf.fileName;
        finalPdfSize = uploadedPdf.size;
      }

      if (editingBook) {
        const borrowedCount = Math.max(0, editingBook.totalCopies - editingBook.availableCopies);
        const nextTotal = Math.max(borrowedCount, Number(totalCopies));
        const nextAvailable = Math.max(0, nextTotal - borrowedCount);

        const res = await updateBook(editingBook.id, {
          title: title.trim(),
          author: author.trim(),
          isbn: isbn.trim(),
          category,
          year: Number(year),
          pages: Number(pages),
          totalCopies: nextTotal,
          availableCopies: nextAvailable,
          location: {
            building,
            floor: Number(floor),
            shelf,
            section,
          },
          coverUrl: finalCoverUrl,
          description:
            description.trim() ||
            `${title} — universitet talabalari va tadqiqotchilari uchun mo'ljallangan darslik.`,
          allowPdfDownload,
          pdfFileId: finalPdfId,
          pdfFileName: finalPdfName,
          pdfFileSize: finalPdfSize,
          ebookChapters: sampleChapterContent.trim()
            ? [
                {
                  id: editingBook.ebookChapters?.[0]?.id || 'ch-intro',
                  title: editingBook.ebookChapters?.[0]?.title || '1-bob: Kirish va fan asoslari',
                  content: sampleChapterContent.trim(),
                },
                ...(editingBook.ebookChapters?.slice(1) || []),
              ]
            : editingBook.ebookChapters,
        });
        if (!res.success) {
          setError(res.message);
          return;
        }
      } else {
        const res = await addBook({
          title: title.trim(),
          author: author.trim(),
          isbn: isbn.trim(),
          barcode: `INV-${year}-${Math.floor(1000 + Math.random() * 9000)}`,
          category,
          year: Number(year),
          pages: Number(pages),
          totalCopies: Number(totalCopies),
          availableCopies: Number(totalCopies),
          location: {
            building,
            floor: Number(floor),
            shelf,
            section,
          },
          coverUrl: finalCoverUrl,
          description:
            description.trim() ||
            `${title} — universitet talabalari va tadqiqotchilari uchun mo'ljallangan darslik.`,
          language: "O'zbek tili (Lotin)",
          isEbookAvailable: true,
          allowPdfDownload,
          pdfFileId: finalPdfId,
          pdfFileName: finalPdfName,
          pdfFileSize: finalPdfSize,
          rating: 4.8,
          ebookChapters: [
            {
              id: 'ch-intro',
              title: '1-bob: Kirish va fan asoslari',
              content:
                sampleChapterContent.trim() ||
                `${title} fani bo'yicha kirish ma'ruzasi.\n\nUshbu darslik "${category}" kategoriyasi bo'yicha talabalarga amaliy va nazariy bilim berishga qaratilgan.`,
            },
          ],
        });
        if (!res.success) {
          setError(res.message);
          return;
        }
      }

      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-linear-to-r from-blue-700 to-indigo-700 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/20 backdrop-blur-xs">
              {isEditMode ? <Pencil className="w-5 h-5 text-white" /> : <BookPlus className="w-5 h-5 text-white" />}
            </div>
            <div>
              <h2 className="font-bold text-lg">
                {isEditMode ? "Kitob ma'lumotlarini tahrirlash" : "Fondga yangi kitob qo'shish"}
              </h2>
              <p className="text-xs text-blue-200">Kategoriya, muqova rasmi va PDF faylini yuklash</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Yopish"
            className="p-1.5 rounded-lg hover:bg-white/20 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form id="add-book-form" onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-semibold">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Category Selection (no faculty assignment for books) */}
          <div>
            <label htmlFor="book-category-select" className="block text-xs font-semibold text-slate-700 mb-1">
              Kitob kategoriyasi *
            </label>
            {categories.length === 0 && !category ? (
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-medium">
                Avval &quot;Kategoriyalar&quot; bo&apos;limida kamida bitta kitob kategoriyasi yarating.
              </div>
            ) : (
              <select
                id="book-category-select"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:ring-2 focus:ring-blue-500 focus:outline-hidden bg-white"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
                {category && !categories.some((c) => c.name === category) && (
                  <option value={category}>{category}</option>
                )}
              </select>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="book-title-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Kitob nomi (Sarlavha) *
              </label>
              <input
                id="book-title-input"
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                placeholder="Masalan: Diskret matematika va mantiq"
              />
            </div>

            <div>
              <label htmlFor="book-author-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Muallif(lar) *
              </label>
              <input
                id="book-author-input"
                type="text"
                required
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                placeholder="Prof. S. Qosimov"
              />
            </div>
          </div>

          {/* Cover Image & PDF Upload Section */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200">
            {/* Cover Upload */}
            <div className="space-y-2">
              <span className="block text-xs font-bold text-slate-800">Muqova rasmi yuklash</span>
              <div className="flex items-center gap-3">
                <img
                  src={coverUrl}
                  alt="Kitob muqovasi"
                  className="w-16 h-22 object-cover rounded-lg border border-slate-300 shadow-xs bg-white flex-shrink-0"
                />
                <div className="flex-1 min-w-0 space-y-1.5">
                  <label
                    htmlFor="book-cover-upload"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-xs font-semibold cursor-pointer transition-colors"
                  >
                    <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                    <span>Rasm tanlash</span>
                  </label>
                  <input
                    id="book-cover-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleCoverUpload}
                    className="sr-only"
                  />
                  <div className="text-[11px] text-slate-500 truncate">
                    {coverFileName || "Yoki joriy/standart muqova qo'llaniladi"}
                  </div>
                </div>
              </div>
            </div>

            {/* PDF Upload */}
            <div className="space-y-2">
              <span className="block text-xs font-bold text-slate-800">Kitobning PDF varianti yuklash</span>
              <label
                htmlFor="book-pdf-upload"
                className={`flex flex-col items-center justify-center p-3 rounded-xl border-2 border-dashed cursor-pointer transition-colors text-center ${
                  pdfFile
                    ? 'border-emerald-400 bg-emerald-50/70'
                    : 'border-blue-300 bg-white hover:bg-blue-50/40'
                }`}
              >
                {pdfFile ? (
                  <>
                    <FileText className="w-5 h-5 text-emerald-600 mb-1" />
                    <span className="text-xs font-bold text-emerald-800 line-clamp-1">{pdfFile.name}</span>
                    <span className="text-[10px] text-emerald-600">
                      {formatFileSize(pdfFile.size)} • PDF biriktirildi
                    </span>
                  </>
                ) : (
                  <>
                    <Upload className="w-5 h-5 text-blue-600 mb-1" />
                    <span className="text-xs font-semibold text-slate-700">PDF faylni tanlang (.pdf)</span>
                    <span className="text-[10px] text-slate-400">Talabalar sayt ichida o'qishlari uchun</span>
                  </>
                )}
              </label>
              <input
                id="book-pdf-upload"
                type="file"
                accept=".pdf,application/pdf"
                onChange={handlePdfUpload}
                className="sr-only"
              />
            </div>

            {/* Student PDF download permission switch */}
            <div className="sm:col-span-2 pt-3 border-t border-slate-200 flex items-center justify-between gap-4">
              <div className="flex items-start gap-2.5">
                <div
                  className={`p-2 rounded-xl flex-shrink-0 ${
                    allowPdfDownload
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-slate-200/80 text-slate-600'
                  }`}
                >
                  {allowPdfDownload ? <Download className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">
                    Talabalarga PDF faylni yuklab olishga ruxsat berish
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {allowPdfDownload
                      ? 'Yoqilgan — talabalar kitobning PDF variantini yuklab olishlari mumkin.'
                      : "O'chik holat — talabalar kitobni faqat sayt ichida o'qiy oladi (yuklab olish taqiqlangan)."}
                  </p>
                </div>
              </div>

              <button
                type="button"
                role="switch"
                aria-checked={allowPdfDownload}
                aria-label="Talabalarga PDF faylni yuklab olishga ruxsat berish"
                data-testid="allow-pdf-download-toggle"
                onClick={() => setAllowPdfDownload((prev) => !prev)}
                className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                  allowPdfDownload ? 'bg-emerald-600' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                    allowPdfDownload ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="col-span-2 sm:col-span-1">
              <label className="block text-xs font-semibold text-slate-700 mb-1">ISBN kodi</label>
              <input
                type="text"
                value={isbn}
                onChange={(e) => setIsbn(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nashr yili</label>
              <input
                type="number"
                min={1950}
                max={2030}
                value={year}
                onChange={(e) => setYear(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Sahifalar</label>
              <input
                type="number"
                min={10}
                max={5000}
                value={pages}
                onChange={(e) => setPages(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nusxalar soni</label>
              <input
                type="number"
                min={1}
                max={500}
                value={totalCopies}
                onChange={(e) => setTotalCopies(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden font-bold"
              />
            </div>
          </div>

          {/* Physical Location on Shelves */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Kutubxonadagi jismoniy joylashuvi
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">Bino / Korpus</label>
                <input
                  type="text"
                  value={building}
                  onChange={(e) => setBuilding(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">Qavat</label>
                <input
                  type="number"
                  value={floor}
                  onChange={(e) => setFloor(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">Javon raqami</label>
                <input
                  type="text"
                  value={shelf}
                  onChange={(e) => setShelf(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">Tokcha / Bo'lim</label>
                <input
                  type="text"
                  value={section}
                  onChange={(e) => setSection(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                />
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Qisqacha tavsif</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden resize-none"
              placeholder="Kitobning qisqacha mazmuni va mundarijasi..."
            />
          </div>

          {/* E-book content sample */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Qo'shimcha matn (ixtiyoriy, matn rejimida ko'rish uchun)
            </label>
            <textarea
              rows={2}
              value={sampleChapterContent}
              onChange={(e) => setSampleChapterContent(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden font-serif"
              placeholder="1-bob matnini bu yerga yozishingiz mumkin..."
            />
          </div>
        </form>

        {/* Pinned Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold transition-colors"
          >
            Bekor qilish
          </button>
          <button
            type="submit"
            form="add-book-form"
            disabled={isSaving}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold shadow-md shadow-blue-500/20 transition-all"
          >
            <Check className="w-4 h-4" />
            <span>
              {isSaving
                ? 'Yuklanmoqda va saqlanmoqda...'
                : isEditMode
                ? "O'zgarishlarni saqlash"
                : "Kitobni fondga qo'shish"}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
