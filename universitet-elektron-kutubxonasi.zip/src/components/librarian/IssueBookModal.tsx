import React, { useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import { MAX_ACTIVE_LOANS_PER_STUDENT, STANDARD_LOAN_DAYS } from '../../utils/libraryRules';
import { UserAvatar } from '../common/UserAvatar';
import {
  X,
  BookUp,
  Search,
  AlertCircle,
  Check,
  ArrowRight,
  ArrowLeft,
  UserCheck,
  BookOpen,
} from 'lucide-react';

interface IssueBookModalProps {
  initialBookId?: string;
  initialStudentId?: string;
  onClose: () => void;
}

export const IssueBookModal: React.FC<IssueBookModalProps> = ({
  initialBookId,
  initialStudentId,
  onClose,
}) => {
  const { books, students, loans, categories, issueMultipleBooks } = useLibrary();

  const [step, setStep] = useState<1 | 2>(initialStudentId ? 2 : 1);
  const [selectedStudentId, setSelectedStudentId] = useState(initialStudentId || '');
  const [selectedBookIds, setSelectedBookIds] = useState<string[]>(
    initialBookId ? [initialBookId] : []
  );
  const [days, setDays] = useState(STANDARD_LOAN_DAYS);
  const [notes, setNotes] = useState('');
  const [studentSearch, setStudentSearch] = useState('');
  const [bookSearch, setBookSearch] = useState('');
  const [bookCategory, setBookCategory] = useState('all');
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const student = students.find((s) => s.id === selectedStudentId);

  const studentActiveLoans = student
    ? loans.filter((l) => l.studentId === student.id && l.status !== 'returned')
    : [];
  const studentHasOverdue = studentActiveLoans.some((l) => l.status === 'overdue');
  const remainingCapacity = Math.max(0, MAX_ACTIVE_LOANS_PER_STUDENT - studentActiveLoans.length);

  const filteredStudents = students.filter(
    (s) =>
      s.name.toLowerCase().includes(studentSearch.toLowerCase()) ||
      s.studentId.toLowerCase().includes(studentSearch.toLowerCase()) ||
      s.group.toLowerCase().includes(studentSearch.toLowerCase())
  );

  const filteredBooks = books.filter((b) => {
    const q = bookSearch.toLowerCase();
    const matchesSearch =
      b.title.toLowerCase().includes(q) ||
      b.author.toLowerCase().includes(q) ||
      b.barcode.toLowerCase().includes(q);
    const matchesCategory = bookCategory === 'all' || b.category === bookCategory;
    return matchesSearch && matchesCategory;
  });

  const selectedBookObjects = books.filter((b) => selectedBookIds.includes(b.id));

  const toggleBookSelection = (bookId: string, availableCopies: number) => {
    setErrorMessage('');
    if (availableCopies <= 0) return;

    setSelectedBookIds((prev) => {
      if (prev.includes(bookId)) {
        return prev.filter((id) => id !== bookId);
      }
      if (prev.length >= remainingCapacity) {
        setErrorMessage(
          `Bu talaba maksimal ${MAX_ACTIVE_LOANS_PER_STUDENT} ta kitob olishi mumkin. Hozir qo'shimcha ${remainingCapacity} ta kitob belgilash mumkin.`
        );
        return prev;
      }
      return [...prev, bookId];
    });
  };

  const handleProceedToBooks = () => {
    setErrorMessage('');
    if (!student) {
      setErrorMessage('Iltimos, avval talabani tanlang!');
      return;
    }
    if (student.status === 'blocked') {
      setErrorMessage(`Talaba "${student.name}" ma'muriyat tomonidan bloklangan.`);
      return;
    }
    if (studentHasOverdue) {
      setErrorMessage("Talabada muddati o'tgan kitob mavjud. Avval uni qaytarish kerak.");
      return;
    }
    if (remainingCapacity <= 0) {
      setErrorMessage(`Talabada allaqachon maksimal ${MAX_ACTIVE_LOANS_PER_STUDENT} ta kitob bor.`);
      return;
    }
    setStep(2);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!selectedStudentId) {
      setStep(1);
      setErrorMessage('Iltimos, kitob beriladigan talabani tanlang!');
      return;
    }
    if (selectedBookIds.length === 0) {
      setErrorMessage('Iltimos, ijaraga beriladigan kamida bitta kitobni belgilang!');
      return;
    }

    setIsSubmitting(true);
    try {
      const result = await issueMultipleBooks({
        bookIds: selectedBookIds,
        studentId: selectedStudentId,
        days: Number(days),
        notes: notes.trim(),
      });

      if (result.success) {
        onClose();
      } else {
        setErrorMessage(result.message);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-linear-to-r from-blue-700 to-indigo-700 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/20 backdrop-blur-xs">
              <BookUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-lg">Kitoblarni ijaraga berish</h2>
              <p className="text-xs text-blue-200">
                1-qadam: talabani tanlang • 2-qadam: kitob(lar)ni belgilang
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Yopish"
            className="p-1.5 rounded-lg hover:bg-white/20 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Orderly 2-step indicator bar */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              setErrorMessage('');
              setStep(1);
            }}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              step === 1
                ? 'bg-blue-600 text-white shadow-xs'
                : student
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : 'bg-white text-slate-600 border border-slate-200'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>1. Talabani tanlash</span>
          </button>

          <ArrowRight className="w-4 h-4 text-slate-400 shrink-0" />

          <button
            type="button"
            disabled={!student}
            onClick={() => {
              if (student) handleProceedToBooks();
            }}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition-all disabled:opacity-40 ${
              step === 2
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>
              2. Kitoblarni belgilash
              {selectedBookIds.length > 0 ? ` (${selectedBookIds.length})` : ''}
            </span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
          {errorMessage && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-semibold">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* STEP 1: Select Student */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">1-qadam: Talabani tanlang</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Qaysi talabaga kitob berilishini belgilang — uning faol ijaralari va limiti darhol ko&apos;rsatiladi
                </p>
              </div>

              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                <input
                  type="text"
                  placeholder="Talaba ismi, ID yoki guruh bo'yicha qidiring..."
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-50 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div className="max-h-64 overflow-y-auto border border-slate-200 rounded-2xl divide-y divide-slate-100 bg-white">
                {filteredStudents.length === 0 ? (
                  <div className="p-6 text-xs text-slate-400 text-center">Talaba topilmadi</div>
                ) : (
                  filteredStudents.map((s) => {
                    const isSelected = selectedStudentId === s.id;
                    const isBlocked = s.status === 'blocked';
                    const activeForStudent = loans.filter(
                      (l) => l.studentId === s.id && l.status !== 'returned'
                    );
                    const overdueForStudent = activeForStudent.some((l) => l.status === 'overdue');

                    return (
                      <button
                        key={s.id}
                        type="button"
                        disabled={isBlocked}
                        onClick={() => {
                          setSelectedStudentId(s.id);
                          setSelectedBookIds(initialBookId ? [initialBookId] : []);
                          setErrorMessage('');
                        }}
                        className={`w-full text-left px-4 py-3 flex items-center justify-between gap-3 text-xs transition-colors ${
                          isSelected
                            ? 'bg-blue-50 ring-1 ring-inset ring-blue-500'
                            : isBlocked
                            ? 'opacity-50 cursor-not-allowed bg-slate-50'
                            : 'hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <UserAvatar
                            name={s.name}
                            avatarUrl={s.avatarUrl}
                            sizeClass="w-9 h-9"
                            textClass="text-xs"
                            roundedClass="rounded-full"
                            className="border border-slate-200"
                          />
                          <div className="min-w-0">
                            <div className="font-bold text-slate-900 truncate">{s.name}</div>
                            <div className="text-[11px] text-slate-500 font-mono truncate">
                              {s.studentId} • Guruh: {s.group} • {s.specialty}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-[11px] font-semibold text-slate-600 tabular-nums bg-slate-100 px-2 py-0.5 rounded-lg">
                            {activeForStudent.length} / {MAX_ACTIVE_LOANS_PER_STUDENT}
                          </span>
                          {isBlocked ? (
                            <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-lg border border-rose-200">
                              Bloklangan
                            </span>
                          ) : overdueForStudent ? (
                            <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200">
                              Kechikkan
                            </span>
                          ) : isSelected ? (
                            <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center">
                              <Check className="w-3.5 h-3.5" />
                            </span>
                          ) : null}
                        </div>
                      </button>
                    );
                  })
                )}
              </div>

              {student && (
                <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="font-bold text-blue-950 text-sm">{student.name}</div>
                    <div className="text-slate-600 mt-0.5">
                      {student.faculty} • Qo&apos;lida: <span className="font-bold">{studentActiveLoans.length}</span> / {MAX_ACTIVE_LOANS_PER_STUDENT} ta kitob • Yana <span className="font-bold text-blue-700">{remainingCapacity} ta</span> berish mumkin
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleProceedToBooks}
                    className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-sm whitespace-nowrap shrink-0"
                  >
                    <span>Keyingi qadam: Kitoblarni tanlash</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}

              <div className="pt-2 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold"
                >
                  Bekor qilish
                </button>
                <button
                  type="button"
                  disabled={!student}
                  onClick={handleProceedToBooks}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white text-xs font-semibold shadow-sm"
                >
                  <span>Davom etish</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Multi-Book Selection + Duration + Notes */}
          {step === 2 && student && (
            <div className="space-y-4">
              {/* Selected Student Compact Card */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <UserAvatar
                    name={student.name}
                    avatarUrl={student.avatarUrl}
                    sizeClass="w-9 h-9"
                    textClass="text-xs"
                    roundedClass="rounded-full"
                    className="border border-slate-200"
                  />
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-slate-900 truncate">{student.name}</div>
                    <div className="text-[11px] text-slate-500">
                      {student.studentId} • Guruh: {student.group} • Limit: {studentActiveLoans.length + selectedBookIds.length}/{MAX_ACTIVE_LOANS_PER_STUDENT}
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage('');
                    setStep(1);
                  }}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-xs font-semibold text-slate-700 shrink-0"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>O&apos;zgartirish</span>
                </button>
              </div>

              {/* Search & Category filter */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
                    2-qadam: Tizimdagi mavjud kitoblarni belgilang ({selectedBookIds.length} / {remainingCapacity})
                  </label>
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                    <input
                      type="text"
                      placeholder="Kitob nomi, muallif yoki inventar raqami..."
                      value={bookSearch}
                      onChange={(e) => setBookSearch(e.target.value)}
                      className="w-full pl-9 pr-4 py-2 bg-slate-50 rounded-xl border border-slate-300 text-xs sm:text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    />
                  </div>
                  <select
                    aria-label="Kategoriya bo'yicha saralash"
                    value={bookCategory}
                    onChange={(e) => setBookCategory(e.target.value)}
                    className="px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white text-slate-700"
                  >
                    <option value="all">Barcha kategoriyalar</option>
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Available Books Checklist */}
                <div className="max-h-52 overflow-y-auto border border-slate-200 rounded-2xl divide-y divide-slate-100 bg-white">
                  {filteredBooks.length === 0 ? (
                    <div className="p-5 text-xs text-slate-400 text-center">Kitob topilmadi</div>
                  ) : (
                    filteredBooks.map((b) => {
                      const isChecked = selectedBookIds.includes(b.id);
                      const isOutOfStock = b.availableCopies <= 0;
                      return (
                        <button
                          key={b.id}
                          type="button"
                          disabled={isOutOfStock}
                          onClick={() => toggleBookSelection(b.id, b.availableCopies)}
                          className={`w-full text-left px-4 py-2.5 flex items-center justify-between gap-3 text-xs transition-colors ${
                            isChecked
                              ? 'bg-blue-50/90 ring-1 ring-inset ring-blue-500'
                              : isOutOfStock
                              ? 'opacity-40 cursor-not-allowed bg-slate-50'
                              : 'hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <span
                              className={`w-5 h-5 rounded-md border flex items-center justify-center flex-shrink-0 transition-colors ${
                                isChecked
                                  ? 'bg-blue-600 border-blue-600 text-white'
                                  : 'border-slate-300 bg-white'
                              }`}
                            >
                              {isChecked && <Check className="w-3.5 h-3.5" />}
                            </span>
                            <img
                              src={b.coverUrl}
                              alt={b.title}
                              className="w-8 h-10 object-cover rounded shadow-xs flex-shrink-0"
                            />
                            <div className="min-w-0">
                              <div className="font-bold text-slate-900 line-clamp-1">{b.title}</div>
                              <div className="text-[11px] text-slate-500 truncate">
                                {b.author} • {b.category} • {b.barcode}
                              </div>
                            </div>
                          </div>

                          <div className="text-right shrink-0">
                            {isOutOfStock ? (
                              <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md">
                                Qolmagan
                              </span>
                            ) : (
                              <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md tabular-nums">
                                {b.availableCopies} ta bo&apos;sh
                              </span>
                            )}
                          </div>
                        </button>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Selected Books Basket */}
              {selectedBookObjects.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-blue-50/60 border border-blue-200 space-y-2">
                  <div className="text-xs font-bold text-blue-950">
                    Tanlangan kitoblar ({selectedBookObjects.length} ta):
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedBookObjects.map((b) => (
                      <span
                        key={b.id}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-blue-200 text-[11px] font-semibold text-slate-800"
                      >
                        <span className="max-w-[180px] truncate">{b.title}</span>
                        <button
                          type="button"
                          onClick={() => toggleBookSelection(b.id, b.availableCopies)}
                          aria-label={`Olib tashlash: ${b.title}`}
                          className="text-slate-400 hover:text-rose-600"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Loan Duration & Notes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Qaytarish muddati
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { label: '7 kun', val: 7 },
                      { label: '14 kun', val: 14 },
                      { label: '30 kun', val: 30 },
                    ].map((opt) => (
                      <button
                        key={opt.val}
                        type="button"
                        onClick={() => setDays(opt.val)}
                        className={`py-2 rounded-xl text-xs font-semibold border transition-all ${
                          days === opt.val
                            ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                            : 'border-slate-300 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Izoh (ixtiyoriy)
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    placeholder="Masalan: Semestr darsliklari to'plami"
                  />
                </div>
              </div>

              {/* Submit Actions */}
              <div className="pt-3 border-t border-slate-200 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage('');
                    setStep(1);
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Orqaga</span>
                </button>

                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold"
                  >
                    Bekor qilish
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting || selectedBookIds.length === 0}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold shadow-md shadow-blue-500/20 transition-all"
                  >
                    <BookUp className="w-4 h-4" />
                    <span>
                      {isSubmitting
                        ? 'Saqlanmoqda...'
                        : `${selectedBookIds.length} ta kitobni ijaraga berish`}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
