import React, { useEffect, useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import type { Book, Loan, Student } from '../../types/library';
import { IssueBookModal } from './IssueBookModal';
import { ReturnBookModal } from './ReturnBookModal';
import { AddBookModal } from './AddBookModal';
import { StudentBooksModal } from './StudentBooksModal';
import { CategoriesManager } from '../common/CategoriesManager';
import { EBookReaderModal } from '../common/EBookReaderModal';
import { DashboardLayout, SidebarMenuItem } from '../layout/DashboardLayout';
import {
  calculateDaysOverdue,
  formatUzbekCurrency,
  formatUzbekDate,
} from '../../utils/libraryRules';
import {
  BookOpen,
  BookUp,
  BookCheck,
  PlusCircle,
  Search,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Layers,
  MapPin,
  RotateCw,
  Eye,
  Users,
  Tag,
  FileText,
  ChevronRight,
  Pencil,
  Trash2,
  Phone,
  ArrowRight,
  Lock,
  Download,
  UserCheck,
} from 'lucide-react';

interface LibrarianDashboardProps {
  overdueJumpKey?: number;
}

export const LibrarianDashboard: React.FC<LibrarianDashboardProps> = ({ overdueJumpKey = 0 }) => {
  const {
    books,
    students,
    categories,
    loans,
    reservations,
    currentUser,
    prolongLoan,
    cancelReservation,
    deleteBook,
    setShowProfileModal,
  } = useLibrary();

  const [activeTab, setActiveTab] = useState<'loans' | 'students' | 'books' | 'categories' | 'reservations'>('loans');

  // Modals state
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [preselectedBookId, setPreselectedBookId] = useState<string | undefined>();
  const [preselectedStudentId, setPreselectedStudentId] = useState<string | undefined>();
  const [returningLoan, setReturningLoan] = useState<Loan | null>(null);
  const [showAddBookModal, setShowAddBookModal] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | undefined>(undefined);
  const [readingBook, setReadingBook] = useState<Book | null>(null);
  const [inspectingStudent, setInspectingStudent] = useState<Student | null>(null);
  const [confirmDeleteBookId, setConfirmDeleteBookId] = useState<string | null>(null);

  // Filters
  const [loanSearch, setLoanSearch] = useState('');
  const [loanFilter, setLoanFilter] = useState<'all' | 'active' | 'overdue' | 'returned'>('all');
  const [studentSearch, setStudentSearch] = useState('');
  const [bookSearch, setBookSearch] = useState('');
  const [bookCategory, setBookCategory] = useState('all');

  useEffect(() => {
    if (overdueJumpKey > 0) {
      setActiveTab('loans');
      setLoanFilter('overdue');
    }
  }, [overdueJumpKey]);

  // Counts
  const activeLoans = loans.filter((l) => l.status === 'active');
  const overdueLoans = loans.filter((l) => l.status === 'overdue');
  const returnedLoans = loans.filter((l) => l.status === 'returned');

  // Filter loans
  const filteredLoans = loans.filter((loan) => {
    const matchesSearch =
      loan.bookTitle.toLowerCase().includes(loanSearch.toLowerCase()) ||
      loan.studentName.toLowerCase().includes(loanSearch.toLowerCase()) ||
      loan.studentGroup.toLowerCase().includes(loanSearch.toLowerCase());

    if (!matchesSearch) return false;
    if (loanFilter === 'all') return true;
    return loan.status === loanFilter;
  });

  // Filter students
  const filteredStudents = students.filter(
    (s) =>
      s.name.toLowerCase().includes(studentSearch.toLowerCase()) ||
      s.studentId.toLowerCase().includes(studentSearch.toLowerCase()) ||
      s.group.toLowerCase().includes(studentSearch.toLowerCase()) ||
      s.specialty.toLowerCase().includes(studentSearch.toLowerCase())
  );

  // Filter books
  const filteredBooks = books.filter((b) => {
    const matchesSearch =
      b.title.toLowerCase().includes(bookSearch.toLowerCase()) ||
      b.author.toLowerCase().includes(bookSearch.toLowerCase()) ||
      b.barcode.toLowerCase().includes(bookSearch.toLowerCase());
    const matchesCategory = bookCategory === 'all' || b.category === bookCategory;
    return matchesSearch && matchesCategory;
  });

  const handleOpenIssueModal = (bookId?: string, studentId?: string) => {
    setPreselectedBookId(bookId);
    setPreselectedStudentId(studentId);
    setShowIssueModal(true);
  };

  const handleJumpToOverdue = () => {
    setActiveTab('loans');
    setLoanFilter('overdue');
  };

  const menuItems: SidebarMenuItem[] = [
    {
      id: 'loans',
      label: 'Ijara nazorati',
      icon: <BookCheck className="w-4 h-4" />,
      badge: loans.length,
    },
    {
      id: 'students',
      label: "Talabalar ro'yxati",
      icon: <Users className="w-4 h-4" />,
      badge: students.length,
    },
    {
      id: 'books',
      label: 'Kitoblar fondi',
      icon: <Layers className="w-4 h-4" />,
      badge: books.length,
    },
    {
      id: 'categories',
      label: 'Kategoriyalar',
      icon: <Tag className="w-4 h-4" />,
      badge: categories.length,
    },
    {
      id: 'reservations',
      label: 'Bron qilinganlar',
      icon: <Clock className="w-4 h-4" />,
      badge: reservations.length,
    },
  ];

  return (
    <DashboardLayout
      accentColor="blue"
      panelTitle="Kutubxonachi Paneli"
      panelSubtitle="Kitob ijarasi, talaba kitob hisobi, kategoriya va fond boshqaruvi"
      menuItems={menuItems}
      activeMenuId={activeTab}
      onSelectMenu={(id) => setActiveTab(id as typeof activeTab)}
      sidebarFooter={
        <div className="space-y-2">
          <button
            type="button"
            onClick={() => handleOpenIssueModal()}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <BookUp className="w-3.5 h-3.5" />
            <span>Kitob ijaraga berish</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setEditingBook(undefined);
              setShowAddBookModal(true);
            }}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Fondga kitob qo'shish</span>
          </button>
        </div>
      }
    >
      {/* Modern Librarian Profile & Action Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5 bg-linear-to-r from-slate-900 via-blue-950 to-indigo-950 p-6 rounded-3xl text-white shadow-lg border border-white/10">
        <div className="flex items-start gap-4 min-w-0">
          {currentUser?.avatarUrl && (
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.name}
              className="w-15 h-15 rounded-2xl object-cover ring-2 ring-blue-400/40 shadow-md flex-shrink-0"
            />
          )}
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-lg text-[11px] font-semibold bg-blue-500/25 text-blue-200 border border-blue-400/30 inline-flex items-center gap-1">
                <BookOpen className="w-3 h-3" />
                Kutubxonachi Ish Stoli
              </span>
              {currentUser?.librarianData?.shift && (
                <span className="text-[11px] text-slate-300">{currentUser.librarianData.shift}</span>
              )}
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight truncate">
              {currentUser?.name || 'Kitoblar Berish va Qaytarish Markazi'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
              {currentUser?.librarianData?.department ||
                "Talabalarga kitob ijaraga berish, talaba hisobi va fond boshqaruvi"}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => handleOpenIssueModal()}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-500/25 transition-all"
          >
            <BookUp className="w-4 h-4" />
            <span>Kitob ijaraga berish</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setEditingBook(undefined);
              setShowAddBookModal(true);
            }}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs sm:text-sm border border-white/20 transition-all"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Fondga kitob qo'shish</span>
          </button>

          <button
            type="button"
            onClick={() => setShowProfileModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs border border-white/20 transition-all"
          >
            <UserCheck className="w-4 h-4 text-blue-300" />
            <span>Profil</span>
          </button>
        </div>
      </div>

      {/* KPI Counters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 tabular-nums">
        <button
          type="button"
          onClick={() => {
            setActiveTab('loans');
            setLoanFilter('active');
          }}
          className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-blue-300 shadow-xs flex items-center justify-between text-left transition-all cursor-pointer"
        >
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Hozirda ijaradagi kitoblar</p>
            <h3 className="text-2xl font-extrabold text-slate-900 mt-1">{activeLoans.length} ta</h3>
            <span className="text-[11px] text-blue-600 font-medium">Muddati kutilmoqda</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center">
            <BookOpen className="w-6 h-6" />
          </div>
        </button>

        <button
          type="button"
          data-testid="librarian-overdue-stat-card"
          onClick={handleJumpToOverdue}
          className={`bg-white p-5 rounded-2xl border shadow-xs flex items-center justify-between text-left transition-all cursor-pointer group ${
            activeTab === 'loans' && loanFilter === 'overdue'
              ? 'border-rose-500 ring-2 ring-rose-500/20'
              : overdueLoans.length > 0
              ? 'border-rose-200 hover:border-rose-400 hover:shadow-md'
              : 'border-slate-200 hover:border-slate-300'
          }`}
        >
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Muddati o'tgan kitoblar</p>
            <h3 className={`text-2xl font-bold mt-1 ${overdueLoans.length > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
              {overdueLoans.length} ta
            </h3>
            <span className="text-[11px] text-rose-600 font-semibold inline-flex items-center gap-1 mt-0.5">
              <span>{overdueLoans.length > 0 ? "Kechiktirganlarni ko'rish" : 'Barcha muddatlar toza'}</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('reservations')}
          className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-amber-300 shadow-xs flex items-center justify-between text-left transition-all cursor-pointer"
        >
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Talabalar buyurtmalari (Bronlar)</p>
            <h3 className="text-2xl font-bold text-slate-900 mt-1">{reservations.length} ta</h3>
            <span className="text-[11px] text-amber-600 font-medium">Olib ketishni kutmoqda</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
        </button>
      </div>

      {/* Section 1: Loans & Returns Table */}
      {activeTab === 'loans' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden space-y-4">
          <div className="p-4 bg-slate-50/70 border-b border-slate-200 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
              <input
                type="text"
                placeholder="Kitob nomi, talaba ismi yoki guruh bo'yicha qidirish..."
                value={loanSearch}
                onChange={(e) => setLoanSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-white rounded-xl border border-slate-300 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
              <button
                type="button"
                onClick={() => setLoanFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                  loanFilter === 'all'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50'
                }`}
              >
                Barchasi ({loans.length})
              </button>
              <button
                type="button"
                onClick={() => setLoanFilter('active')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                  loanFilter === 'active'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50'
                }`}
              >
                Faol ijaralar ({activeLoans.length})
              </button>
              <button
                type="button"
                onClick={() => setLoanFilter('overdue')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                  loanFilter === 'overdue'
                    ? 'bg-rose-600 text-white'
                    : 'bg-white border border-rose-300 text-rose-700 hover:bg-rose-50'
                }`}
              >
                Muddati o'tganlar ({overdueLoans.length})
              </button>
              <button
                type="button"
                onClick={() => setLoanFilter('returned')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                  loanFilter === 'returned'
                    ? 'bg-slate-800 text-white'
                    : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50'
                }`}
              >
                Topshirilganlar ({returnedLoans.length})
              </button>
            </div>
          </div>

          {loanFilter === 'overdue' && overdueLoans.length > 0 && (
            <div className="mx-4 p-4 rounded-xl bg-rose-50 border border-rose-200 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-rose-900">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>Kechiktirayotgan talabalar va bog'lanish ma'lumotlari ({overdueLoans.length} ta)</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {overdueLoans.map((ol) => {
                  const stu = students.find((s) => s.id === ol.studentId);
                  const days = calculateDaysOverdue(ol.dueDate);
                  return (
                    <div
                      key={ol.id}
                      className="p-3 rounded-xl bg-white border border-rose-200 flex items-center justify-between gap-2 text-xs"
                    >
                      <div className="min-w-0">
                        <button
                          type="button"
                          onClick={() => stu && setInspectingStudent(stu)}
                          className="font-bold text-slate-900 hover:text-blue-600 underline decoration-dotted text-left truncate block"
                        >
                          {ol.studentName} ({ol.studentGroup})
                        </button>
                        <div className="text-[11px] text-slate-500 truncate">{ol.bookTitle}</div>
                        {stu && (
                          <div className="text-[11px] text-slate-600 font-mono flex items-center gap-1 mt-0.5">
                            <Phone className="w-3 h-3 text-slate-400" />
                            <span>{stu.phone}</span>
                          </div>
                        )}
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className="font-bold text-rose-600">{days} kun</div>
                        <div className="text-[11px] font-semibold text-rose-700">
                          {formatUzbekCurrency(ol.fineAmount)}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs font-bold uppercase text-slate-500">
                <tr>
                  <th className="px-6 py-3.5">Kitob</th>
                  <th className="px-4 py-3.5">Talaba (ko'rish uchun bosing)</th>
                  <th className="px-4 py-3.5">Berilgan sana</th>
                  <th className="px-4 py-3.5">Topshirish muddati</th>
                  <th className="px-4 py-3.5">Holati</th>
                  <th className="px-6 py-3.5 text-right">Amallar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLoans.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                      Ijaradagi kitoblar topilmadi.
                    </td>
                  </tr>
                ) : (
                  filteredLoans.map((loan) => {
                    const isReturned = loan.status === 'returned';
                    const isOverdue = loan.status === 'overdue';
                    const daysOverdue = calculateDaysOverdue(loan.dueDate);
                    const matchedStudent = students.find((s) => s.id === loan.studentId);

                    return (
                      <tr
                        key={loan.id}
                        className={`transition-colors ${
                          isOverdue ? 'bg-rose-50/50 hover:bg-rose-50/80' : 'hover:bg-slate-50/80'
                        }`}
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <img
                              src={loan.bookCoverUrl}
                              alt={loan.bookTitle}
                              className="w-10 h-14 object-cover rounded shadow-xs flex-shrink-0"
                            />
                            <div>
                              <div className="font-bold text-slate-900 line-clamp-1">{loan.bookTitle}</div>
                              <div className="text-xs text-slate-500">{loan.bookAuthor}</div>
                              {loan.notes && (
                                <div className="text-[11px] text-slate-400 italic mt-0.5">
                                  Izoh: {loan.notes}
                                </div>
                              )}
                            </div>
                          </div>
                        </td>

                        <td className="px-4 py-4">
                          <button
                            type="button"
                            onClick={() => matchedStudent && setInspectingStudent(matchedStudent)}
                            className="text-left group"
                            title="Talaba kitoblarini ko'rish"
                          >
                            <div className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors underline decoration-dotted underline-offset-2">
                              {loan.studentName}
                            </div>
                            <div className="text-xs text-slate-500">
                              Guruh: <span className="font-semibold text-slate-700">{loan.studentGroup}</span>
                            </div>
                            <div className="text-[11px] text-slate-400 line-clamp-1">{loan.studentFaculty}</div>
                          </button>
                        </td>

                        <td className="px-4 py-4 text-xs text-slate-600">{formatUzbekDate(loan.issueDate)}</td>

                        <td className="px-4 py-4">
                          <div className="text-xs font-semibold text-slate-900">
                            {formatUzbekDate(loan.dueDate)}
                          </div>
                          {isOverdue && (
                            <div className="text-[11px] font-bold text-rose-600 mt-0.5 flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" />
                              <span>{daysOverdue} kun kechikkan!</span>
                            </div>
                          )}
                          {isReturned && loan.returnDate && (
                            <div className="text-[11px] text-emerald-600 font-medium">
                              Topshirildi: {formatUzbekDate(loan.returnDate)}
                            </div>
                          )}
                        </td>

                        <td className="px-4 py-4">
                          {isReturned ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">
                              <CheckCircle2 className="w-3.5 h-3.5 text-slate-500" />
                              <span>Topshirilgan</span>
                            </span>
                          ) : isOverdue ? (
                            <div className="space-y-1">
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-700 border border-rose-200">
                                <AlertTriangle className="w-3.5 h-3.5" />
                                <span>Muddati o'tgan</span>
                              </span>
                              {loan.fineAmount > 0 && (
                                <div className="text-[11px] text-rose-600 font-bold">
                                  Jarima: {formatUzbekCurrency(loan.fineAmount)}
                                </div>
                              )}
                            </div>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                              <Clock className="w-3.5 h-3.5" />
                              <span>Faol ijara</span>
                            </span>
                          )}
                        </td>

                        <td className="px-6 py-4 text-right">
                          {!isReturned ? (
                            <div className="flex items-center justify-end gap-2">
                              <button
                                type="button"
                                onClick={() => setReturningLoan(loan)}
                                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs transition-colors"
                              >
                                <BookCheck className="w-3.5 h-3.5" />
                                <span>Qaytarib olish</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => prolongLoan(loan.id, 7)}
                                title="Muddatni 7 kunga uzaytirish"
                                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-medium transition-colors"
                              >
                                <RotateCw className="w-3 h-3" />
                                <span className="hidden lg:inline">+7 kun</span>
                              </button>
                            </div>
                          ) : (
                            <span className="text-xs text-slate-400">Amal tugatilgan</span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Section 2: Talabalar ro'yxati */}
      {activeTab === 'students' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 bg-slate-50/70 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="font-bold text-slate-900 text-sm">
                Talabalar ro'yxati va kitobxonlik ko'rsatkichlari
              </h2>
              <p className="text-xs text-slate-500">
                Talaba ustiga bossangiz, hozirda qo'lidagi va shu vaqtgacha o'qigan kitoblari batafsil ochiladi
              </p>
            </div>
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
              <input
                type="text"
                value={studentSearch}
                onChange={(e) => setStudentSearch(e.target.value)}
                placeholder="Talaba ismi, ID yoki guruh..."
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 bg-white text-xs focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="divide-y divide-slate-100">
            {filteredStudents.map((stu) => {
              const stuLoans = loans.filter((l) => l.studentId === stu.id);
              const holdingCount = stuLoans.filter((l) => l.status !== 'returned').length;
              const readCount = stuLoans.filter((l) => l.status === 'returned').length;

              return (
                <button
                  key={stu.id}
                  type="button"
                  onClick={() => setInspectingStudent(stu)}
                  className="w-full p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-blue-50/50 transition-colors text-left"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <img
                      src={stu.avatarUrl}
                      alt={stu.name}
                      className="w-11 h-11 rounded-full object-cover border border-slate-200 flex-shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-slate-900">{stu.name}</span>
                        <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                          {stu.studentId}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5 truncate">
                        {stu.specialtyCode ? `[${stu.specialtyCode}] ` : ''}
                        {stu.specialty} • {stu.group}-guruh ({stu.course}-kurs)
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 flex-shrink-0">
                    <span className="px-3 py-1 rounded-xl bg-blue-50 text-blue-700 border border-blue-200 text-xs font-bold">
                      Qo'lida: {holdingCount} ta
                    </span>
                    <span className="px-3 py-1 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold">
                      O'qigan: {readCount} ta
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Section 3: Book Catalog & Shelves */}
      {activeTab === 'books' && (
        <div className="space-y-4">
          <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
              <input
                type="text"
                placeholder="Kitob nomi, muallif yoki inventar kodi bo'yicha..."
                value={bookSearch}
                onChange={(e) => setBookSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 rounded-xl border border-slate-300 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <select
                aria-label="Kategoriya bo'yicha saralash"
                value={bookCategory}
                onChange={(e) => setBookCategory(e.target.value)}
                className="bg-white border border-slate-300 text-xs font-medium rounded-xl px-3 py-2 text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Barcha kategoriyalar</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={() => {
                  setEditingBook(undefined);
                  setShowAddBookModal(true);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors whitespace-nowrap"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Kitob kiritish</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredBooks.map((book) => {
              const isAvailable = book.availableCopies > 0;
              const isConfirming = confirmDeleteBookId === book.id;

              return (
                <div
                  key={book.id}
                  className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between hover:shadow-md transition-shadow"
                >
                  <div className="flex gap-4">
                    <img
                      src={book.coverUrl}
                      alt={book.title}
                      className="w-20 h-28 object-cover rounded-xl shadow-xs flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                          {book.category}
                        </span>
                        {book.pdfFileName && (
                          <span className="inline-flex items-center gap-0.5 text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-50 text-blue-700">
                            <FileText className="w-3 h-3" />
                            PDF
                          </span>
                        )}
                      </div>
                      <h3 className="font-bold text-sm text-slate-900 mt-1 line-clamp-2 leading-snug">
                        {book.title}
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">{book.author}</p>

                      <div className="mt-2 text-xs space-y-1">
                        <div className="flex items-center gap-1 text-slate-600">
                          <MapPin className="w-3.5 h-3.5 text-blue-600 flex-shrink-0" />
                          <span className="text-[11px] truncate">
                            {book.location.shelf}, {book.location.section}
                          </span>
                        </div>
                        <div className="flex items-center justify-between gap-2 text-[11px]">
                          <span className="text-slate-500 font-mono">{book.barcode}</span>
                          <span
                            className={`inline-flex items-center gap-1 font-medium ${
                              book.allowPdfDownload ? 'text-emerald-700' : 'text-amber-700'
                            }`}
                          >
                            {book.allowPdfDownload ? (
                              <>
                                <Download className="w-3 h-3" />
                                Yuklab olish ochiq
                              </>
                            ) : (
                              <>
                                <Lock className="w-3 h-3" />
                                Faqat o'qish
                              </>
                            )}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="text-xs font-bold">
                        {isAvailable ? (
                          <span className="text-emerald-600">{book.availableCopies} ta mavjud</span>
                        ) : (
                          <span className="text-rose-600">Hozirda qolmagan</span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400">Jami {book.totalCopies} nusxa</div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setReadingBook(book)}
                        title="PDF va elektron nusxasini ko'rish"
                        aria-label={`Elektron o'qish: ${book.title}`}
                        className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setEditingBook(book);
                          setShowAddBookModal(true);
                        }}
                        title="Kitobni tahrirlash"
                        aria-label={`Kitobni tahrirlash: ${book.title}`}
                        className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>

                      {isConfirming ? (
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              deleteBook(book.id);
                              setConfirmDeleteBookId(null);
                            }}
                            className="px-2 py-1 rounded-lg bg-rose-600 text-white text-[11px] font-bold"
                          >
                            O'chirish
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteBookId(null)}
                            className="px-1.5 py-1 rounded-lg border border-slate-300 text-slate-600 text-[11px]"
                          >
                            Yo'q
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteBookId(book.id)}
                          title="Kitobni o'chirish"
                          aria-label={`Kitobni o'chirish: ${book.title}`}
                          className="p-2 rounded-lg border border-rose-200 text-rose-600 hover:bg-rose-50 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}

                      <button
                        type="button"
                        disabled={!isAvailable}
                        onClick={() => handleOpenIssueModal(book.id)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-semibold shadow-xs transition-colors"
                      >
                        <BookUp className="w-3.5 h-3.5" />
                        <span>Ijaraga berish</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Section 4: Categories Manager */}
      {activeTab === 'categories' && <CategoriesManager accentColor="blue" />}

      {/* Section 5: Reservations */}
      {activeTab === 'reservations' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm">Talabalar tomonidan bron qilingan kitoblar</h3>
            <span className="text-xs text-slate-500">{reservations.length} ta so'rov</span>
          </div>

          <div className="divide-y divide-slate-100">
            {reservations.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-sm">
                Hozirda yangi band qilingan kitoblar mavjud emas.
              </div>
            ) : (
              reservations.map((res) => (
                <div
                  key={res.id}
                  className="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">{res.bookTitle}</h4>
                    <div className="text-slate-500 mt-0.5">
                      Talaba: <span className="font-semibold text-slate-800">{res.studentName}</span> • So'rov
                      sanasi: {formatUzbekDate(res.requestDate)}
                    </div>
                    <div className="text-[11px] text-amber-600 mt-0.5 font-medium">
                      Olib ketish muddati: {formatUzbekDate(res.expiryDate)} gacha
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleOpenIssueModal(res.bookId, res.studentId)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-xs transition-colors shadow-xs"
                    >
                      <BookUp className="w-3.5 h-3.5" />
                      <span>Ijara sifatida berish</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => cancelReservation(res.id)}
                      className="px-3 py-1.5 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg font-medium text-xs transition-colors"
                    >
                      Bekor qilish
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Modals */}
      {showIssueModal && (
        <IssueBookModal
          initialBookId={preselectedBookId}
          initialStudentId={preselectedStudentId}
          onClose={() => {
            setShowIssueModal(false);
            setPreselectedBookId(undefined);
            setPreselectedStudentId(undefined);
          }}
        />
      )}

      {returningLoan && <ReturnBookModal loan={returningLoan} onClose={() => setReturningLoan(null)} />}

      {showAddBookModal && (
        <AddBookModal
          editingBook={editingBook}
          onClose={() => {
            setShowAddBookModal(false);
            setEditingBook(undefined);
          }}
        />
      )}

      {readingBook && <EBookReaderModal book={readingBook} onClose={() => setReadingBook(null)} />}

      {inspectingStudent && (
        <StudentBooksModal
          student={inspectingStudent}
          loans={loans}
          onClose={() => setInspectingStudent(null)}
          onReturnLoan={(loan) => {
            setInspectingStudent(null);
            setReturningLoan(loan);
          }}
          onProlongLoan={(loanId) => prolongLoan(loanId, 7)}
          onIssueToStudent={(studentId) => {
            setInspectingStudent(null);
            handleOpenIssueModal(undefined, studentId);
          }}
        />
      )}
    </DashboardLayout>
  );
};
