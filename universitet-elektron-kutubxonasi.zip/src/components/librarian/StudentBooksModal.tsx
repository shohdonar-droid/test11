import React from 'react';
import { Loan, Student } from '../../types/library';
import { formatUzbekCurrency, formatUzbekDate, calculateDaysOverdue } from '../../utils/libraryRules';
import { UserAvatar } from '../common/UserAvatar';
import { UserAvatar } from '../common/UserAvatar';
import {
  X,
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  BookCheck,
  RotateCw,
  BookUp,
  Clock
} from 'lucide-react';

interface StudentBooksModalProps {
  student: Student;
  loans: Loan[];
  onClose: () => void;
  onReturnLoan: (loan: Loan) => void;
  onProlongLoan: (loanId: string) => void;
  onIssueToStudent: (studentId: string) => void;
}

export const StudentBooksModal: React.FC<StudentBooksModalProps> = ({
  student,
  loans,
  onClose,
  onReturnLoan,
  onProlongLoan,
  onIssueToStudent,
}) => {
  const studentLoans = loans.filter(l => l.studentId === student.id);
  const currentLoans = studentLoans.filter(l => l.status !== 'returned');
  const readLoans = studentLoans.filter(l => l.status === 'returned');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Student Header */}
        <div className="flex items-start justify-between gap-4 px-6 py-5 bg-linear-to-r from-blue-900 via-indigo-900 to-slate-900 text-white">
          <div className="flex items-center gap-4">
            <UserAvatar
              name={student.name}
              avatarUrl={student.avatarUrl}
              sizeClass="w-14 h-14"
              textClass="text-lg"
              roundedClass="rounded-2xl"
              className="border-2 border-blue-400/50"
            />
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="font-bold text-lg">{student.name}</h2>
                <span className="px-2 py-0.5 rounded-md bg-white/15 text-xs font-mono">
                  {student.studentId}
                </span>
              </div>
              <p className="text-xs text-blue-200 mt-0.5">
                {student.faculty} • {student.group}-guruh ({student.course}-kurs)
              </p>
              <p className="text-xs text-slate-300 mt-0.5">
                {student.specialtyCode ? `[${student.specialtyCode}] ` : ''}{student.specialty}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Yopish"
            className="p-1.5 rounded-lg hover:bg-white/20 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Summary Counters */}
        <div className="grid grid-cols-3 gap-3 p-5 bg-slate-50 border-b border-slate-200">
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 text-center">
            <div className="text-xl font-extrabold text-blue-600">{currentLoans.length} ta</div>
            <div className="text-[11px] font-semibold text-slate-500 mt-0.5">Hozirda qo'lidagi kitoblar</div>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 text-center">
            <div className="text-xl font-extrabold text-emerald-600">{readLoans.length} ta</div>
            <div className="text-[11px] font-semibold text-slate-500 mt-0.5">Shu vaqtgacha o'qiganlari</div>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 text-center">
            <div className="text-xl font-extrabold text-slate-800">{studentLoans.length} ta</div>
            <div className="text-[11px] font-semibold text-slate-500 mt-0.5">Jami olgan kitoblari</div>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Active Loans */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-blue-600" />
                <span>Hozirda talaba qo'lidagi kitoblar ({currentLoans.length})</span>
              </h3>
              <button
                type="button"
                onClick={() => onIssueToStudent(student.id)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors"
              >
                <BookUp className="w-3.5 h-3.5" />
                <span>Yangi kitob berish</span>
              </button>
            </div>

            {currentLoans.length === 0 ? (
              <div className="p-5 rounded-xl border border-dashed border-slate-300 text-center text-xs text-slate-500">
                Hozircha talabaning qo'lida ijaradagi kitob mavjud emas.
              </div>
            ) : (
              <div className="space-y-2.5">
                {currentLoans.map((loan) => {
                  const isOverdue = loan.status === 'overdue';
                  const days = calculateDaysOverdue(loan.dueDate);

                  return (
                    <div
                      key={loan.id}
                      className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                        isOverdue ? 'bg-rose-50/50 border-rose-200' : 'bg-white border-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={loan.bookCoverUrl}
                          alt={loan.bookTitle}
                          className="w-10 h-14 object-cover rounded shadow-xs flex-shrink-0"
                        />
                        <div>
                          <div className="font-bold text-xs text-slate-900">{loan.bookTitle}</div>
                          <div className="text-[11px] text-slate-500">{loan.bookAuthor}</div>
                          <div className="flex flex-wrap items-center gap-2 mt-1 text-[11px]">
                            <span className="text-slate-500">
                              Olingan: {formatUzbekDate(loan.issueDate)}
                            </span>
                            <span className={`font-semibold ${isOverdue ? 'text-rose-600' : 'text-slate-700'}`}>
                              Muddat: {formatUzbekDate(loan.dueDate)}
                            </span>
                            {isOverdue ? (
                              <span className="inline-flex items-center gap-1 text-rose-700 font-bold">
                                <AlertTriangle className="w-3 h-3" />
                                {days} kun kechikkan ({formatUzbekCurrency(loan.fineAmount)})
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold">
                                <Clock className="w-3 h-3" />
                                Faol
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 flex-shrink-0">
                        <button
                          type="button"
                          onClick={() => onReturnLoan(loan)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition-colors"
                        >
                          <BookCheck className="w-3.5 h-3.5" />
                          <span>Qaytarib olish</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onProlongLoan(loan.id)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-medium transition-colors"
                        >
                          <RotateCw className="w-3 h-3" />
                          <span>+7 kun</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* Previously Read / Returned Books */}
          <section className="space-y-3">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Shu vaqtgacha o'qib topshirgan kitoblari ({readLoans.length})</span>
            </h3>

            {readLoans.length === 0 ? (
              <div className="p-5 rounded-xl border border-dashed border-slate-300 text-center text-xs text-slate-500">
                Talaba hali o'qib topshirgan kitoblar tarixi mavjud emas.
              </div>
            ) : (
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
                {readLoans.map((loan) => (
                  <div key={loan.id} className="p-3.5 bg-white flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-3">
                      <img
                        src={loan.bookCoverUrl}
                        alt={loan.bookTitle}
                        className="w-9 h-12 object-cover rounded shadow-xs flex-shrink-0"
                      />
                      <div>
                        <div className="font-bold text-slate-900">{loan.bookTitle}</div>
                        <div className="text-[11px] text-slate-500">{loan.bookAuthor}</div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-[11px] font-semibold text-emerald-700">
                        Topshirildi: {loan.returnDate ? formatUzbekDate(loan.returnDate) : '—'}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Holati: {loan.conditionOnReturn || 'yaxshi'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold transition-colors"
          >
            Yopish
          </button>
        </div>
      </div>
    </div>
  );
};
