import React, { useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import type { Book } from '../../types/library';
import { EBookReaderModal } from '../common/EBookReaderModal';
import { BookDetailsModal } from '../common/BookDetailsModal';
import { getCategoryImage } from '../../utils/categoryVisuals';
import { getCategoryBookCounts } from '../../utils/libraryRules';
import {
  GraduationCap,
  BookOpen,
  Search,
  LogIn,
  ArrowRight,
  MapPin,
  Clock,
  Shield,
  Award,
  CheckCircle2,
  Bookmark,
  Eye,
  Heart,
  Phone,
  Mail,
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const {
    books,
    categories,
    studentsCount,
    currentUser,
    isAuthenticated,
    siteSettings,
    setCurrentView,
    toggleFavoriteBook,
  } = useLibrary();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [readingBook, setReadingBook] = useState<Book | null>(null);
  const [guestInfoBook, setGuestInfoBook] = useState<Book | null>(null);

  // Filter public catalog
  const filteredBooks = books.filter((b) => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      b.title.toLowerCase().includes(q) ||
      b.author.toLowerCase().includes(q) ||
      b.category.toLowerCase().includes(q) ||
      (b.faculty || '').toLowerCase().includes(q);
    const matchesCat = selectedCategory === 'all' || b.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const categoryCounts = getCategoryBookCounts(categories, books);
  const totalCopies = books.reduce((acc, b) => acc + b.totalCopies, 0);

  const handleOpenBook = (book: Book) => {
    if (isAuthenticated) {
      setReadingBook(book);
    } else {
      setGuestInfoBook(book);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Top University Public Bar — clean single-row 3-zone header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/90">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 gap-4">
            {/* Zone 1: Brand mark + Name */}
            <a
              href="#top"
              className="flex items-center gap-2.5 shrink-0 group focus:outline-hidden"
            >
              {siteSettings.header.logoUrl ? (
                <img
                  src={siteSettings.header.logoUrl}
                  alt={siteSettings.header.brandName}
                  className="w-9 h-9 rounded-xl object-cover border border-slate-200 shadow-xs flex-shrink-0"
                />
              ) : (
                <div className="w-9 h-9 rounded-xl bg-linear-to-br from-blue-700 via-indigo-700 to-purple-800 flex items-center justify-center text-white shadow-sm flex-shrink-0">
                  <GraduationCap className="w-5 h-5" />
                </div>
              )}
              <span className="font-extrabold text-lg sm:text-xl text-slate-900 tracking-tight whitespace-nowrap group-hover:text-blue-700 transition-colors">
                {siteSettings.header.brandName}
              </span>
            </a>

            {/* Zone 2: Clean single-line Navigation */}
            <nav
              aria-label="Asosiy navigatsiya"
              className="hidden md:flex items-center gap-6 lg:gap-8 text-sm font-medium text-slate-600"
            >
              <a
                href="#katalog"
                className="relative py-1 whitespace-nowrap shrink-0 hover:text-slate-950 transition-colors after:absolute after:left-0 after:right-0 after:-bottom-0.5 after:h-0.5 after:bg-blue-600 after:scale-x-0 hover:after:scale-x-100 after:transition-transform after:origin-left"
              >
                {siteSettings.header.navCatalogLabel}
              </a>
              <a
                href="#xizmatlar"
                className="relative py-1 whitespace-nowrap shrink-0 hover:text-slate-950 transition-colors after:absolute after:left-0 after:right-0 after:-bottom-0.5 after:h-0.5 after:bg-blue-600 after:scale-x-0 hover:after:scale-x-100 after:transition-transform after:origin-left"
              >
                {siteSettings.header.navServicesLabel}
              </a>
              <a
                href="#qoidalar"
                className="relative py-1 whitespace-nowrap shrink-0 hover:text-slate-950 transition-colors after:absolute after:left-0 after:right-0 after:-bottom-0.5 after:h-0.5 after:bg-blue-600 after:scale-x-0 hover:after:scale-x-100 after:transition-transform after:origin-left"
              >
                {siteSettings.header.navRulesLabel}
              </a>
              <a
                href="#aloqa"
                className="relative py-1 whitespace-nowrap shrink-0 hover:text-slate-950 transition-colors after:absolute after:left-0 after:right-0 after:-bottom-0.5 after:h-0.5 after:bg-blue-600 after:scale-x-0 hover:after:scale-x-100 after:transition-transform after:origin-left"
              >
                {siteSettings.header.navContactLabel}
              </a>
            </nav>

            {/* Zone 3: Primary CTA */}
            <div className="flex items-center shrink-0">
              {isAuthenticated ? (
                <button
                  type="button"
                  onClick={() => setCurrentView('dashboard')}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm shadow-sm transition-colors whitespace-nowrap shrink-0"
                >
                  <span>Mening kabinetim</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setCurrentView('login')}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm shadow-sm transition-colors whitespace-nowrap shrink-0"
                >
                  <LogIn className="w-4 h-4" />
                  <span>{siteSettings.header.ctaLabel}</span>
                </button>
              )}
            </div>
          </div>

          {/* Mobile compact section jump strip */}
          <nav
            aria-label="Mobil navigatsiya"
            className="flex md:hidden items-center justify-between gap-3 py-2 border-t border-slate-100 text-xs font-medium text-slate-600 overflow-x-auto"
          >
            <a href="#katalog" className="whitespace-nowrap shrink-0 hover:text-blue-600">
              {siteSettings.header.navCatalogLabel}
            </a>
            <a href="#xizmatlar" className="whitespace-nowrap shrink-0 hover:text-blue-600">
              {siteSettings.header.navServicesLabel}
            </a>
            <a href="#qoidalar" className="whitespace-nowrap shrink-0 hover:text-blue-600">
              {siteSettings.header.navRulesLabel}
            </a>
            <a href="#aloqa" className="whitespace-nowrap shrink-0 hover:text-blue-600">
              {siteSettings.header.navContactLabel}
            </a>
          </nav>
        </div>
      </header>

      {/* Hero Section (Supports dynamic gradient, image, or video background) */}
      <section
        id="top"
        className="relative bg-linear-to-br from-slate-900 via-indigo-950 to-slate-900 text-white py-16 sm:py-24 px-4 sm:px-6 lg:px-8 overflow-hidden"
      >
        {siteSettings.banner.backgroundType === 'image' && siteSettings.banner.backgroundMediaUrl && (
          <img
            src={siteSettings.banner.backgroundMediaUrl}
            alt="Universitet kutubxonasi banneri"
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}
        {siteSettings.banner.backgroundType === 'video' && siteSettings.banner.backgroundMediaUrl && (
          <video
            src={siteSettings.banner.backgroundMediaUrl}
            autoPlay
            muted
            loop
            playsInline
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}

        {siteSettings.banner.backgroundType !== 'gradient' && siteSettings.banner.backgroundMediaUrl ? (
          <div
            className="absolute inset-0 bg-slate-950"
            style={{
              opacity: Math.min(0.88, Math.max(0.2, (siteSettings.banner.overlayOpacity ?? 55) / 100)),
            }}
          />
        ) : (
          <>
            <div className="absolute top-1/4 -left-20 w-80 h-80 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-10 right-0 w-96 h-96 bg-purple-500/15 rounded-full blur-3xl pointer-events-none" />
          </>
        )}

        <div className="max-w-5xl mx-auto text-center relative z-10 space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-xs text-blue-200">
            <Award className="w-4 h-4 text-amber-400" />
            <span>{siteSettings.banner.badgeText}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
            {siteSettings.banner.titlePrefix} <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-linear-to-r from-blue-400 via-sky-300 to-teal-300">
              {siteSettings.banner.titleHighlight}
            </span>
          </h1>

          <p className="max-w-2xl mx-auto text-sm sm:text-base text-slate-200 font-normal leading-relaxed">
            {siteSettings.banner.subtitle}
          </p>

          {/* Quick Search Input */}
          <div className="max-w-2xl mx-auto mt-4">
            <div className="relative flex items-center bg-white rounded-2xl p-1.5 shadow-2xl border border-white/20">
              <Search className="w-5 h-5 text-slate-400 ml-3 pointer-events-none" />
              <input
                type="text"
                placeholder={siteSettings.banner.searchPlaceholder}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-3 py-3 text-slate-800 text-sm focus:outline-hidden bg-transparent"
              />
              <a
                href="#katalog"
                className="flex items-center gap-1.5 px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-md transition-colors whitespace-nowrap shrink-0"
              >
                <span>Qidirish</span>
              </a>
            </div>
          </div>

          {/* Key Metrics strip */}
          <div className="pt-10 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-4xl mx-auto">
            <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/15 text-center">
              <div className="text-2xl sm:text-3xl font-extrabold text-blue-300 tabular-nums">{books.length}+ xil</div>
              <div className="text-xs text-slate-300 mt-1">Darslik va nashrlar</div>
            </div>

            <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/15 text-center">
              <div className="text-2xl sm:text-3xl font-extrabold text-teal-300 tabular-nums">{totalCopies} ta</div>
              <div className="text-xs text-slate-300 mt-1">Kutubxona fondi nusxalari</div>
            </div>

            <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/15 text-center">
              <div className="text-2xl sm:text-3xl font-extrabold text-purple-300 tabular-nums">{studentsCount} nafar</div>
              <div className="text-xs text-slate-300 mt-1">Faol ro'yxatdagi talabalar</div>
            </div>

            <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/15 text-center">
              <div className="text-2xl sm:text-3xl font-extrabold text-amber-300 tabular-nums">24 / 7</div>
              <div className="text-xs text-slate-300 mt-1">Elektron o'qish zali</div>
            </div>
          </div>
        </div>
      </section>

      {/* Catalog Search & Showcase Section */}
      <section id="katalog" className="py-14 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        {/* Centered Header */}
        <div className="text-center max-w-3xl mx-auto mb-8 space-y-2">
          <div className="text-xs font-bold uppercase tracking-widest text-blue-600">
            Universitet kutubxona fondi
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            O'quv adabiyotlari va elektron katalog
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Yo'nalish bo'yicha kategoriyani tanlang — har bir kategoriya tarkibidagi kitoblar soni real vaqtda ko'rsatiladi
          </p>
        </div>

        {/* Categories Strip: Small Image + Text + Book Count */}
        <div
          data-testid="landing-categories-grid"
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-3 mb-9"
        >
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`flex items-center gap-3 p-2.5 rounded-2xl border text-left transition-all cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-600/15'
                : 'bg-white border-slate-200/90 text-slate-800 hover:border-blue-300 hover:bg-blue-50/40'
            }`}
          >
            <div
              className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${
                selectedCategory === 'all'
                  ? 'bg-white/20 text-white'
                  : 'bg-blue-50 text-blue-600 border border-blue-100'
              }`}
            >
              <BookOpen className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="font-bold text-xs sm:text-sm truncate">Barchasi</div>
              <div
                className={`text-[11px] font-medium tabular-nums mt-0.5 ${
                  selectedCategory === 'all' ? 'text-blue-100' : 'text-slate-500'
                }`}
              >
                {books.length} ta kitob
              </div>
            </div>
          </button>

          {categories.map((cat, idx) => {
            const count = categoryCounts[cat.name] || 0;
            const isSelected = selectedCategory === cat.name;
            const thumbSrc = getCategoryImage(cat, idx);

            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.name)}
                data-testid={`landing-category-${cat.id}`}
                className={`flex items-center gap-3 p-2.5 rounded-2xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-600/15'
                    : 'bg-white border-slate-200/90 text-slate-800 hover:border-blue-300 hover:bg-blue-50/40'
                }`}
              >
                <img
                  src={thumbSrc}
                  alt={cat.name}
                  className="w-11 h-11 rounded-xl object-cover flex-shrink-0 border border-black/5 bg-slate-100"
                />
                <div className="min-w-0 flex-1">
                  <div className="font-bold text-xs sm:text-sm truncate" title={cat.name}>
                    {cat.name}
                  </div>
                  <div
                    className={`text-[11px] font-medium tabular-nums mt-0.5 ${
                      isSelected ? 'text-blue-100' : 'text-slate-500'
                    }`}
                  >
                    {count} ta kitob
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Book Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {filteredBooks.map((book) => {
            const isAvailable = book.availableCopies > 0;
            const isFavorited = Boolean(currentUser && (book.favoritedBy || []).includes(currentUser.id));

            return (
              <div
                key={book.id}
                className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-lg transition-all flex flex-col justify-between overflow-hidden group"
              >
                <div>
                  <div className="relative aspect-4/3 overflow-hidden bg-slate-100">
                    <img
                      src={book.coverUrl}
                      alt={book.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <span className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-900/80 backdrop-blur-xs text-white max-w-[70%] truncate">
                      {book.category}
                    </span>

                    {/* Favorite toggle button on cover */}
                    <button
                      type="button"
                      onClick={() => toggleFavoriteBook(book.id)}
                      aria-label={`Sevimliga qo'shish: ${book.title}`}
                      className={`absolute top-2.5 right-2.5 p-1.5 rounded-full backdrop-blur-xs shadow-xs transition-all ${
                        isFavorited
                          ? 'bg-rose-600 text-white'
                          : 'bg-white/90 text-slate-600 hover:text-rose-600'
                      }`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${isFavorited ? 'fill-current' : ''}`} />
                    </button>

                    {/* Engagement stats bar overlay on cover bottom */}
                    <div className="absolute bottom-2.5 left-2.5 right-2.5 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 px-2 py-1 rounded-md bg-slate-900/75 backdrop-blur-xs text-white text-[11px] font-semibold">
                        <span className="flex items-center gap-1" title="Ko'rishlar soni">
                          <Eye className="w-3 h-3 text-sky-300" />
                          {book.viewsCount || 0}
                        </span>
                        <span className="text-slate-400">•</span>
                        <span className="flex items-center gap-1" title="Sevimli qilgan talabalar soni">
                          <Heart className="w-3 h-3 text-rose-400 fill-current" />
                          {book.favoritesCount || 0}
                        </span>
                      </div>

                      {book.isEbookAvailable && (
                        <span className="px-2 py-1 rounded-md text-[10px] font-bold bg-blue-600 text-white shadow-xs">
                          PDF
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="p-4 space-y-2">
                    <h3 className="font-bold text-sm text-slate-900 line-clamp-2 leading-snug group-hover:text-blue-600 transition-colors">
                      {book.title}
                    </h3>
                    <p className="text-xs text-slate-500">{book.author}</p>

                    <div className="pt-2 border-t border-slate-100 space-y-1 text-xs text-slate-600">
                      <div className="flex items-center gap-1 text-[11px] text-slate-500">
                        <MapPin className="w-3.5 h-3.5 text-blue-600 flex-shrink-0" />
                        <span className="truncate">
                          {book.location.shelf}, {book.location.section}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-slate-500">
                        <span>{book.viewsCount || 0} marta ko'rildi</span>
                        <span>{book.favoritesCount || 0} ta sevimli</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 pt-0">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold">
                      {isAvailable ? (
                        <span className="text-emerald-600">{book.availableCopies} ta nusxa bor</span>
                      ) : (
                        <span className="text-rose-600">Hozirda band</span>
                      )}
                    </span>
                    <span className="text-[10px] text-slate-400">Jami {book.totalCopies} dona</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => handleOpenBook(book)}
                      className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{isAuthenticated ? "O'qish" : "Ko'rish"}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setCurrentView(isAuthenticated ? 'dashboard' : 'login')}
                      className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors"
                    >
                      <Bookmark className="w-3.5 h-3.5" />
                      <span>Olish</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Library Services Section */}
      <section id="xizmatlar" className="py-16 bg-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
              {siteSettings.services.kicker}
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              {siteSettings.services.title}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-2">
              {siteSettings.services.subtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {siteSettings.services.items.map((srv) => {
              const colorClass = {
                blue: 'bg-blue-100 text-blue-600',
                purple: 'bg-purple-100 text-purple-600',
                emerald: 'bg-emerald-100 text-emerald-600',
                amber: 'bg-amber-100 text-amber-700',
              }[srv.color || 'blue'];

              const iconNode =
                srv.icon === 'shield' ? (
                  <Shield className="w-6 h-6" />
                ) : srv.icon === 'map' ? (
                  <MapPin className="w-6 h-6" />
                ) : srv.icon === 'clock' ? (
                  <Clock className="w-6 h-6" />
                ) : srv.icon === 'award' ? (
                  <Award className="w-6 h-6" />
                ) : srv.icon === 'bookmark' ? (
                  <Bookmark className="w-6 h-6" />
                ) : (
                  <BookOpen className="w-6 h-6" />
                );

              return (
                <div key={srv.id} className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${colorClass}`}>
                    {iconNode}
                  </div>
                  <h3 className="text-base font-bold text-slate-900">{srv.title}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{srv.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Rules & Hours Section */}
      <section id="qoidalar" className="py-14 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
              {siteSettings.rules.kicker}
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {siteSettings.rules.title}
            </h2>
            <div className="space-y-3 text-xs sm:text-sm text-slate-600">
              {siteSettings.rules.items.map((ruleText, idx) => (
                <div key={idx} className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                  <span>{ruleText}</span>
                </div>
              ))}
            </div>
          </div>

          <div id="aloqa" className="bg-linear-to-br from-blue-900 to-indigo-900 text-white p-8 rounded-3xl shadow-xl space-y-6">
            <h3 className="text-xl font-bold">{siteSettings.contact.title}</h3>

            <div className="space-y-3 text-xs">
              <div className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-blue-300 flex-shrink-0" />
                <div>
                  <div className="font-semibold">{siteSettings.contact.scheduleLabel}</div>
                  <div className="text-slate-300">{siteSettings.contact.scheduleValue}</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-blue-300 flex-shrink-0" />
                <div>
                  <div className="font-semibold">{siteSettings.contact.addressLabel}</div>
                  <div className="text-slate-300">{siteSettings.contact.addressValue}</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-blue-300 flex-shrink-0" />
                <div>
                  <div className="font-semibold">{siteSettings.contact.phoneLabel}</div>
                  <div className="font-mono text-slate-300">{siteSettings.contact.phoneValue}</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-blue-300 flex-shrink-0" />
                <div>
                  <div className="font-semibold">{siteSettings.contact.emailLabel}</div>
                  <div className="text-slate-300">{siteSettings.contact.emailValue}</div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-white/10">
              <button
                type="button"
                onClick={() => setCurrentView(isAuthenticated ? 'dashboard' : 'login')}
                className="w-full py-3 px-4 rounded-xl bg-white hover:bg-slate-100 text-blue-900 font-bold text-xs shadow-md transition-colors text-center"
              >
                {isAuthenticated ? 'Kabinetga o\'tish' : siteSettings.contact.buttonText}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-8 text-xs border-t border-slate-800 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            {siteSettings.header.logoUrl ? (
              <img
                src={siteSettings.header.logoUrl}
                alt={siteSettings.footer.brandName}
                className="w-7 h-7 rounded-lg object-cover border border-white/10"
              />
            ) : (
              <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                <GraduationCap className="w-4 h-4" />
              </div>
            )}
            <span className="font-bold text-white">{siteSettings.footer.brandName}</span>
            <span>{siteSettings.footer.description}</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>{siteSettings.footer.rightNote}</span>
            <span>•</span>
            <span>{siteSettings.footer.yearText}</span>
          </div>
        </div>
      </footer>

      {/* Authenticated PDF Reader */}
      {readingBook && (
        <EBookReaderModal book={readingBook} onClose={() => setReadingBook(null)} />
      )}

      {/* Guest Book Metadata Info Modal */}
      {guestInfoBook && (
        <BookDetailsModal
          book={guestInfoBook}
          onClose={() => setGuestInfoBook(null)}
          onLoginClick={() => {
            setGuestInfoBook(null);
            setCurrentView('login');
          }}
        />
      )}
    </div>
  );
};
