import React, { useEffect, useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import type { SiteServiceItem, SiteSettings } from '../../types/library';
import {
  LayoutTemplate,
  Sparkles,
  ScrollText,
  PhoneCall,
  Image as ImageIcon,
  Upload,
  Video,
  Save,
  Plus,
  Trash2,
  RotateCcw,
  CheckCircle2,
  BookOpen,
  Shield,
  MapPin,
  Award,
  Clock,
  Bookmark,
} from 'lucide-react';

export type SiteSettingsSubTab = 'footer' | 'services' | 'rules' | 'contact' | 'banner';

interface SiteSettingsPanelProps {
  activeSubTab: SiteSettingsSubTab;
  onSelectSubTab: (sub: SiteSettingsSubTab) => void;
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error("Faylni o'qib bo'lmadi"));
    reader.readAsDataURL(file);
  });
}

export const SiteSettingsPanel: React.FC<SiteSettingsPanelProps> = ({
  activeSubTab,
  onSelectSubTab,
}) => {
  const { siteSettings, updateSiteSettings, uploadServerFile, showToast } = useLibrary();

  const [draft, setDraft] = useState<SiteSettings>(siteSettings);
  const [isSaving, setIsSaving] = useState(false);
  const [uploadingField, setUploadingField] = useState<'logo' | 'banner' | null>(null);

  useEffect(() => {
    setDraft(siteSettings);
  }, [siteSettings]);

  const handleSave = async (partial?: Partial<SiteSettings>) => {
    setIsSaving(true);
    try {
      await updateSiteSettings(partial || draft);
    } finally {
      setIsSaving(false);
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('Iltimos, logotip uchun faqat rasm fayl tanlang!', 'error');
      return;
    }
    setUploadingField('logo');
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const uploaded = await uploadServerFile(dataUrl, file.name, file.type);
      if (uploaded) {
        setDraft((prev) => ({
          ...prev,
          header: { ...prev.header, logoUrl: uploaded.url },
        }));
        showToast('Logotip yuklandi. Saqlash tugmasini bosing.', 'info');
      }
    } catch {
      showToast('Logotipni yuklashda xatolik yuz berdi', 'error');
    } finally {
      setUploadingField(null);
    }
  };

  const handleBannerMediaUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    targetMode: 'image' | 'video'
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    const maxBytes = targetMode === 'video' ? 40 * 1024 * 1024 : 15 * 1024 * 1024;
    if (file.size > maxBytes) {
      showToast(
        targetMode === 'video'
          ? 'Video hajmi 40 MB dan oshmasligi kerak!'
          : 'Rasm hajmi 15 MB dan oshmasligi kerak!',
        'error'
      );
      return;
    }

    setUploadingField('banner');
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const uploaded = await uploadServerFile(
        dataUrl,
        file.name,
        file.type || (targetMode === 'video' ? 'video/mp4' : 'image/jpeg')
      );
      if (uploaded) {
        setDraft((prev) => ({
          ...prev,
          banner: {
            ...prev.banner,
            backgroundType: targetMode,
            backgroundMediaUrl: uploaded.url,
          },
        }));
        showToast(
          targetMode === 'video'
            ? 'Banner videosi yuklandi. Saqlash tugmasini bosing.'
            : 'Banner rasmi yuklandi. Saqlash tugmasini bosing.',
          'info'
        );
      }
    } catch {
      showToast('Media faylni yuklashda xatolik yuz berdi', 'error');
    } finally {
      setUploadingField(null);
    }
  };

  const subTabs: Array<{ id: SiteSettingsSubTab; label: string; icon: React.ReactNode }> = [
    { id: 'footer', label: 'Footerlar', icon: <LayoutTemplate className="w-3.5 h-3.5" /> },
    { id: 'services', label: 'Xizmatlar', icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'rules', label: 'Qoidalar', icon: <ScrollText className="w-3.5 h-3.5" /> },
    { id: 'contact', label: "Bog'lanish", icon: <PhoneCall className="w-3.5 h-3.5" /> },
    { id: 'banner', label: 'Banner', icon: <ImageIcon className="w-3.5 h-3.5" /> },
  ];

  const updateServiceItem = (index: number, patch: Partial<SiteServiceItem>) => {
    setDraft((prev) => {
      const next = [...prev.services.items];
      next[index] = { ...next[index], ...patch };
      return {
        ...prev,
        services: { ...prev.services, items: next },
      };
    });
  };

  const addServiceItem = () => {
    const newItem: SiteServiceItem = {
      id: `srv-${Date.now()}`,
      title: 'Yangi xizmat nomi',
      description: 'Xizmat haqida qisqacha maʼlumot va talabalar uchun foydali jihatlar.',
      icon: 'book',
      color: 'blue',
    };
    setDraft((prev) => ({
      ...prev,
      services: { ...prev.services, items: [...prev.services.items, newItem] },
    }));
  };

  const removeServiceItem = (index: number) => {
    setDraft((prev) => ({
      ...prev,
      services: {
        ...prev.services,
        items: prev.services.items.filter((_, idx) => idx !== index),
      },
    }));
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Top Section Header + Clean Horizontal Submenu Strip */}
      <div className="px-6 pt-5 pb-4 border-b border-slate-200 bg-slate-50/70 space-y-4">
        <div>
          <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
            Sayt sozlamalari va bosh sahifa kontenti
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            O&apos;zgarishlar saqlangandan so&apos;ng barcha foydalanuvchilar uchun bosh sahifada darhol aks etadi
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {subTabs.map((t) => {
            const active = t.id === activeSubTab;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => onSelectSubTab(t.id)}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
                  active
                    ? 'bg-purple-600 text-white shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {t.icon}
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* 1. FOOTERLAR (Top Header + Bottom Footer) */}
        {activeSubTab === 'footer' && (
          <div className="space-y-6">
            {/* Top Header Config */}
            <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-4">
              <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-200">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Saytning yuqori qismi (Yuqori panel / Header)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Logotip, brend nomi, menyu linklari va kirish tugmasi matnini tahrirlang
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Portal / Universitet nomi
                  </label>
                  <input
                    type="text"
                    value={draft.header.brandName}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        header: { ...prev.header, brandName: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                    placeholder="Masalan: UniLib"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kirish tugmasi matni (Mehmonlar uchun)
                  </label>
                  <input
                    type="text"
                    value={draft.header.ctaLabel}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        header: { ...prev.header, ctaLabel: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              {/* Logo Upload */}
              <div className="flex flex-col sm:flex-row sm:items-center gap-4 pt-2">
                <div className="flex items-center gap-3">
                  {draft.header.logoUrl ? (
                    <img
                      src={draft.header.logoUrl}
                      alt="Sayt logotipi"
                      className="w-12 h-12 rounded-xl object-cover border border-slate-300 bg-white"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-xl bg-linear-to-br from-blue-700 to-indigo-700 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                      Logo
                    </div>
                  )}
                  <div className="text-xs text-slate-600">
                    <div className="font-semibold text-slate-800">Yuqori panel logotipi</div>
                    <div className="text-[11px] text-slate-500">PNG, SVG yoki JPG rasm yuklang</div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 sm:ml-auto">
                  <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-xs font-semibold text-slate-700 cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploadingField === 'logo' ? 'Yuklanmoqda...' : 'Logotip yuklash'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="sr-only"
                    />
                  </label>
                  {draft.header.logoUrl && (
                    <button
                      type="button"
                      onClick={() =>
                        setDraft((prev) => ({
                          ...prev,
                          header: { ...prev.header, logoUrl: '' },
                        }))
                      }
                      className="inline-flex items-center gap-1 px-3 py-2 rounded-xl border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-semibold"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Standart ikona</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Navigation labels */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    1-menyu (Katalog)
                  </label>
                  <input
                    type="text"
                    value={draft.header.navCatalogLabel}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        header: { ...prev.header, navCatalogLabel: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    2-menyu (Xizmatlar)
                  </label>
                  <input
                    type="text"
                    value={draft.header.navServicesLabel}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        header: { ...prev.header, navServicesLabel: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    3-menyu (Qoidalar)
                  </label>
                  <input
                    type="text"
                    value={draft.header.navRulesLabel}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        header: { ...prev.header, navRulesLabel: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    4-menyu (Aloqa)
                  </label>
                  <input
                    type="text"
                    value={draft.header.navContactLabel}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        header: { ...prev.header, navContactLabel: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs"
                  />
                </div>
              </div>
            </div>

            {/* Bottom Footer Config */}
            <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-4">
              <div className="pb-3 border-b border-slate-200">
                <h3 className="text-sm font-bold text-slate-900">
                  Saytning pastki qismi (Pastki footer)
                </h3>
                <p className="text-xs text-slate-500">
                  Bosh sahifa eng pastki qismidagi tashkilot nomi, tavsif va mualliflik yilini kiriting
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Footer brend nomi
                  </label>
                  <input
                    type="text"
                    value={draft.footer.brandName}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        footer: { ...prev.footer, brandName: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Yil / Mualliflik matni
                  </label>
                  <input
                    type="text"
                    value={draft.footer.yearText}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        footer: { ...prev.footer, yearText: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Chap taraf tavsifi
                  </label>
                  <input
                    type="text"
                    value={draft.footer.description}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        footer: { ...prev.footer, description: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    O&apos;ng taraf qo&apos;shimcha yozuvi
                  </label>
                  <input
                    type="text"
                    value={draft.footer.rightNote}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        footer: { ...prev.footer, rightNote: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                disabled={isSaving}
                onClick={() => handleSave({ header: draft.header, footer: draft.footer })}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-semibold shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saqlanmoqda...' : 'Footer va header sozlamalarini saqlash'}</span>
              </button>
            </div>
          </div>
        )}

        {/* 2. XIZMATLAR */}
        {activeSubTab === 'services' && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 rounded-2xl border border-slate-200 bg-slate-50/50">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Bo&apos;lim sarlavhachasi
                </label>
                <input
                  type="text"
                  value={draft.services.kicker}
                  onChange={(e) =>
                    setDraft((prev) => ({
                      ...prev,
                      services: { ...prev.services, kicker: e.target.value },
                    }))
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Asosiy sarlavha
                </label>
                <input
                  type="text"
                  value={draft.services.title}
                  onChange={(e) =>
                    setDraft((prev) => ({
                      ...prev,
                      services: { ...prev.services, title: e.target.value },
                    }))
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                />
              </div>
              <div className="md:col-span-3">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Izoh matni
                </label>
                <input
                  type="text"
                  value={draft.services.subtitle}
                  onChange={(e) =>
                    setDraft((prev) => ({
                      ...prev,
                      services: { ...prev.services, subtitle: e.target.value },
                    }))
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                Kutubxona xizmatlari kartochkalari ({draft.services.items.length} ta)
              </h3>
              <button
                type="button"
                onClick={addServiceItem}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200 text-xs font-semibold"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Yangi xizmat qo&apos;shish</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {draft.services.items.map((srv, idx) => (
                <div
                  key={srv.id}
                  className="p-4 rounded-2xl border border-slate-200 bg-white space-y-3 flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-bold text-slate-400">#{idx + 1}</span>
                      <button
                        type="button"
                        onClick={() => removeServiceItem(idx)}
                        disabled={draft.services.items.length <= 1}
                        className="text-rose-600 hover:bg-rose-50 disabled:opacity-30 p-1 rounded-lg"
                        title="O'chirish"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Xizmat nomi
                      </label>
                      <input
                        type="text"
                        value={srv.title}
                        onChange={(e) => updateServiceItem(idx, { title: e.target.value })}
                        className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Tavsif
                      </label>
                      <textarea
                        rows={3}
                        value={srv.description}
                        onChange={(e) => updateServiceItem(idx, { description: e.target.value })}
                        className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs resize-none"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                          Ikona
                        </label>
                        <select
                          value={srv.icon}
                          onChange={(e) =>
                            updateServiceItem(idx, {
                              icon: e.target.value as SiteServiceItem['icon'],
                            })
                          }
                          className="w-full px-2 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                        >
                          <option value="book">Kitob</option>
                          <option value="shield">Qalqon</option>
                          <option value="map">Joylashuv</option>
                          <option value="clock">Soat</option>
                          <option value="award">Sertifikat</option>
                          <option value="bookmark">Xatcho&apos;p</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                          Rang
                        </label>
                        <select
                          value={srv.color}
                          onChange={(e) =>
                            updateServiceItem(idx, {
                              color: e.target.value as SiteServiceItem['color'],
                            })
                          }
                          className="w-full px-2 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                        >
                          <option value="blue">Ko&apos;k</option>
                          <option value="purple">Binafsha</option>
                          <option value="emerald">Yashil</option>
                          <option value="amber">Sariq</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                disabled={isSaving}
                onClick={() => handleSave({ services: draft.services })}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-semibold shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saqlanmoqda...' : 'Xizmatlarni saqlash'}</span>
              </button>
            </div>
          </div>
        )}

        {/* 3. QOIDALAR */}
        {activeSubTab === 'rules' && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-2xl border border-slate-200 bg-slate-50/50">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Bo&apos;lim nomi
                </label>
                <input
                  type="text"
                  value={draft.rules.kicker}
                  onChange={(e) =>
                    setDraft((prev) => ({
                      ...prev,
                      rules: { ...prev.rules, kicker: e.target.value },
                    }))
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Qoidalar sarlavhasi
                </label>
                <input
                  type="text"
                  value={draft.rules.title}
                  onChange={(e) =>
                    setDraft((prev) => ({
                      ...prev,
                      rules: { ...prev.rules, title: e.target.value },
                    }))
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                Kutubxona tartib-qoidalari ro&apos;yxati ({draft.rules.items.length} ta band)
              </h3>
              <button
                type="button"
                onClick={() =>
                  setDraft((prev) => ({
                    ...prev,
                    rules: {
                      ...prev.rules,
                      items: [...prev.rules.items, 'Yangi tartib-qoida matnini kiriting...'],
                    },
                  }))
                }
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200 text-xs font-semibold"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Qoida qo&apos;shish</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {draft.rules.items.map((ruleText, idx) => (
                <div key={idx} className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={ruleText}
                    onChange={(e) => {
                      const next = [...draft.rules.items];
                      next[idx] = e.target.value;
                      setDraft((prev) => ({
                        ...prev,
                        rules: { ...prev.rules, items: next },
                      }));
                    }}
                    className="flex-1 px-3 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                  />
                  <button
                    type="button"
                    disabled={draft.rules.items.length <= 1}
                    onClick={() =>
                      setDraft((prev) => ({
                        ...prev,
                        rules: {
                          ...prev.rules,
                          items: prev.rules.items.filter((_, i) => i !== idx),
                        },
                      }))
                    }
                    className="p-2 rounded-xl border border-rose-200 text-rose-600 hover:bg-rose-50 disabled:opacity-30"
                    title="O'chirish"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                disabled={isSaving}
                onClick={() => handleSave({ rules: draft.rules })}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-semibold shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saqlanmoqda...' : 'Qoidalarni saqlash'}</span>
              </button>
            </div>
          </div>
        )}

        {/* 4. BOG'LANISH */}
        {activeSubTab === 'contact' && (
          <div className="space-y-5">
            <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Blok sarlavhasi
                </label>
                <input
                  type="text"
                  value={draft.contact.title}
                  onChange={(e) =>
                    setDraft((prev) => ({
                      ...prev,
                      contact: { ...prev.contact, title: e.target.value },
                    }))
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm font-semibold"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Ish vaqti nomi
                  </label>
                  <input
                    type="text"
                    value={draft.contact.scheduleLabel}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        contact: { ...prev.contact, scheduleLabel: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Ish vaqti qiymati
                  </label>
                  <input
                    type="text"
                    value={draft.contact.scheduleValue}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        contact: { ...prev.contact, scheduleValue: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Manzil nomi
                  </label>
                  <input
                    type="text"
                    value={draft.contact.addressLabel}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        contact: { ...prev.contact, addressLabel: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Manzil qiymati
                  </label>
                  <input
                    type="text"
                    value={draft.contact.addressValue}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        contact: { ...prev.contact, addressValue: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Telefon nomi
                  </label>
                  <input
                    type="text"
                    value={draft.contact.phoneLabel}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        contact: { ...prev.contact, phoneLabel: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Telefon raqami
                  </label>
                  <input
                    type="text"
                    value={draft.contact.phoneValue}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        contact: { ...prev.contact, phoneValue: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Elektron manzil nomi
                  </label>
                  <input
                    type="text"
                    value={draft.contact.emailLabel}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        contact: { ...prev.contact, emailLabel: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Elektron pochta qiymati
                  </label>
                  <input
                    type="text"
                    value={draft.contact.emailValue}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        contact: { ...prev.contact, emailValue: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Pastki tugma matni
                </label>
                <input
                  type="text"
                  value={draft.contact.buttonText}
                  onChange={(e) =>
                    setDraft((prev) => ({
                      ...prev,
                      contact: { ...prev.contact, buttonText: e.target.value },
                    }))
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
                />
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                disabled={isSaving}
                onClick={() => handleSave({ contact: draft.contact })}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-semibold shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saqlanmoqda...' : "Bog'lanish ma'lumotlarini saqlash"}</span>
              </button>
            </div>
          </div>
        )}

        {/* 5. BANNER */}
        {activeSubTab === 'banner' && (
          <div className="space-y-5">
            {/* Live Preview */}
            <div className="relative rounded-2xl overflow-hidden border border-slate-300 bg-linear-to-br from-slate-900 via-indigo-950 to-slate-900 text-white p-6 sm:p-8 min-h-[210px] flex flex-col justify-center items-center text-center">
              {draft.banner.backgroundType === 'image' && draft.banner.backgroundMediaUrl && (
                <img
                  src={draft.banner.backgroundMediaUrl}
                  alt="Banner foni"
                  className="absolute inset-0 w-full h-full object-cover"
                />
              )}
              {draft.banner.backgroundType === 'video' && draft.banner.backgroundMediaUrl && (
                <video
                  src={draft.banner.backgroundMediaUrl}
                  autoPlay
                  muted
                  loop
                  playsInline
                  className="absolute inset-0 w-full h-full object-cover"
                />
              )}
              <div
                className="absolute inset-0 bg-slate-950 transition-opacity"
                style={{
                  opacity:
                    draft.banner.backgroundType === 'gradient'
                      ? 0
                      : Math.min(0.88, Math.max(0.2, (draft.banner.overlayOpacity ?? 55) / 100)),
                }}
              />
              <div className="relative z-10 max-w-2xl space-y-2">
                <span className="inline-block px-3 py-1 rounded-full bg-white/10 border border-white/15 text-[11px] text-blue-200">
                  {draft.banner.badgeText}
                </span>
                <h4 className="text-xl sm:text-2xl font-extrabold">
                  {draft.banner.titlePrefix}{' '}
                  <span className="text-sky-300">{draft.banner.titleHighlight}</span>
                </h4>
                <p className="text-xs text-slate-200 line-clamp-2">{draft.banner.subtitle}</p>
              </div>
            </div>

            {/* Background Mode & Upload Controls */}
            <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Banner orqa fon turi</h3>
                  <p className="text-xs text-slate-500">
                    Bosh sahifa banneri orqasiga rasm yoki video yuklang yoxud standart gradientdan foydalaning
                  </p>
                </div>

                <div className="inline-flex rounded-xl bg-white p-1 border border-slate-200">
                  {[
                    { id: 'gradient', label: 'Standart fon' },
                    { id: 'image', label: 'Rasm (Image)' },
                    { id: 'video', label: 'Video (MP4/WebM)' },
                  ].map((mode) => (
                    <button
                      key={mode.id}
                      type="button"
                      onClick={() =>
                        setDraft((prev) => ({
                          ...prev,
                          banner: {
                            ...prev.banner,
                            backgroundType: mode.id as 'gradient' | 'image' | 'video',
                          },
                        }))
                      }
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        draft.banner.backgroundType === mode.id
                          ? 'bg-purple-600 text-white shadow-xs'
                          : 'text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {mode.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <label className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-xs font-semibold text-slate-800 cursor-pointer shadow-xs">
                  <ImageIcon className="w-4 h-4 text-purple-600" />
                  <span>
                    {uploadingField === 'banner' ? 'Yuklanmoqda...' : 'Banner uchun rasm yuklash'}
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleBannerMediaUpload(e, 'image')}
                    className="sr-only"
                  />
                </label>

                <label className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-xs font-semibold text-slate-800 cursor-pointer shadow-xs">
                  <Video className="w-4 h-4 text-blue-600" />
                  <span>
                    {uploadingField === 'banner' ? 'Yuklanmoqda...' : 'Banner uchun video yuklash'}
                  </span>
                  <input
                    type="file"
                    accept="video/mp4,video/webm,video/ogg,.mp4,.webm,.mov"
                    onChange={(e) => handleBannerMediaUpload(e, 'video')}
                    className="sr-only"
                  />
                </label>

                {draft.banner.backgroundMediaUrl && (
                  <button
                    type="button"
                    onClick={() =>
                      setDraft((prev) => ({
                        ...prev,
                        banner: { ...prev.banner, backgroundType: 'gradient', backgroundMediaUrl: '' },
                      }))
                    }
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-semibold"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Orqa fonni tozalash</span>
                  </button>
                )}
              </div>

              {draft.banner.backgroundType !== 'gradient' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Media manzili (URL yoki yuklangan fayl)
                    </label>
                    <input
                      type="text"
                      value={draft.banner.backgroundMediaUrl}
                      onChange={(e) =>
                        setDraft((prev) => ({
                          ...prev,
                          banner: { ...prev.banner, backgroundMediaUrl: e.target.value },
                        }))
                      }
                      placeholder="/api/files/... yoki https://..."
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Qoraytirish qatlami ({draft.banner.overlayOpacity ?? 55}%) — matn aniq ko&apos;rinishi uchun
                    </label>
                    <input
                      type="range"
                      min={20}
                      max={85}
                      value={draft.banner.overlayOpacity ?? 55}
                      onChange={(e) =>
                        setDraft((prev) => ({
                          ...prev,
                          banner: { ...prev.banner, overlayOpacity: Number(e.target.value) },
                        }))
                      }
                      className="w-full accent-purple-600 mt-2"
                    />
                  </div>
                </div>
              )}

              {/* Banner Text Inputs */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-200">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Yuqori nishoncha matni
                  </label>
                  <input
                    type="text"
                    value={draft.banner.badgeText}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        banner: { ...prev.banner, badgeText: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Qidiruv qutisi ichidagi matn
                  </label>
                  <input
                    type="text"
                    value={draft.banner.searchPlaceholder}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        banner: { ...prev.banner, searchPlaceholder: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Asosiy sarlavha (1-qism)
                  </label>
                  <input
                    type="text"
                    value={draft.banner.titlePrefix}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        banner: { ...prev.banner, titlePrefix: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Ajratilgan sarlavha (2-qism)
                  </label>
                  <input
                    type="text"
                    value={draft.banner.titleHighlight}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        banner: { ...prev.banner, titleHighlight: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Banner tavsif matni
                  </label>
                  <textarea
                    rows={2}
                    value={draft.banner.subtitle}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        banner: { ...prev.banner, subtitle: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs resize-none"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                disabled={isSaving}
                onClick={() => handleSave({ banner: draft.banner })}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-semibold shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saqlanmoqda...' : 'Banner sozlamalarini saqlash'}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Keep helper icons referenced cleanly for service previews if needed later
export function renderServiceIcon(icon: SiteServiceItem['icon'], className = 'w-6 h-6') {
  switch (icon) {
    case 'shield':
      return <Shield className={className} />;
    case 'map':
      return <MapPin className={className} />;
    case 'clock':
      return <Clock className={className} />;
    case 'award':
      return <Award className={className} />;
    case 'bookmark':
      return <Bookmark className={className} />;
    case 'book':
    default:
      return <BookOpen className={className} />;
  }
}
