import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { useLibrary } from '../../context/LibraryContext';
import { mapExcelRowsToStudents, ParsedImportStudentRow } from '../../utils/libraryRules';
import {
  X,
  FileSpreadsheet,
  Download,
  Upload,
  CheckCircle2,
  AlertTriangle,
  Users,
  Check,
} from 'lucide-react';

interface ExcelImportModalProps {
  onClose: () => void;
}

export const ExcelImportModal: React.FC<ExcelImportModalProps> = ({ onClose }) => {
  const { specialties, faculties, students, bulkCreateStudents, showToast } = useLibrary();

  const [parsedRows, setParsedRows] = useState<ParsedImportStudentRow[]>([]);
  const [fileName, setFileName] = useState('');
  const [parseError, setParseError] = useState('');
  const [isImporting, setIsImporting] = useState(false);

  const handleDownloadTemplate = () => {
    const sampleSpecs = specialties.slice(0, 3);
    const sampleData = [
      {
        'Ism Familiya': 'Kamoliddin Tursunov',
        'Talaba ID': `TAL-2026-${Math.floor(100 + Math.random() * 800)}`,
        "Yo'nalish shifri": sampleSpecs[0]?.code || '60610600',
        Kurs: 2,
        Guruh: '915-22',
        Telefon: '+998 90 111 22 33',
        Email: 'kamoliddin@univ.uz',
        Parol: 'student123',
      },
      {
        'Ism Familiya': 'Madina Karimova',
        'Talaba ID': `TAL-2026-${Math.floor(100 + Math.random() * 800)}`,
        "Yo'nalish shifri": sampleSpecs[1]?.code || '60610700',
        Kurs: 1,
        Guruh: '916-23',
        Telefon: '+998 93 444 55 66',
        Email: 'madina@univ.uz',
        Parol: 'student123',
      },
    ];

    const worksheet = XLSX.utils.json_to_sheet(sampleData);
    worksheet['!cols'] = [
      { wch: 24 },
      { wch: 16 },
      { wch: 18 },
      { wch: 8 },
      { wch: 12 },
      { wch: 18 },
      { wch: 24 },
      { wch: 14 },
    ];
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Talabalar');
    XLSX.writeFile(workbook, 'talabalar_shablon.xlsx');
    showToast('Namuna Excel fayli yuklab olindi!', 'info');
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setParseError('');
    setFileName(file.name);

    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });
      const firstSheetName = workbook.SheetNames[0];
      if (!firstSheetName) {
        setParseError('Excel faylida varaq (sheet) topilmadi!');
        return;
      }
      const worksheet = workbook.Sheets[firstSheetName];
      const jsonRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(worksheet, { defval: '' });

      if (jsonRows.length === 0) {
        setParseError("Tanlangan faylda talaba ma'lumotlari topilmadi!");
        setParsedRows([]);
        return;
      }

      const mapped = mapExcelRowsToStudents(
        jsonRows,
        specialties,
        students,
        faculties[0]?.name || 'Axborot texnologiyalari va dasturiy injiniring'
      );
      setParsedRows(mapped);
    } catch {
      setParseError("Excel faylni o'qishda xatolik yuz berdi. Iltimos, .xlsx yoki .csv formatdan foydalaning.");
      setParsedRows([]);
    }
  };

  const validRows = parsedRows.filter((r) => !r.error);
  const errorRows = parsedRows.filter((r) => r.error);

  const handleConfirmImport = async () => {
    if (validRows.length === 0) return;
    setIsImporting(true);
    try {
      const count = await bulkCreateStudents(
        validRows.map((r) => ({
          studentId: r.studentId,
          name: r.name,
          email: r.email,
          phone: r.phone,
          faculty: r.faculty,
          specialty: r.specialtyName,
          specialtyCode: r.specialtyCode,
          course: r.course,
          group: r.group,
          status: 'active',
          password: r.password,
          avatarUrl: '',
          notes: `Exceldan import (${r.specialtyCode || 'shifrsiz'})`,
        }))
      );
      if (count > 0) {
        onClose();
      }
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-linear-to-r from-emerald-700 to-teal-700 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/20 backdrop-blur-xs">
              <FileSpreadsheet className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-lg">Exceldan talabalarni ommaviy import qilish</h2>
              <p className="text-xs text-emerald-100">
                Yo'nalish shifri orqali tizimdagi mos yo'nalish nomi avtomatik topilib saqlanadi
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Yopish"
            className="p-1.5 rounded-lg hover:bg-white/20 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Instructions + Download Template */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                1-qadam: Excel shablonini yuklab oling yoki tayyor faylni yuklang
              </h3>
              <p className="text-xs text-slate-500">
                Ustunlar:{' '}
                <span className="font-mono text-slate-700">
                  Ism Familiya, Talaba ID, Yo'nalish shifri, Kurs, Guruh, Telefon, Email, Parol
                </span>
              </p>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {specialties.slice(0, 4).map((s) => (
                  <span
                    key={s.id}
                    className="text-[10px] px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-600"
                  >
                    <strong className="font-mono text-purple-700">{s.code}</strong> → {s.name}
                  </span>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={handleDownloadTemplate}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 text-xs font-semibold shadow-xs flex-shrink-0 transition-colors"
            >
              <Download className="w-4 h-4 text-emerald-600" />
              <span>Shablon yuklab olish (.xlsx)</span>
            </button>
          </div>

          {/* File Upload Dropzone */}
          <div>
            <label
              htmlFor="excel-upload-input"
              className="flex flex-col items-center justify-center p-6 rounded-2xl border-2 border-dashed border-emerald-300 bg-emerald-50/40 hover:bg-emerald-50 cursor-pointer transition-colors text-center"
            >
              <Upload className="w-8 h-8 text-emerald-600 mb-2" />
              <span className="text-sm font-bold text-slate-800">
                {fileName ? `Tanlangan fayl: ${fileName}` : 'Excel faylini tanlang (.xlsx, .xls, .csv)'}
              </span>
              <span className="text-xs text-slate-500 mt-1">
                Yuklangan qatorlar avtomatik tekshirilib, yo'nalish shifrlari tizimga moslanadi
              </span>
              <input
                id="excel-upload-input"
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleFileChange}
                className="sr-only"
              />
            </label>
          </div>

          {parseError && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{parseError}</span>
            </div>
          )}

          {/* Preview Table */}
          {parsedRows.length > 0 && (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-600" />
                  <span>Import tekshiruvi: Jami {parsedRows.length} ta qator</span>
                </h3>
                <div className="flex items-center gap-2 text-xs">
                  <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                    Tayyor: {validRows.length} ta
                  </span>
                  {errorRows.length > 0 && (
                    <span className="px-2.5 py-1 rounded-full bg-rose-100 text-rose-700 font-bold">
                      Xatoli: {errorRows.length} ta
                    </span>
                  )}
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-x-auto max-h-72">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-[11px] uppercase text-slate-500 font-bold sticky top-0">
                    <tr>
                      <th className="px-3 py-2.5">#</th>
                      <th className="px-3 py-2.5">Ism Familiya</th>
                      <th className="px-3 py-2.5">Talaba ID</th>
                      <th className="px-3 py-2.5">Shifr</th>
                      <th className="px-3 py-2.5">Mos Yo'nalish nomi</th>
                      <th className="px-3 py-2.5">Guruh / Kurs</th>
                      <th className="px-3 py-2.5">Holat</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {parsedRows.map((row) => (
                      <tr key={row.rowNumber} className={row.error ? 'bg-rose-50/60' : 'bg-white'}>
                        <td className="px-3 py-2.5 text-slate-400 font-mono">{row.rowNumber}</td>
                        <td className="px-3 py-2.5 font-bold text-slate-900">{row.name || '—'}</td>
                        <td className="px-3 py-2.5 font-mono text-slate-700">{row.studentId}</td>
                        <td className="px-3 py-2.5 font-mono font-semibold text-purple-700">
                          {row.specialtyCode || '—'}
                        </td>
                        <td className="px-3 py-2.5">
                          <div className="font-semibold text-slate-800">{row.specialtyName}</div>
                          <div className="text-[10px] text-slate-400">{row.faculty}</div>
                        </td>
                        <td className="px-3 py-2.5">
                          {row.group || '—'} ({row.course}-kurs)
                        </td>
                        <td className="px-3 py-2.5">
                          {row.error ? (
                            <span className="inline-flex items-center gap-1 text-rose-700 font-semibold">
                              <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                              {row.error}
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold">
                              <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
                              {row.matchedSpecialty ? 'Shifr moslandi' : 'Tayyor'}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Faqat xatosiz ({validRows.length} ta) talabalar tizimga saqlanadi
          </span>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold transition-colors"
            >
              Bekor qilish
            </button>
            <button
              type="button"
              disabled={validRows.length === 0 || isImporting}
              onClick={handleConfirmImport}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-semibold shadow-md shadow-emerald-500/20 transition-all"
            >
              <Check className="w-4 h-4" />
              <span>{isImporting ? 'Saqlanmoqda...' : `${validRows.length} ta talabani import qilish`}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
