import React, { useEffect, useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import type { Specialty } from '../../types/library';
import { Compass, PlusCircle, Trash2, Users, Search, AlertCircle, Pencil, Check, X } from 'lucide-react';

export const SpecialtiesManager: React.FC = () => {
  const { specialties, faculties, students, createSpecialty, updateSpecialty, deleteSpecialty } = useLibrary();

  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [faculty, setFaculty] = useState(faculties[0]?.name || '');
  const [search, setSearch] = useState('');
  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editCode, setEditCode] = useState('');
  const [editName, setEditName] = useState('');
  const [editFaculty, setEditFaculty] = useState('');

  useEffect(() => {
    if (!faculty && faculties.length > 0) {
      setFaculty(faculties[0].name);
    }
  }, [faculties, faculty]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSaving(true);
    try {
      const res = await createSpecialty({ code, name, faculty });
      if (!res.success) {
        setError(res.message);
        return;
      }
      setCode('');
      setName('');
    } finally {
      setIsSaving(false);
    }
  };

  const startEdit = (spec: Specialty) => {
    setEditingId(spec.id);
    setEditCode(spec.code);
    setEditName(spec.name);
    setEditFaculty(spec.faculty);
    setError('');
  };

  const handleSaveEdit = async (id: string) => {
    setError('');
    const res = await updateSpecialty(id, {
      code: editCode,
      name: editName,
      faculty: editFaculty,
    });
    if (!res.success) {
      setError(res.message);
      return;
    }
    setEditingId(null);
  };

  const filtered = specialties.filter(
    (s) =>
      s.code.toLowerCase().includes(search.toLowerCase()) ||
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.faculty.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Create Specialty Form */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6">
        <div className="flex items-center gap-2.5 mb-4">
          <div className="p-2 rounded-xl bg-purple-100 text-purple-600">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-base text-slate-900">Yangi ta'lim yo'nalishi va shifr qo'shish</h2>
            <p className="text-xs text-slate-500">
              Exceldan ko'plab talabalarni import qilganda yo'nalish shifri orqali mos yo'nalish nomi avtomatik biriktiriladi
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-4 flex items-center gap-2 p-3 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-medium">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          <div className="md:col-span-3">
            <label htmlFor="spec-code-input" className="block text-xs font-semibold text-slate-700 mb-1">
              Yo'nalish shifri (Kod) *
            </label>
            <input
              id="spec-code-input"
              type="text"
              required
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Masalan: 60610800"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="md:col-span-4">
            <label htmlFor="spec-name-input" className="block text-xs font-semibold text-slate-700 mb-1">
              Yo'nalish nomi *
            </label>
            <input
              id="spec-name-input"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Masalan: Kiberxavfsizlik injiniringi"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="md:col-span-3">
            <label htmlFor="spec-faculty-select" className="block text-xs font-semibold text-slate-700 mb-1">
              Fakultet *
            </label>
            <select
              id="spec-faculty-select"
              value={faculty}
              onChange={(e) => setFaculty(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs bg-white focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            >
              {faculties.map((f) => (
                <option key={f.id} value={f.name}>
                  {f.name}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <button
              type="submit"
              disabled={isSaving}
              className="w-full flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-sm font-semibold shadow-md shadow-purple-500/20 transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Qo'shish</span>
            </button>
          </div>
        </form>
      </div>

      {/* Specialties Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50/70 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-slate-900 text-sm">
              Ro'yxatdagi yo'nalishlar ({specialties.length} ta)
            </h3>
            <p className="text-[11px] text-slate-500">Har bir shifr tizimda noyob bo'ladi</p>
          </div>

          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Shifr yoki yo'nalish nomi bo'yicha..."
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 bg-white text-xs focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-xs font-bold uppercase text-slate-500">
              <tr>
                <th className="px-6 py-3">Yo'nalish shifri</th>
                <th className="px-4 py-3">Yo'nalish nomi</th>
                <th className="px-4 py-3">Fakultet</th>
                <th className="px-4 py-3 text-center">Talabalar</th>
                <th className="px-6 py-3 text-right">Amal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((spec) => {
                const count = students.filter(
                  (s) => s.specialtyCode === spec.code || s.specialty === spec.name
                ).length;
                const isEditing = editingId === spec.id;

                return (
                  <tr key={spec.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-6 py-3.5">
                      {isEditing ? (
                        <input
                          type="text"
                          value={editCode}
                          onChange={(e) => setEditCode(e.target.value)}
                          className="w-28 px-2.5 py-1 rounded-lg border border-slate-300 text-xs font-mono"
                        />
                      ) : (
                        <span className="font-mono text-xs font-bold px-2.5 py-1 rounded-lg bg-purple-50 text-purple-700 border border-purple-200">
                          {spec.code}
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3.5 font-bold text-slate-900 text-xs sm:text-sm">
                      {isEditing ? (
                        <input
                          type="text"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-full px-2.5 py-1 rounded-lg border border-slate-300 text-xs"
                        />
                      ) : (
                        spec.name
                      )}
                    </td>
                    <td className="px-4 py-3.5 text-xs text-slate-600">
                      {isEditing ? (
                        <select
                          value={editFaculty}
                          onChange={(e) => setEditFaculty(e.target.value)}
                          className="w-full px-2 py-1 rounded-lg border border-slate-300 text-xs bg-white"
                        >
                          {faculties.map((f) => (
                            <option key={f.id} value={f.name}>
                              {f.name}
                            </option>
                          ))}
                        </select>
                      ) : (
                        spec.faculty
                      )}
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs font-semibold">
                        <Users className="w-3 h-3" />
                        {count}
                      </span>
                    </td>
                    <td className="px-6 py-3.5 text-right">
                      {isEditing ? (
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => handleSaveEdit(spec.id)}
                            aria-label="Saqlash"
                            className="p-1.5 rounded-lg bg-purple-600 text-white hover:bg-purple-700"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingId(null)}
                            aria-label="Bekor qilish"
                            className="p-1.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => startEdit(spec)}
                            aria-label={`Yo'nalishni tahrirlash: ${spec.name}`}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-purple-600 hover:bg-purple-50 transition-colors"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteSpecialty(spec.id)}
                            aria-label={`Yo'nalishni o'chirish: ${spec.name}`}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
