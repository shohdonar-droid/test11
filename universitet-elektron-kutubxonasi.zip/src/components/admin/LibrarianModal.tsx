import React, { useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import type { Librarian } from '../../types/library';
import { X, UserPlus, Check, AlertCircle, Pencil } from 'lucide-react';

interface LibrarianModalProps {
  onClose: () => void;
  editingLibrarian?: Librarian;
}

export const LibrarianModal: React.FC<LibrarianModalProps> = ({
  onClose,
  editingLibrarian,
}) => {
  const { createLibrarian, updateLibrarian } = useLibrary();
  const isEditMode = Boolean(editingLibrarian);

  const [name, setName] = useState(editingLibrarian?.name || '');
  const [email, setEmail] = useState(editingLibrarian?.email || '');
  const [phone, setPhone] = useState(editingLibrarian?.phone || '+998 ');
  const [department, setDepartment] = useState(
    editingLibrarian?.department || "Asosiy o'quv zali"
  );
  const [shift, setShift] = useState(
    editingLibrarian?.shift || 'Kunduzgi (08:30 - 17:30)'
  );
  const [password, setPassword] = useState(isEditMode ? '' : 'lib123');
  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!name.trim() || !email.trim()) {
      setError('Iltimos, xodim ismi va elektron pochtasini kiriting!');
      return;
    }

    setIsSaving(true);
    try {
      if (editingLibrarian) {
        const updates: Partial<Librarian> = {
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          department: department.trim(),
          shift: shift.trim(),
        };
        if (password.trim()) {
          updates.password = password.trim();
        }
        const res = await updateLibrarian(editingLibrarian.id, updates);
        if (!res.success) {
          setError(res.message);
          return;
        }
      } else {
        const res = await createLibrarian({
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          department: department.trim(),
          shift: shift.trim(),
          password: password.trim() || 'lib123',
        });
        if (!res.success) {
          setError(res.message);
          return;
        }
      }
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
        <div className="flex items-center justify-between px-6 py-4 bg-linear-to-r from-purple-700 to-indigo-700 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/20">
              {isEditMode ? <Pencil className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="font-bold text-lg">
                {isEditMode ? "Kutubxonachi ma'lumotlarini tahrirlash" : "Yangi kutubxonachi qo'shish"}
              </h2>
              <p className="text-xs text-purple-200">Kutubxona xodimi hisobi va ish smenasi</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Yopish"
            className="p-1.5 rounded-lg hover:bg-white/20 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-medium">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">F.I.Sh *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Masalan: Dilnoza Qodirova"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Email (Login) *
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="d.qodirova@univ-library.uz"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Telefon</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+998 90 123 45 67"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-mono focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Bo'lim</label>
              <input
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Ish smenasi</label>
              <input
                type="text"
                value={shift}
                onChange={(e) => setShift(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {isEditMode ? 'Yangi parol (ixtiyoriy)' : 'Kirish paroli *'}
            </label>
            <input
              type="text"
              required={!isEditMode}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={isEditMode ? "O'zgartirmaslik uchun bo'sh qoldiring" : 'lib123'}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-mono focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
            />
          </div>

          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold"
            >
              Bekor qilish
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-semibold"
            >
              <Check className="w-4 h-4" />
              <span>{isSaving ? 'Saqlanmoqda...' : 'Saqlash'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
