import React, { useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import type { Student } from '../../types/library';
import { generateStudentId } from '../../utils/libraryRules';
import { X, UserPlus, Sparkles, Check, AlertCircle, Pencil } from 'lucide-react';

interface CreateStudentModalProps {
  onClose: () => void;
  editingStudent?: Student;
}

export const CreateStudentModal: React.FC<CreateStudentModalProps> = ({
  onClose,
  editingStudent,
}) => {
  const { students, specialties, faculties, createStudent, updateStudent } = useLibrary();

  const isEditMode = Boolean(editingStudent);

  const matchedSpec = editingStudent
    ? specialties.find(
        (s) =>
          (editingStudent.specialtyCode && s.code === editingStudent.specialtyCode) ||
          s.name === editingStudent.specialty
      )
    : specialties[0];

  const [name, setName] = useState(editingStudent?.name || '');
  const [studentId, setStudentId] = useState(
    editingStudent?.studentId || generateStudentId(students.length)
  );
  const [selectedSpecialtyId, setSelectedSpecialtyId] = useState(
    matchedSpec?.id || (editingStudent ? 'custom' : specialties[0]?.id || 'custom')
  );
  const [faculty, setFaculty] = useState(
    editingStudent?.faculty || specialties[0]?.faculty || faculties[0]?.name || ''
  );
  const [specialty, setSpecialty] = useState(
    editingStudent?.specialty || specialties[0]?.name || ''
  );
  const [specialtyCode, setSpecialtyCode] = useState(
    editingStudent?.specialtyCode || specialties[0]?.code || ''
  );
  const [course, setCourse] = useState(editingStudent?.course || 1);
  const [group, setGroup] = useState(editingStudent?.group || '');
  const [phone, setPhone] = useState(editingStudent?.phone || '+998 ');
  const [email, setEmail] = useState(editingStudent?.email || '');
  const [password, setPassword] = useState(isEditMode ? '' : 'student123');
  const [notes, setNotes] = useState(editingStudent?.notes || '');
  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleSpecialtySelect = (specId: string) => {
    setSelectedSpecialtyId(specId);
    const found = specialties.find((s) => s.id === specId);
    if (found) {
      setSpecialty(found.name);
      setSpecialtyCode(found.code);
      setFaculty(found.faculty);
    }
  };

  const handleNameChange = (val: string) => {
    setName(val);
    if (!isEditMode && (!email || email.includes('@univ.uz'))) {
      const slug = val
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '.')
        .replace(/\.+/g, '.');
      if (slug.length > 2) {
        setEmail(`${slug}@univ.uz`);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!name.trim()) {
      setError('Iltimos, talabaning ism va familiyasini kiriting!');
      return;
    }
    if (!group.trim()) {
      setError("Iltimos, talaba o'qiydigan guruh raqamini kiriting!");
      return;
    }
    if (!specialty.trim()) {
      setError("Iltimos, mutaxassislik yoki yo'nalishni tanlang!");
      return;
    }

    const exists = students.some(
      (s) =>
        s.id !== editingStudent?.id &&
        s.studentId.toLowerCase() === studentId.trim().toLowerCase()
    );
    if (exists) {
      setError(`"${studentId}" ID raqamli talaba allaqachon mavjud! Boshqa ID kiriting.`);
      return;
    }

    setIsSaving(true);
    try {
      if (editingStudent) {
        const updates: Partial<Student> = {
          studentId: studentId.trim(),
          name: name.trim(),
          email: email.trim() || `${studentId.toLowerCase()}@univ.uz`,
          phone: phone.trim(),
          faculty,
          specialty: specialty.trim(),
          specialtyCode: specialtyCode.trim() || undefined,
          course: Number(course),
          group: group.trim(),
          notes: notes.trim(),
        };
        if (password.trim()) {
          updates.password = password.trim();
        }
        const res = await updateStudent(editingStudent.id, updates);
        if (!res.success) {
          setError(res.message);
          return;
        }
      } else {
        const res = await createStudent({
          studentId: studentId.trim(),
          name: name.trim(),
          email: email.trim() || `${studentId.toLowerCase()}@univ.uz`,
          phone: phone.trim(),
          faculty,
          specialty: specialty.trim(),
          specialtyCode: specialtyCode.trim() || undefined,
          course: Number(course),
          group: group.trim(),
          status: 'active',
          password: password.trim() || 'student123',
          avatarUrl: '',
          notes: notes.trim(),
        });
        if (!res.success) {
          setError(res.message);
          return;
        }
      }
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-linear-to-r from-purple-700 to-indigo-700 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/20 backdrop-blur-xs">
              {isEditMode ? <Pencil className="w-5 h-5 text-white" /> : <UserPlus className="w-5 h-5 text-white" />}
            </div>
            <div>
              <h2 className="font-bold text-lg">
                {isEditMode ? "Talaba ma'lumotlarini tahrirlash" : "Yangi talaba ro'yxatga olish"}
              </h2>
              <p className="text-xs text-purple-200">
                {isEditMode
                  ? 'Talabaning shaxsiy va akademik ma\'lumotlarini yangilash'
                  : 'Admin tomonidan yangi talabaga kutubxona kartasi ochish'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Yopish"
            className="p-1.5 rounded-lg hover:bg-white/20 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-medium">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Student ID */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Talaba ID (Kutubxona bileti raqami) *
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={studentId}
                  onChange={(e) => setStudentId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  placeholder="TAL-2024-001"
                />
                {!isEditMode && (
                  <button
                    type="button"
                    onClick={() =>
                      setStudentId(generateStudentId(students.length + Math.floor(Math.random() * 50)))
                    }
                    title="Yangi ID generatsiya qilish"
                    className="absolute right-2 top-2 p-1 text-purple-600 hover:bg-purple-50 rounded"
                  >
                    <Sparkles className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Full Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Familiya, Ism va Sharif *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => handleNameChange(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                placeholder="Masalan: Azizbek Ergashev"
              />
            </div>
          </div>

          {/* Specialty by Shifr */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Ta'lim yo'nalishi (Shifr bilan) *
            </label>
            <select
              aria-label="Ta'lim yo'nalishini tanlash"
              value={selectedSpecialtyId}
              onChange={(e) => handleSpecialtySelect(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden bg-white"
            >
              {specialties.map((spec) => (
                <option key={spec.id} value={spec.id}>
                  [{spec.code}] — {spec.name}
                </option>
              ))}
              <option value="custom">Boshqa yo'nalish (qo'lda kiritish)</option>
            </select>
          </div>

          {selectedSpecialtyId === 'custom' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Shifr</label>
                <input
                  type="text"
                  value={specialtyCode}
                  onChange={(e) => setSpecialtyCode(e.target.value)}
                  placeholder="60610600"
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs font-mono bg-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Yo'nalish nomi *</label>
                <input
                  type="text"
                  required
                  value={specialty}
                  onChange={(e) => setSpecialty(e.target.value)}
                  placeholder="Yo'nalish nomini kiriting"
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                />
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Faculty */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">Fakultet *</label>
              {faculties.length > 0 ? (
                <select
                  value={faculty}
                  onChange={(e) => setFaculty(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden bg-white"
                >
                  <option value="">Fakultetni tanlang...</option>
                  {faculties.map((fac) => (
                    <option key={fac.id} value={fac.name}>
                      {fac.name}
                    </option>
                  ))}
                  {faculty && !faculties.some((f) => f.name === faculty) && (
                    <option value={faculty}>{faculty}</option>
                  )}
                </select>
              ) : (
                <input
                  type="text"
                  required
                  value={faculty}
                  onChange={(e) => setFaculty(e.target.value)}
                  placeholder="Masalan: Davolash fakulteti"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden bg-white"
                />
              )}
            </div>

            {/* Course */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Kurs *</label>
              <select
                value={course}
                onChange={(e) => setCourse(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden bg-white"
              >
                <option value={1}>1-kurs</option>
                <option value={2}>2-kurs</option>
                <option value={3}>3-kurs</option>
                <option value={4}>4-kurs</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Group */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Guruh raqami *</label>
              <input
                type="text"
                required
                value={group}
                onChange={(e) => setGroup(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                placeholder="912-21"
              />
            </div>

            {/* Phone */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Telefon raqami</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden font-mono"
                placeholder="+998 90 123 45 67"
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Elektron pochta</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                placeholder="talaba@univ.uz"
              />
            </div>
          </div>

          {/* Initial / New Password */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {isEditMode ? 'Yangi parol (ixtiyoriy)' : 'Dastlabki kirish paroli (Talaba uchun) *'}
            </label>
            <input
              type="text"
              required={!isEditMode}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-mono focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
              placeholder={isEditMode ? "O'zgartirmaslik uchun bo'sh qoldiring" : 'student123'}
            />
            <span className="text-[10px] text-slate-400 mt-0.5 block">
              Talaba ushbu parol va o'zining Talaba ID yoki email orqali tizimga kiradi
            </span>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Qo'shimcha izoh / Ma'lumot
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-hidden resize-none"
              placeholder="Masalan: Grant asosida o'qiydi, ilmiy rahbar prof. Karimov..."
            />
          </div>

          {/* Bottom Actions */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-sm font-semibold transition-colors"
            >
              Bekor qilish
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-sm font-semibold shadow-md shadow-purple-500/20 transition-all"
            >
              <Check className="w-4 h-4" />
              <span>
                {isSaving
                  ? 'Saqlanmoqda...'
                  : isEditMode
                  ? "O'zgarishlarni saqlash"
                  : 'Talabani saqlash va yaratish'}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
