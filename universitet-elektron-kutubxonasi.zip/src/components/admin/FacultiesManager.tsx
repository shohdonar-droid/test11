import React, { useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import type { Faculty } from '../../types/library';
import {
  Building2,
  PlusCircle,
  Pencil,
  Trash2,
  Users,
  Compass,
  BookOpen,
  AlertCircle,
  Check,
  X,
} from 'lucide-react';

export const FacultiesManager: React.FC = () => {
  const {
    faculties,
    specialties,
    students,
    books,
    createFaculty,
    updateFaculty,
    deleteFaculty,
  } = useLibrary();

  const [name, setName] = useState('');
  const [shortName, setShortName] = useState('');
  const [dean, setDean] = useState('');
  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editShortName, setEditShortName] = useState('');
  const [editDean, setEditDean] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSaving(true);
    try {
      const res = await createFaculty({ name, shortName, dean });
      if (!res.success) {
        setError(res.message);
        return;
      }
      setName('');
      setShortName('');
      setDean('');
    } finally {
      setIsSaving(false);
    }
  };

  const startEdit = (fac: Faculty) => {
    setEditingId(fac.id);
    setEditName(fac.name);
    setEditShortName(fac.shortName || '');
    setEditDean(fac.dean || '');
    setConfirmDeleteId(null);
    setError('');
  };

  const handleSaveEdit = async (id: string) => {
    setError('');
    const res = await updateFaculty(id, {
      name: editName,
      shortName: editShortName,
      dean: editDean,
    });
    if (!res.success) {
      setError(res.message);
      return;
    }
    setEditingId(null);
  };

  const handleDelete = async (id: string) => {
    setError('');
    const res = await deleteFaculty(id);
    setConfirmDeleteId(null);
    if (!res.success) {
      setError(res.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Create Faculty Form */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6">
        <div className="flex items-center gap-2.5 mb-4">
          <div className="p-2 rounded-xl bg-purple-100 text-purple-600">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-base text-slate-900">Yangi fakultet qo'shish</h2>
            <p className="text-xs text-slate-500">
              Universitet fakultetlarini yaratish, nomini tahrirlash yoki o'chirish boshqaruvi
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-4 flex items-center gap-2 p-3 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-medium">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleCreate} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          <div className="md:col-span-5">
            <label htmlFor="fac-name-input" className="block text-xs font-semibold text-slate-700 mb-1">
              Fakultet nomi *
            </label>
            <input
              id="fac-name-input"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Masalan: Sun'iy intellekt va robototexnika"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="md:col-span-2">
            <label htmlFor="fac-short-input" className="block text-xs font-semibold text-slate-700 mb-1">
              Qisqartmasi
            </label>
            <input
              id="fac-short-input"
              type="text"
              value={shortName}
              onChange={(e) => setShortName(e.target.value)}
              placeholder="SIRF"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="md:col-span-3">
            <label htmlFor="fac-dean-input" className="block text-xs font-semibold text-slate-700 mb-1">
              Fakultet dekani
            </label>
            <input
              id="fac-dean-input"
              type="text"
              value={dean}
              onChange={(e) => setDean(e.target.value)}
              placeholder="Prof. A. Karimov"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="md:col-span-2">
            <button
              type="submit"
              disabled={isSaving}
              className="w-full flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-sm font-semibold shadow-md shadow-purple-500/20 transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Qo'shish</span>
            </button>
          </div>
        </form>
      </div>

      {/* Faculties List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-base">
            Tizimdagi fakultetlar ({faculties.length} ta)
          </h3>
          <span className="text-xs text-slate-500">
            Tahrirlanganda bog'langan talaba va yo'nalishlar ham avtomatik yangilanadi
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {faculties.map((fac) => {
            const isEditing = editingId === fac.id;
            const isConfirmingDelete = confirmDeleteId === fac.id;
            const specCount = specialties.filter((s) => s.faculty === fac.name).length;
            const stuCount = students.filter((s) => s.faculty === fac.name).length;
            const bookCount = books.filter((b) => b.faculty === fac.name).length;

            return (
              <div
                key={fac.id}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between gap-3 transition-all"
              >
                {isEditing ? (
                  <div className="space-y-2.5">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Fakultet nomi *
                      </label>
                      <input
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                          Qisqartma
                        </label>
                        <input
                          type="text"
                          value={editShortName}
                          onChange={(e) => setEditShortName(e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                          Dekan
                        </label>
                        <input
                          type="text"
                          value={editDean}
                          onChange={(e) => setEditDean(e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs"
                        />
                      </div>
                    </div>
                    <div className="flex items-center justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setEditingId(null)}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-slate-600 text-xs font-semibold hover:bg-slate-50"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Bekor qilish</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSaveEdit(fac.id)}
                        className="flex items-center gap-1 px-3 py-1 rounded-lg bg-purple-600 text-white text-xs font-semibold hover:bg-purple-700"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Saqlash</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h4 className="font-bold text-sm text-slate-900">{fac.name}</h4>
                            {fac.shortName && (
                              <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-purple-100 text-purple-700">
                                {fac.shortName}
                              </span>
                            )}
                          </div>
                          {fac.dean && (
                            <p className="text-xs text-slate-500">Dekan: {fac.dean}</p>
                          )}
                        </div>

                        <div className="flex items-center gap-1 flex-shrink-0">
                          <button
                            type="button"
                            onClick={() => startEdit(fac)}
                            aria-label={`Fakultetni tahrirlash: ${fac.name}`}
                            title="Tahrirlash"
                            className="p-1.5 rounded-lg text-slate-400 hover:text-purple-600 hover:bg-purple-50 transition-colors"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>

                          {isConfirmingDelete ? (
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => handleDelete(fac.id)}
                                className="px-2 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold"
                              >
                                Tasdiqlash
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteId(null)}
                                className="px-2 py-1 rounded-lg border border-slate-300 bg-white text-slate-600 text-[11px] font-semibold"
                              >
                                Yo'q
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(fac.id)}
                              aria-label={`Fakultetni o'chirish: ${fac.name}`}
                              title="O'chirish"
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="pt-2.5 border-t border-slate-200/70 flex flex-wrap items-center gap-3 text-xs text-slate-600">
                      <span className="flex items-center gap-1 font-semibold">
                        <Compass className="w-3.5 h-3.5 text-purple-500" />
                        {specCount} yo'nalish
                      </span>
                      <span className="flex items-center gap-1 font-semibold">
                        <Users className="w-3.5 h-3.5 text-emerald-600" />
                        {stuCount} talaba
                      </span>
                      <span className="flex items-center gap-1 font-semibold">
                        <BookOpen className="w-3.5 h-3.5 text-blue-600" />
                        {bookCount} kitob
                      </span>
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
