import React, { useEffect, useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import type { Book, Librarian, Loan, Student } from '../../types/library';
import { CreateStudentModal } from './CreateStudentModal';
import { ExcelImportModal } from './ExcelImportModal';
import { FacultiesManager } from './FacultiesManager';
import { SpecialtiesManager } from './SpecialtiesManager';
import { LibrarianModal } from './LibrarianModal';
import { CategoriesManager } from '../common/CategoriesManager';
import { AddBookModal } from '../librarian/AddBookModal';
import { StudentBooksModal } from '../librarian/StudentBooksModal';
import { ReturnBookModal } from '../librarian/ReturnBookModal';
import { DashboardLayout, SidebarMenuItem } from '../layout/DashboardLayout';
import { SiteSettingsPanel, type SiteSettingsSubTab } from './SiteSettingsPanel';
import {
  calculateDaysOverdue,
  formatUzbekCurrency,
  formatUzbekDate,
} from '../../utils/libraryRules';
import {
  Users,
  BookOpen,
  CalendarCheck,
  AlertTriangle,
  UserPlus,
  Search,
  CheckCircle2,
  XCircle,
  Shield,
  Trash2,
  History,
  GraduationCap,
  FileSpreadsheet,
  Compass,
  Tag,
  Building2,
  Pencil,
  Phone,
  Mail,
  PlusCircle,
  BookCheck,
  RotateCw,
  ArrowRight,
  Lock,
  Download,
  UserCheck,
  Settings,
  LayoutTemplate,
  Sparkles,
  ScrollText,
  PhoneCall,
  Image as ImageIcon,
} from 'lucide-react';

interface AdminDashboardProps {
  overdueJumpKey?: number;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ overdueJumpKey = 0 }) => {
  const {
    students,
    books,
    loans,
    librarians,
    logs,
    faculties,
    specialties,
    categories,
    currentUser,
    toggleStudentStatus,
    deleteStudent,
    deleteLibrarian,
    deleteBook,
    prolongLoan,
    setShowProfileModal,
  } = useLibrary();

  const [activeTab, setActiveTab] = useState<
    | 'students'
    | 'overdue'
    | 'faculties'
    | 'specialties'
    | 'categories'
    | 'librarians'
    | 'books'
    | 'logs'
    | 'settings:footer'
    | 'settings:services'
    | 'settings:rules'
    | 'settings:contact'
    | 'settings:banner'
  >('students');

  const [showCreateStudentModal, setShowCreateStudentModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | undefined>(undefined);
  const [showExcelImportModal, setShowExcelImportModal] = useState(false);

  const [showLibrarianModal, setShowLibrarianModal] = useState(false);
  const [editingLibrarian, setEditingLibrarian] = useState<Librarian | undefined>(undefined);

  const [showBookModal, setShowBookModal] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | undefined>(undefined);

  const [inspectingStudent, setInspectingStudent] = useState<Student | null>(null);
  const [returningLoan, setReturningLoan] = useState<Loan | null>(null);

  const [confirmDeleteStudentId, setConfirmDeleteStudentId] = useState<string | null>(null);
  const [confirmDeleteBookId, setConfirmDeleteBookId] = useState<string | null>(null);
  const [confirmDeleteLibId, setConfirmDeleteLibId] = useState<string | null>(null);

  // Search & Filter state for students & books
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFaculty, setSelectedFaculty] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [bookSearch, setBookSearch] = useState('');
  const [bookCategory, setBookCategory] = useState('all');

  useEffect(() => {
    if (overdueJumpKey > 0) {
      setActiveTab('overdue');
    }
  }, [overdueJumpKey]);

  // KPI Calculations
  const totalBooks = books.reduce((acc, b) => acc + b.totalCopies, 0);
  const availableBooks = books.reduce((acc, b) => acc + b.availableCopies, 0);
  const activeLoans = loans.filter((l) => l.status === 'active');
  const overdueLoans = loans.filter((l) => l.status === 'overdue');

  // Filter students
  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.group.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (student.specialtyCode || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.specialty.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesFaculty = selectedFaculty === 'all' || student.faculty === selectedFaculty;
    const matchesStatus = selectedStatus === 'all' || student.status === selectedStatus;

    return matchesSearch && matchesFaculty && matchesStatus;
  });

  const menuItems: SidebarMenuItem[] = [
    {
      id: 'students',
      label: 'Talabalar bazasi',
      icon: <Users className="w-4 h-4" />,
      badge: students.length,
    },
    {
      id: 'overdue',
      label: "Muddati o'tganlar",
      icon: <AlertTriangle className="w-4 h-4" />,
      badge: overdueLoans.length,
    },
    {
      id: 'faculties',
      label: 'Fakultetlar',
      icon: <Building2 className="w-4 h-4" />,
      badge: faculties.length,
    },
    {
      id: 'specialties',
      label: "Yo'nalishlar (Shifrlar)",
      icon: <Compass className="w-4 h-4" />,
      badge: specialties.length,
    },
    {
      id: 'categories',
      label: 'Kitob kategoriyalari',
      icon: <Tag className="w-4 h-4" />,
      badge: categories.length,
    },
    {
      id: 'librarians',
      label: 'Kutubxona xodimlari',
      icon: <GraduationCap className="w-4 h-4" />,
      badge: librarians.length,
    },
    {
      id: 'books',
      label: 'Fond monitoringi',
      icon: <BookOpen className="w-4 h-4" />,
      badge: books.length,
    },
    {
      id: 'logs',
      label: 'Tizim auditi',
      icon: <History className="w-4 h-4" />,
      badge: logs.length,
    },
    {
      id: 'settings',
      label: 'Sayt sozlamalari',
      icon: <Settings className="w-4 h-4" />,
      children: [
        {
          id: 'settings:footer',
          label: 'Footerlar',
          icon: <LayoutTemplate className="w-3.5 h-3.5" />,
        },
        {
          id: 'settings:services',
          label: 'Xizmatlar',
          icon: <Sparkles className="w-3.5 h-3.5" />,
        },
        {
          id: 'settings:rules',
          label: 'Qoidalar',
          icon: <ScrollText className="w-3.5 h-3.5" />,
        },
        {
          id: 'settings:contact',
          label: "Bog'lanish",
          icon: <PhoneCall className="w-3.5 h-3.5" />,
        },
        {
          id: 'settings:banner',
          label: 'Banner',
          icon: <ImageIcon className="w-3.5 h-3.5" />,
        },
      ],
    },
  ];

  return (
    <DashboardLayout
      accentColor="purple"
      panelTitle="Admin Paneli"
      panelSubtitle="Fakultetlar, talabalar, yo'nalish shifrlari, kategoriyalar va kutubxona fondi boshqaruvi"
      menuItems={menuItems}
      activeMenuId={activeTab}
      onSelectMenu={(id) => setActiveTab(id as typeof activeTab)}
      sidebarFooter={
        <div className="space-y-2">
          <button
            type="button"
            onClick={() => {
              setEditingStudent(undefined);
              setShowCreateStudentModal(true);
            }}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Yangi talaba yaratish</span>
          </button>
          <button
            type="button"
            onClick={() => setShowExcelImportModal(true)}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 text-xs font-semibold transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Exceldan import qilish</span>
          </button>
        </div>
      }
    >
      {/* Modern Admin Profile & Command Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5 bg-linear-to-r from-slate-900 via-purple-950 to-indigo-950 p-6 rounded-3xl text-white shadow-lg border border-white/10">
        <div className="flex items-start gap-4 min-w-0">
          {currentUser?.avatarUrl && (
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.name}
              className="w-15 h-15 rounded-2xl object-cover ring-2 ring-purple-400/40 shadow-md flex-shrink-0"
            />
          )}
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-lg text-[11px] font-semibold bg-purple-500/25 text-purple-200 border border-purple-400/30 inline-flex items-center gap-1">
                <Shield className="w-3 h-3" />
                Administrator Paneli
              </span>
              <span className="text-[11px] text-slate-300 truncate">
                {currentUser?.adminData?.title || 'Boshqaruv markazi'}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight truncate">
              {currentUser?.name || 'Universitet Axborot-Kutubxona Markazi'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
              Fakultetlar, talabalar, yo'nalish shifrlari va kutubxona fondining markazlashgan boshqaruvi
            </p>
          </div>
        </div>

        <div className="flex flex-wrap xl:flex-nowrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => setShowExcelImportModal(true)}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-md shadow-emerald-600/25 transition-all whitespace-nowrap shrink-0"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Exceldan import</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setEditingStudent(undefined);
              setShowCreateStudentModal(true);
            }}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shadow-md shadow-purple-500/25 transition-all whitespace-nowrap shrink-0"
          >
            <UserPlus className="w-4 h-4" />
            <span>Yangi talaba yaratish</span>
          </button>
          <button
            type="button"
            onClick={() => setShowProfileModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs border border-white/20 transition-all whitespace-nowrap shrink-0"
          >
            <UserCheck className="w-4 h-4 text-purple-300" />
            <span>Profil</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 tabular-nums">
        <button
          type="button"
          onClick={() => setActiveTab('students')}
          className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-purple-300 shadow-xs flex items-center justify-between text-left transition-all cursor-pointer"
        >
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Jami talabalar</p>
            <h3 className="text-2xl font-bold text-slate-900 mt-1">{students.length} nafar</h3>
            <span className="text-[11px] text-emerald-600 font-medium">
              {faculties.length} ta fakultet • {specialties.length} yo'nalish
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('books')}
          className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-blue-300 shadow-xs flex items-center justify-between text-left transition-all cursor-pointer"
        >
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Kutubxona fondi</p>
            <h3 className="text-2xl font-bold text-slate-900 mt-1">{totalBooks} ta nusxa</h3>
            <span className="text-[11px] text-slate-500 font-medium">
              {books.length} xil kitob ({availableBooks} ta mavjud)
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center">
            <BookOpen className="w-6 h-6" />
          </div>
        </button>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Ijarada turgan</p>
            <h3 className="text-2xl font-bold text-slate-900 mt-1">{activeLoans.length} ta kitob</h3>
            <span className="text-[11px] text-blue-600 font-medium">Talabalar qo'lida</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center">
            <CalendarCheck className="w-6 h-6" />
          </div>
        </div>

        <button
          type="button"
          data-testid="admin-overdue-stat-card"
          onClick={() => setActiveTab('overdue')}
          className={`bg-white p-5 rounded-2xl border shadow-xs flex items-center justify-between text-left transition-all cursor-pointer group ${
            activeTab === 'overdue'
              ? 'border-rose-500 ring-2 ring-rose-500/20'
              : overdueLoans.length > 0
              ? 'border-rose-200 hover:border-rose-400 hover:shadow-md'
              : 'border-slate-200 hover:border-slate-300'
          }`}
        >
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Muddati o'tganlar</p>
            <h3 className={`text-2xl font-bold mt-1 ${overdueLoans.length > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
              {overdueLoans.length} ta kitob
            </h3>
            <span className="text-[11px] text-rose-600 font-semibold inline-flex items-center gap-1 mt-0.5">
              <span>{overdueLoans.length > 0 ? "Ro'yxatni ko'rish" : "Hammasi o'z vaqtida"}</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </button>
      </div>

      {/* Section 1: Talabalar boshqaruvi */}
      {activeTab === 'students' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden space-y-4">
          <div className="p-4 bg-slate-50/70 border-b border-slate-200 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
              <input
                type="text"
                placeholder="Ism, ID, guruh yoki yo'nalish shifri bo'yicha qidirish..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-white rounded-xl border border-slate-300 text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                aria-label="Fakultet bo'yicha saralash"
                value={selectedFaculty}
                onChange={(e) => setSelectedFaculty(e.target.value)}
                className="bg-white border border-slate-300 text-xs font-medium rounded-xl px-3 py-2 text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              >
                <option value="all">Barcha fakultetlar</option>
                {faculties.map((fac) => (
                  <option key={fac.id} value={fac.name}>
                    {fac.name}
                  </option>
                ))}
              </select>

              <select
                aria-label="Holat bo'yicha saralash"
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="bg-white border border-slate-300 text-xs font-medium rounded-xl px-3 py-2 text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              >
                <option value="all">Barcha holatlar</option>
                <option value="active">Faol</option>
                <option value="blocked">Bloklangan</option>
              </select>

              <button
                type="button"
                onClick={() => setShowExcelImportModal(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Excel import</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setEditingStudent(undefined);
                  setShowCreateStudentModal(true);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Talaba qo'shish</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs font-bold uppercase text-slate-500">
                <tr>
                  <th className="px-6 py-3.5">Talaba</th>
                  <th className="px-4 py-3.5">Talaba ID</th>
                  <th className="px-4 py-3.5">Yo'nalish (Shifr) va Fakultet</th>
                  <th className="px-4 py-3.5">Guruh / Kurs</th>
                  <th className="px-4 py-3.5 text-center">Ijarada</th>
                  <th className="px-4 py-3.5">Status</th>
                  <th className="px-6 py-3.5 text-right">Amallar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredStudents.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                      Bunday mezonlarga mos keladigan talaba topilmadi.
                    </td>
                  </tr>
                ) : (
                  filteredStudents.map((student) => {
                    const studentLoans = loans.filter(
                      (l) => l.studentId === student.id && l.status !== 'returned'
                    );
                    const hasOverdue = studentLoans.some((l) => l.status === 'overdue');
                    const isConfirmingDelete = confirmDeleteStudentId === student.id;

                    return (
                      <tr key={student.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="px-6 py-4">
                          <button
                            type="button"
                            onClick={() => setInspectingStudent(student)}
                            className="flex items-center gap-3 text-left group"
                            title="Talaba kitoblarini ko'rish"
                          >
                            <img
                              src={student.avatarUrl}
                              alt={student.name}
                              className="w-9 h-9 rounded-full object-cover border border-slate-200"
                            />
                            <div>
                              <div className="font-bold text-slate-900 group-hover:text-purple-700 transition-colors">
                                {student.name}
                              </div>
                              <div className="text-xs text-slate-400">{student.email}</div>
                            </div>
                          </button>
                        </td>

                        <td className="px-4 py-4">
                          <span className="inline-block whitespace-nowrap font-mono text-xs font-semibold px-2 py-1 rounded bg-slate-100 text-slate-700 border border-slate-200">
                            {student.studentId}
                          </span>
                        </td>

                        <td className="px-4 py-4 max-w-xs">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {student.specialtyCode && (
                              <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-200">
                                {student.specialtyCode}
                              </span>
                            )}
                            <span className="text-xs font-bold text-slate-800">{student.specialty}</span>
                          </div>
                          <div className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                            {student.faculty}
                          </div>
                        </td>

                        <td className="px-4 py-4">
                          <div className="font-semibold text-slate-700 text-xs">{student.group}</div>
                          <div className="text-[11px] text-slate-400">{student.course}-kurs</div>
                        </td>

                        <td className="px-4 py-4 text-center">
                          {studentLoans.length === 0 ? (
                            <span className="text-xs text-slate-400">Yo'q</span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setInspectingStudent(student)}
                              className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                                hasOverdue
                                  ? 'bg-rose-100 text-rose-700 border border-rose-200'
                                  : 'bg-blue-100 text-blue-700 border border-blue-200'
                              }`}
                            >
                              {studentLoans.length} ta
                            </button>
                          )}
                        </td>

                        <td className="px-4 py-4">
                          <button
                            type="button"
                            onClick={() => toggleStudentStatus(student.id)}
                            title="Statusni o'zgartirish uchun bosing"
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold transition-colors ${
                              student.status === 'active'
                                ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                                : 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                            }`}
                          >
                            {student.status === 'active' ? (
                              <>
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Faol</span>
                              </>
                            ) : (
                              <>
                                <XCircle className="w-3.5 h-3.5" />
                                <span>Bloklangan</span>
                              </>
                            )}
                          </button>
                        </td>

                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingStudent(student);
                                setShowCreateStudentModal(true);
                              }}
                              title="Talaba ma'lumotlarini tahrirlash"
                              aria-label={`Talaba ${student.name}ni tahrirlash`}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-purple-600 hover:bg-purple-50 transition-colors"
                            >
                              <Pencil className="w-4 h-4" />
                            </button>

                            {isConfirmingDelete ? (
                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => {
                                    deleteStudent(student.id);
                                    setConfirmDeleteStudentId(null);
                                  }}
                                  className="px-2 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold"
                                >
                                  O'chirish
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setConfirmDeleteStudentId(null)}
                                  className="px-2 py-1 rounded-lg border border-slate-300 bg-white text-slate-600 text-[11px]"
                                >
                                  Yo'q
                                </button>
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteStudentId(student.id)}
                                title="Talabani o'chirish"
                                aria-label={`Talaba ${student.name}ni o'chirish`}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Section: Muddati o'tganlar (Overdue Students & Loans) */}
      {activeTab === 'overdue' && (
        <div className="bg-white rounded-2xl border border-rose-200 shadow-xs overflow-hidden">
          <div className="px-6 py-4 bg-rose-50/70 border-b border-rose-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-rose-100 text-rose-600">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-bold text-rose-950 text-base">
                  Muddati o'tgan kitoblar va kechiktirayotgan talabalar ro'yxati
                </h2>
                <p className="text-xs text-rose-700">
                  Har bir kechiktirilgan kitob bo'yicha talabaning bog'lanish ma'lumotlari va jarima miqdori
                </p>
              </div>
            </div>
            <span className="px-3 py-1 rounded-full bg-rose-600 text-white text-xs font-bold self-start sm:self-center">
              Jami {overdueLoans.length} ta kechikish
            </span>
          </div>

          {overdueLoans.length === 0 ? (
            <div className="p-12 text-center space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
              <div className="font-bold text-slate-900">Hozirda muddati o'tgan kitoblar yo'q</div>
              <p className="text-xs text-slate-500">Barcha talabalar kitoblarni o'z vaqtida topshirmoqda.</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {overdueLoans.map((loan) => {
                const stu = students.find((s) => s.id === loan.studentId);
                const daysOverdue = calculateDaysOverdue(loan.dueDate);

                return (
                  <div
                    key={loan.id}
                    className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4 hover:bg-rose-50/30 transition-colors"
                  >
                    <div className="flex items-start gap-4">
                      {stu ? (
                        <img
                          src={stu.avatarUrl}
                          alt={stu.name}
                          className="w-12 h-12 rounded-2xl object-cover border border-rose-200 flex-shrink-0"
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center flex-shrink-0">
                          <Users className="w-5 h-5" />
                        </div>
                      )}

                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            type="button"
                            onClick={() => stu && setInspectingStudent(stu)}
                            className="font-bold text-sm text-slate-900 hover:text-purple-700 underline decoration-dotted underline-offset-2"
                          >
                            {loan.studentName}
                          </button>
                          {stu && (
                            <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                              {stu.studentId}
                            </span>
                          )}
                          <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 text-[11px] font-bold">
                            {daysOverdue} kun kechikkan
                          </span>
                        </div>

                        <div className="text-xs text-slate-600">
                          {loan.studentFaculty} • Guruh: <strong className="text-slate-800">{loan.studentGroup}</strong>
                          {stu && ` (${stu.course}-kurs)`}
                        </div>

                        {stu && (
                          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 pt-0.5">
                            <span className="inline-flex items-center gap-1 font-mono">
                              <Phone className="w-3.5 h-3.5 text-slate-400" />
                              {stu.phone}
                            </span>
                            <span className="inline-flex items-center gap-1">
                              <Mail className="w-3.5 h-3.5 text-slate-400" />
                              {stu.email}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row sm:items-center gap-4 lg:text-right">
                      <div className="space-y-0.5 text-xs">
                        <div className="font-bold text-slate-900">Kitob: {loan.bookTitle}</div>
                        <div className="text-slate-500">
                          Topshirish muddati: <span className="font-semibold text-rose-600">{formatUzbekDate(loan.dueDate)}</span>
                        </div>
                        <div className="font-bold text-rose-700">
                          Hisoblangan jarima: {formatUzbekCurrency(loan.fineAmount)}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 flex-shrink-0">
                        <button
                          type="button"
                          onClick={() => setReturningLoan(loan)}
                          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs"
                        >
                          <BookCheck className="w-3.5 h-3.5" />
                          <span>Qaytarib olish</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => prolongLoan(loan.id, 7)}
                          className="flex items-center gap-1 px-3 py-2 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-semibold"
                        >
                          <RotateCw className="w-3.5 h-3.5" />
                          <span>+7 kun</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Section: Fakultetlar */}
      {activeTab === 'faculties' && <FacultiesManager />}

      {/* Section 2: Yo'nalishlar (Shifrlar) */}
      {activeTab === 'specialties' && <SpecialtiesManager />}

      {/* Section 3: Kitob kategoriyalari */}
      {activeTab === 'categories' && <CategoriesManager accentColor="purple" />}

      {/* Section 4: Kutubxona xodimlari */}
      {activeTab === 'librarians' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <div>
              <h2 className="font-bold text-slate-900 text-base">Kutubxona xodimlari boshqaruvi</h2>
              <p className="text-xs text-slate-500">
                Kutubxonachi qo'shish, ma'lumotlarini tahrirlash va o'chirish
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setEditingLibrarian(undefined);
                setShowLibrarianModal(true);
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-xs"
            >
              <UserPlus className="w-4 h-4" />
              <span>Yangi kutubxonachi</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {librarians.map((lib) => {
              const isConfirming = confirmDeleteLibId === lib.id;
              return (
                <div
                  key={lib.id}
                  className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-start gap-4"
                >
                  <img
                    src={lib.avatarUrl}
                    alt={lib.name}
                    className="w-14 h-14 rounded-2xl object-cover border border-slate-200"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-bold text-slate-900 text-base truncate">{lib.name}</h3>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 flex-shrink-0">
                        Kutubxonachi
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">{lib.department}</p>
                    <div className="mt-2 text-xs text-slate-600 space-y-0.5">
                      <div>
                        Ish vaqti: <span className="font-medium text-slate-800">{lib.shift}</span>
                      </div>
                      <div>
                        Telefon: <span className="font-mono text-slate-800">{lib.phone}</span>
                      </div>
                      <div>
                        Email: <span className="text-slate-800">{lib.email}</span>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingLibrarian(lib);
                          setShowLibrarianModal(true);
                        }}
                        className="flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                        <span>Tahrirlash</span>
                      </button>

                      {isConfirming ? (
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              deleteLibrarian(lib.id);
                              setConfirmDeleteLibId(null);
                            }}
                            className="px-2.5 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-bold"
                          >
                            Tasdiqlash
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteLibId(null)}
                            className="px-2.5 py-1.5 rounded-lg border border-slate-300 text-slate-600 text-xs"
                          >
                            Yo'q
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteLibId(lib.id)}
                          className="flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-lg text-rose-600 hover:bg-rose-50 border border-rose-200"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>O'chirish</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Section 5: Fond monitoringi */}
      {activeTab === 'books' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
          <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 pb-2 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Kutubxona fondidagi barcha darsliklar
              </h2>
              <span className="text-xs text-slate-500 tabular-nums">Jami {books.length} xil nashr</span>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                <input
                  type="text"
                  value={bookSearch}
                  onChange={(e) => setBookSearch(e.target.value)}
                  placeholder="Kitob yoki muallif qidirish..."
                  className="pl-8 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs bg-slate-50 focus:outline-hidden focus:ring-2 focus:ring-purple-500 w-48"
                />
              </div>

              <select
                aria-label="Kategoriya bo'yicha saralash"
                value={bookCategory}
                onChange={(e) => setBookCategory(e.target.value)}
                className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs bg-white text-slate-700"
              >
                <option value="all">Barcha kategoriyalar</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={() => {
                  setEditingBook(undefined);
                  setShowBookModal(true);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-xs whitespace-nowrap shrink-0"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Yangi kitob qo'shish</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {books
              .filter((b) => {
                const q = bookSearch.toLowerCase();
                const matchesSearch =
                  b.title.toLowerCase().includes(q) ||
                  b.author.toLowerCase().includes(q) ||
                  b.barcode.toLowerCase().includes(q);
                const matchesCat = bookCategory === 'all' || b.category === bookCategory;
                return matchesSearch && matchesCat;
              })
              .map((book) => {
                const isConfirming = confirmDeleteBookId === book.id;
                return (
                  <div
                    key={book.id}
                    className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 transition-all flex flex-col justify-between gap-3"
                  >
                    <div className="flex gap-3">
                      <img
                        src={book.coverUrl}
                        alt={book.title}
                        className="w-16 h-22 object-cover rounded-lg shadow-xs flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                          {book.category}
                        </span>
                        <h4 className="font-bold text-xs text-slate-900 line-clamp-2 mt-1">{book.title}</h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">{book.author}</p>
                        <div className="mt-2 text-[10px] text-slate-600 space-y-0.5">
                          <div className="tabular-nums">
                            Mavjud: <span className="font-bold text-emerald-600">{book.availableCopies}</span> /{' '}
                            {book.totalCopies} nusxa
                          </div>
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-mono text-slate-400">{book.barcode}</span>
                            <span
                              className={`inline-flex items-center gap-0.5 font-medium ${
                                book.allowPdfDownload ? 'text-emerald-700' : 'text-amber-700'
                              }`}
                            >
                              {book.allowPdfDownload ? (
                                <>
                                  <Download className="w-2.5 h-2.5" />
                                  Yuklab olish ochiq
                                </>
                              ) : (
                                <>
                                  <Lock className="w-2.5 h-2.5" />
                                  Faqat o'qish
                                </>
                              )}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingBook(book);
                        setShowBookModal(true);
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-medium"
                    >
                      <Pencil className="w-3 h-3" />
                      <span>Tahrirlash</span>
                    </button>

                    {isConfirming ? (
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            deleteBook(book.id);
                            setConfirmDeleteBookId(null);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-rose-600 text-white text-xs font-bold"
                        >
                          Tasdiqlash
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteBookId(null)}
                          className="px-2 py-1 rounded-lg border border-slate-300 text-slate-600 text-xs"
                        >
                          Yo'q
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteBookId(book.id)}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-medium"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>O'chirish</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Section 6: Tizim loglari */}
      {activeTab === 'logs' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm">Oxirgi amalga oshirilgan tizim operatsiyalari</h3>
            <span className="text-xs text-slate-500">{logs.length} ta yozuv</span>
          </div>

          <div className="divide-y divide-slate-100">
            {logs.map((log) => (
              <div key={log.id} className="px-6 py-3.5 flex items-start justify-between gap-4 text-xs">
                <div>
                  <div className="font-semibold text-slate-900">{log.details}</div>
                  <div className="text-slate-400 text-[11px] mt-0.5">
                    Bajaruvchi: <span className="font-medium text-slate-600">{log.performerName}</span> (
                    {log.performerRole})
                  </div>
                </div>
                <div className="text-right text-slate-400 font-mono text-[11px] flex-shrink-0">
                  {log.timestamp}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Section 7: Sayt sozlamalari */}
      {activeTab.startsWith('settings:') && (
        <SiteSettingsPanel
          activeSubTab={activeTab.replace('settings:', '') as SiteSettingsSubTab}
          onSelectSubTab={(sub) => setActiveTab(`settings:${sub}` as typeof activeTab)}
        />
      )}

      {/* Create / Edit Student Modal */}
      {showCreateStudentModal && (
        <CreateStudentModal
          editingStudent={editingStudent}
          onClose={() => {
            setShowCreateStudentModal(false);
            setEditingStudent(undefined);
          }}
        />
      )}

      {/* Excel Bulk Import Modal */}
      {showExcelImportModal && <ExcelImportModal onClose={() => setShowExcelImportModal(false)} />}

      {/* Create / Edit Librarian Modal */}
      {showLibrarianModal && (
        <LibrarianModal
          editingLibrarian={editingLibrarian}
          onClose={() => {
            setShowLibrarianModal(false);
            setEditingLibrarian(undefined);
          }}
        />
      )}

      {/* Add / Edit Book Modal */}
      {showBookModal && (
        <AddBookModal
          editingBook={editingBook}
          onClose={() => {
            setShowBookModal(false);
            setEditingBook(undefined);
          }}
        />
      )}

      {/* Inspect Student Loans */}
      {inspectingStudent && (
        <StudentBooksModal
          student={inspectingStudent}
          loans={loans}
          onClose={() => setInspectingStudent(null)}
          onReturnLoan={(loan) => {
            setInspectingStudent(null);
            setReturningLoan(loan);
          }}
          onProlongLoan={(loanId) => prolongLoan(loanId, 7)}
          onIssueToStudent={() => setInspectingStudent(null)}
        />
      )}

      {/* Return Book Modal */}
      {returningLoan && (
        <ReturnBookModal loan={returningLoan} onClose={() => setReturningLoan(null)} />
      )}
    </DashboardLayout>
  );
};
