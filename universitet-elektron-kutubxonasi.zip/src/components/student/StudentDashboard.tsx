import React, { useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import type { Book } from '../../types/library';
import { EBookReaderModal } from '../common/EBookReaderModal';
import { UserAvatar } from '../common/UserAvatar';
import { DashboardLayout, SidebarMenuItem } from '../layout/DashboardLayout';
import {
  calculateDaysOverdue,
  formatUzbekCurrency,
  formatUzbekDate,
} from '../../utils/libraryRules';
import {
  BookOpen,
  AlertTriangle,
  RotateCw,
  Search,
  CheckCircle2,
  Clock,
  MapPin,
  Bookmark,
  Layers,
  Heart,
  Eye,
  FileText,
  UserCheck,
} from 'lucide-react';

export const StudentDashboard: React.FC = () => {
  const {
    books,
    categories,
    loans,
    reservations,
    currentUser,
    students,
    prolongLoan,
    reserveBook,
    cancelReservation,
    toggleFavoriteBook,
    setShowProfileModal,
  } = useLibrary();

  const student = currentUser?.studentData || students[0];

  const [activeTab, setActiveTab] = useState<'my-loans' | 'catalog' | 'favorites' | 'reservations' | 'history'>('my-loans');
  const [readingBook, setReadingBook] = useState<Book | null>(null);

  // Catalog search & filter
  const [catalogSearch, setCatalogSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  if (!student || !currentUser) {
    return null;
  }

  // Student specific data
  const myLoans = loans.filter((l) => l.studentId === student.id);
  const myActiveLoans = myLoans.filter((l) => l.status === 'active' || l.status === 'overdue');
  const myHistoryLoans = myLoans.filter((l) => l.status === 'returned');
  const myReservations = reservations.filter((r) => r.studentId === student.id);
  const myFavoriteBooks = books.filter((b) => (b.favoritedBy || []).includes(currentUser.id));

  const hasOverdueLoans = myActiveLoans.some((l) => l.status === 'overdue');

  // Filter catalog by search & category
  const filteredCatalog = books.filter((b) => {
    const q = catalogSearch.toLowerCase();
    const matchesSearch =
      b.title.toLowerCase().includes(q) ||
      b.author.toLowerCase().includes(q) ||
      b.category.toLowerCase().includes(q);
    const matchesCat = selectedCategory === 'all' || b.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const menuItems: SidebarMenuItem[] = [
    {
      id: 'my-loans',
      label: 'Mening kitoblarim',
      icon: <BookOpen className="w-4 h-4" />,
      badge: myActiveLoans.length,
    },
    {
      id: 'catalog',
      label: 'Elektron katalog',
      icon: <Layers className="w-4 h-4" />,
      badge: books.length,
    },
    {
      id: 'favorites',
      label: 'Sevimli kitoblarim',
      icon: <Heart className="w-4 h-4" />,
      badge: myFavoriteBooks.length,
    },
    {
      id: 'reservations',
      label: 'Mening buyurtmalarim',
      icon: <Bookmark className="w-4 h-4" />,
      badge: myReservations.length,
    },
    {
      id: 'history',
      label: 'Ijara tarixi',
      icon: <CheckCircle2 className="w-4 h-4" />,
      badge: myHistoryLoans.length,
    },
  ];

  const renderCatalogCard = (book: Book) => {
    const isAvailable = book.availableCopies > 0;
    const isAlreadyReserved = reservations.some(
      (r) => r.bookId === book.id && r.studentId === student.id && r.status === 'kutilmoqda'
    );
    const isFavorited = (book.favoritedBy || []).includes(currentUser.id);

    return (
      <div
        key={book.id}
        className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between hover:shadow-md transition-all"
      >
        <div>
          <div className="flex gap-4">
            <img
              src={book.coverUrl}
              alt={book.title}
              className="w-20 h-28 object-cover rounded-xl shadow-xs flex-shrink-0"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                  {book.category}
                </span>
                <button
                  type="button"
                  onClick={() => toggleFavoriteBook(book.id)}
                  aria-label={`Sevimliga qo'shish: ${book.title}`}
                  className={`p-1 rounded-lg transition-colors ${
                    isFavorited ? 'text-rose-600 bg-rose-50' : 'text-slate-400 hover:text-rose-500 hover:bg-rose-50'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isFavorited ? 'fill-current' : ''}`} />
                </button>
              </div>
              <h3 className="font-bold text-sm text-slate-900 mt-1 line-clamp-2 leading-snug">
                {book.title}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">{book.author}</p>

              <div className="mt-2 text-xs space-y-1">
                <div className="flex items-center gap-1 text-[11px] text-slate-600">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                  <span className="truncate">
                    {book.location.shelf}, {book.location.section}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-[11px] text-slate-500">
                  <span className="flex items-center gap-1">
                    <Eye className="w-3.5 h-3.5 text-blue-500" />
                    {book.viewsCount || 0}
                  </span>
                  <span className="flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5 text-rose-500" />
                    {book.favoritesCount || 0}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <p className="text-xs text-slate-600 line-clamp-2 mt-3 font-sans">{book.description}</p>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
          <div>
            <div className="text-xs font-bold">
              {isAvailable ? (
                <span className="text-emerald-600">{book.availableCopies} ta nusxa bor</span>
              ) : (
                <span className="text-amber-600">Faqat elektron</span>
              )}
            </div>
            <div className="text-[10px] text-slate-400">
              {book.pages} bet • {book.year}-yil
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setReadingBook(book)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>O'qish (PDF)</span>
            </button>

            {isAvailable && (
              <button
                type="button"
                disabled={isAlreadyReserved}
                onClick={() => reserveBook(book.id, student.id)}
                className={`p-1.5 rounded-lg border transition-colors ${
                  isAlreadyReserved
                    ? 'bg-amber-50 text-amber-600 border-amber-200 cursor-not-allowed'
                    : 'hover:bg-slate-100 text-slate-600 border-slate-200'
                }`}
                title={isAlreadyReserved ? 'Allaqachon band qilingan' : 'Kutubxonadan olish uchun bron qilish'}
                aria-label={`Kitobni bron qilish: ${book.title}`}
              >
                <Bookmark className={`w-4 h-4 ${isAlreadyReserved ? 'fill-current' : ''}`} />
              </button>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <DashboardLayout
      accentColor="emerald"
      panelTitle="Talaba Kabineti"
      panelSubtitle={`${student.group}-guruh • ${student.course}-kurs`}
      menuItems={menuItems}
      activeMenuId={activeTab}
      onSelectMenu={(id) => setActiveTab(id as typeof activeTab)}
    >
      {/* Modern Student Profile Card / Header */}
      <div className="bg-linear-to-r from-slate-900 via-emerald-950 to-teal-950 rounded-3xl p-6 text-white shadow-lg border border-white/10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex items-start gap-4 min-w-0">
          <UserAvatar
            name={student.name}
            avatarUrl={currentUser.avatarUrl || student.avatarUrl}
            sizeClass="w-16 h-16 sm:w-18 sm:h-18"
            textClass="text-xl"
            roundedClass="rounded-2xl"
            className="ring-2 ring-emerald-400/40 shadow-md"
          />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-lg text-[11px] font-mono font-semibold bg-emerald-400/15 text-emerald-200 border border-emerald-400/25">
                {student.studentId}
              </span>
              <span
                className={`px-2.5 py-0.5 rounded-lg text-[11px] font-semibold ${
                  student.status === 'active'
                    ? 'bg-emerald-500/20 text-emerald-200'
                    : 'bg-rose-500/20 text-rose-200'
                }`}
              >
                {student.status === 'active' ? "Faol o'quvchi" : 'Bloklangan'}
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight mt-1.5 truncate">
              {student.name}
            </h1>

            <p className="text-xs text-emerald-100/90 mt-1">
              {student.faculty} • <span className="font-semibold text-white">{student.group}</span>-guruh (
              {student.course}-kurs)
            </p>
            <p className="text-xs text-slate-300 mt-0.5">
              {student.specialtyCode ? `[${student.specialtyCode}] ` : ''}
              {student.specialty}
            </p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="grid grid-cols-3 bg-white/10 backdrop-blur-md p-3 rounded-2xl border border-white/15 tabular-nums">
            <div className="text-center px-3 border-r border-white/10">
              <div className="text-xl font-extrabold text-emerald-300">{myActiveLoans.length} ta</div>
              <div className="text-[10px] text-slate-300 mt-0.5">Qo'ldagi kitob</div>
            </div>

            <div className="text-center px-3 border-r border-white/10">
              <div className={`text-xl font-extrabold ${hasOverdueLoans ? 'text-rose-400' : 'text-slate-100'}`}>
                {myActiveLoans.filter((l) => l.status === 'overdue').length} ta
              </div>
              <div className="text-[10px] text-slate-300 mt-0.5">Kechikkan</div>
            </div>

            <div className="text-center px-3">
              <div className="text-xl font-extrabold text-teal-300">{myHistoryLoans.length} ta</div>
              <div className="text-[10px] text-slate-300 mt-0.5">O'qilgan</div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setShowProfileModal(true)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-semibold text-white transition-colors"
          >
            <UserCheck className="w-4 h-4 text-emerald-300" />
            <span>Profilni sozlash</span>
          </button>
        </div>
      </div>

      {/* Overdue alert banner */}
      {hasOverdueLoans && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 flex items-start gap-3 text-rose-800">
          <AlertTriangle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
          <div className="text-xs">
            <div className="font-bold text-sm text-rose-900">
              Diqqat: Sizda topshirish muddati o'tgan kitob(lar) mavjud!
            </div>
            <p className="mt-0.5 text-rose-700">
              Kutubxona nizomiga binoan, yangi kitoblarni olish uchun avval muddati o'tgan kitoblarni topshirishingiz yoki kutubxonachi orqali uzaytirishingiz lozim.
            </p>
          </div>
        </div>
      )}

      {/* Section 1: My Active Loans */}
      {activeTab === 'my-loans' && (
        <div className="space-y-4">
          {myActiveLoans.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-xs">
              <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center mb-4">
                <BookOpen className="w-8 h-8" />
              </div>
              <h3 className="font-bold text-slate-900 text-lg">Sizda hozircha olingan kitoblar yo'q</h3>
              <p className="text-slate-500 text-xs mt-1 max-w-sm mx-auto">
                Katalogdan kerakli o'quv qo'llanmani topib, kutubxonachidan olishingiz yoki to'g'ridan-to'g'ri PDF shaklida o'qishingiz mumkin.
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('catalog')}
                className="mt-4 px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-semibold shadow-xs hover:bg-emerald-700 transition-colors"
              >
                Katalogga o'tish
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {myActiveLoans.map((loan) => {
                const isOverdue = loan.status === 'overdue';
                const daysOverdue = calculateDaysOverdue(loan.dueDate);
                const book = books.find((b) => b.id === loan.bookId);

                return (
                  <div
                    key={loan.id}
                    className={`bg-white rounded-2xl border p-5 shadow-xs flex flex-col justify-between transition-all ${
                      isOverdue ? 'border-rose-300 ring-2 ring-rose-500/20' : 'border-slate-200'
                    }`}
                  >
                    <div className="flex gap-4">
                      <img
                        src={loan.bookCoverUrl}
                        alt={loan.bookTitle}
                        className="w-20 h-28 object-cover rounded-xl shadow-xs flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              isOverdue ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {isOverdue ? "Muddati o'tgan" : "Qo'lingizda"}
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono">
                            Olingan: {formatUzbekDate(loan.issueDate)}
                          </span>
                        </div>

                        <h3 className="font-bold text-sm text-slate-900 mt-1 line-clamp-2 leading-snug">
                          {loan.bookTitle}
                        </h3>
                        <p className="text-xs text-slate-500 mt-0.5">{loan.bookAuthor}</p>

                        <div className="mt-3 text-xs space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="text-slate-500 text-[11px]">Topshirish muddati:</span>
                            <span className={`font-semibold ${isOverdue ? 'text-rose-600 font-bold' : 'text-slate-900'}`}>
                              {formatUzbekDate(loan.dueDate)}
                            </span>
                          </div>

                          {isOverdue ? (
                            <div className="p-2 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-[11px] font-semibold flex items-center justify-between">
                              <span>{daysOverdue} kun kechikkan</span>
                              <span>Jarima: {formatUzbekCurrency(loan.fineAmount)}</span>
                            </div>
                          ) : (
                            <div className="text-[11px] text-emerald-700 font-medium flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5" />
                              <span>Muddati yetarli</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                      {book && (
                        <button
                          type="button"
                          onClick={() => setReadingBook(book)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs transition-colors"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>O'qish (PDF)</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => prolongLoan(loan.id, 7)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-medium transition-colors"
                      >
                        <RotateCw className="w-3.5 h-3.5" />
                        <span>Uzaytirish (+7 kun)</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Section 2: Catalog & Reading */}
      {activeTab === 'catalog' && (
        <div className="space-y-4">
          <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
              <input
                type="text"
                placeholder="Darslik yoki kitob nomi, muallif bo'yicha qidirish..."
                value={catalogSearch}
                onChange={(e) => setCatalogSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 rounded-xl border border-slate-300 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                aria-label="Kategoriya bo'yicha saralash"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-white border border-slate-300 text-xs font-medium rounded-xl px-3.5 py-2 text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              >
                <option value="all">Barcha kategoriyalar ({books.length})</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name} ({books.filter((b) => b.category === c.name).length})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {filteredCatalog.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500 text-sm">
              Hozircha katalogda mos kitoblar topilmadi.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredCatalog.map(renderCatalogCard)}
            </div>
          )}
        </div>
      )}

      {/* Section 3: Favorites */}
      {activeTab === 'favorites' && (
        <div className="space-y-4">
          {myFavoriteBooks.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-xs">
              <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-500 mx-auto flex items-center justify-center mb-4">
                <Heart className="w-8 h-8" />
              </div>
              <h3 className="font-bold text-slate-900 text-lg">Sevimli kitoblar ro'yxati bo'sh</h3>
              <p className="text-slate-500 text-xs mt-1 max-w-sm mx-auto">
                Katalogdagi yoqtirgan kitoblaringizda yurakcha tugmasini bosing va ular shu yerda saqlanadi.
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('catalog')}
                className="mt-4 px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-semibold shadow-xs hover:bg-emerald-700 transition-colors"
              >
                Katalogga o'tish
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {myFavoriteBooks.map(renderCatalogCard)}
            </div>
          )}
        </div>
      )}

      {/* Section 4: Reservations */}
      {activeTab === 'reservations' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm">Siz band qilgan kitoblar</h3>
            <span className="text-xs text-slate-500">{myReservations.length} ta buyurtma</span>
          </div>

          <div className="divide-y divide-slate-100">
            {myReservations.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-sm">
                Hozirda band qilingan kitoblaringiz yo'q.
              </div>
            ) : (
              myReservations.map((res) => (
                <div key={res.id} className="p-4 sm:px-6 flex items-center justify-between gap-4 text-xs">
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">{res.bookTitle}</h4>
                    <p className="text-slate-500 text-xs mt-0.5">
                      Buyurtma sanasi: {formatUzbekDate(res.requestDate)} • Kutubxonadan olib ketish muddati:{' '}
                      <span className="font-semibold text-emerald-700">{formatUzbekDate(res.expiryDate)}</span> gacha
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-800">
                      Kutubxonada kutilmoqda
                    </span>

                    <button
                      type="button"
                      onClick={() => cancelReservation(res.id)}
                      className="px-3 py-1 border border-slate-300 hover:bg-slate-50 text-slate-600 rounded-lg text-xs"
                    >
                      Bekor qilish
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Section 5: History */}
      {activeTab === 'history' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm">Ilgari olib topshirgan kitoblaringiz tarixi</h3>
            <span className="text-xs text-slate-500">{myHistoryLoans.length} ta kitob</span>
          </div>

          <div className="divide-y divide-slate-100">
            {myHistoryLoans.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-sm">
                Topshirilgan kitoblar tarixi mavjud emas.
              </div>
            ) : (
              myHistoryLoans.map((loan) => {
                const matchedBook = books.find((b) => b.id === loan.bookId);
                return (
                  <div key={loan.id} className="p-4 sm:px-6 flex items-center justify-between gap-4 text-xs">
                    <div className="flex items-center gap-3">
                      <img
                        src={loan.bookCoverUrl}
                        alt={loan.bookTitle}
                        className="w-10 h-14 object-cover rounded shadow-xs"
                      />
                      <div>
                        <h4 className="font-bold text-sm text-slate-900">{loan.bookTitle}</h4>
                        <div className="text-slate-500 mt-0.5">
                          {loan.bookAuthor} • Olingan: {formatUzbekDate(loan.issueDate)}
                        </div>
                        {loan.returnDate && (
                          <div className="text-[11px] text-emerald-600 font-medium">
                            Topshirildi: {formatUzbekDate(loan.returnDate)} (Holati:{' '}
                            {loan.conditionOnReturn || 'yaxshi'})
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {matchedBook && (
                        <button
                          type="button"
                          onClick={() => setReadingBook(matchedBook)}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 text-xs font-semibold"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>O'qish</span>
                        </button>
                      )}
                      <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-700">
                        Topshirilgan
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Reader Modal */}
      {readingBook && <EBookReaderModal book={readingBook} onClose={() => setReadingBook(null)} />}
    </DashboardLayout>
  );
};
