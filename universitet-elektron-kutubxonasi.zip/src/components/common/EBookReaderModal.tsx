import React, { useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import type { Book } from '../../types/library';
import { useLibrary } from '../../context/LibraryContext';
import { formatFileSize } from '../../utils/fileStorage';
import { buildGeneratedBookPdfBlob, canDownloadBookPdf } from '../../utils/libraryRules';
import {
  X,
  BookOpen,
  Sun,
  Moon,
  Type,
  ChevronLeft,
  ChevronRight,
  Bookmark,
  FileText,
  Download,
  Eye,
  Heart,
  ZoomIn,
  ZoomOut,
  Lock,
} from 'lucide-react';

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
  'pdfjs-dist/build/pdf.worker.min.mjs',
  import.meta.url
).toString();

interface EBookReaderModalProps {
  book: Book;
  onClose: () => void;
}

export const EBookReaderModal: React.FC<EBookReaderModalProps> = ({ book, onClose }) => {
  const { books, currentUser, activeRole, authToken, incrementBookViews, toggleFavoriteBook } = useLibrary();

  const liveBook = books.find((b) => b.id === book.id) || book;
  const isFavorited = Boolean(currentUser && (liveBook.favoritedBy || []).includes(currentUser.id));
  const downloadAllowed = canDownloadBookPdf(liveBook, activeRole);

  const chapters =
    liveBook.ebookChapters && liveBook.ebookChapters.length > 0
      ? liveBook.ebookChapters
      : [
          {
            id: 'sample-1',
            title: `1-bob: Kirish va asosiy tushunchalar`,
            content: `${liveBook.title} kitobining elektron talqini. Ushbu o'quv qo'llanma universitet o'quv dasturi asosida tayyorlangan bo'lib, talabalarning fanni chuqur o'zlashtirishlari uchun nazariy va amaliy tavsiyalarni o'z ichiga oladi.\n\nMuallif: ${liveBook.author}\nKategoriya: ${liveBook.category}\nNashr yili: ${liveBook.year}\nSahifalar: ${liveBook.pages} bet\n\n${liveBook.description}`,
          },
          {
            id: 'sample-2',
            title: '2-bob: Nazariy qism va tahlil',
            content: `Fanning ushbu bo'limida asosiy ilmiy metodologiya, zamonaviy tadqiqotlar va tajribalar tahlil qilinadi. Talaba mavzuni o'rganish jarayonida amaliy mashg'ulotlar va mustaqil ta'lim topshiriqlarini bajarishi tavsiya etiladi.`,
          },
        ];

  const [viewMode, setViewMode] = useState<'pdf' | 'text'>('pdf');
  const [pdfBlobUrl, setPdfBlobUrl] = useState<string | null>(null);
  const [pdfDoc, setPdfDoc] = useState<pdfjsLib.PDFDocumentProxy | null>(null);
  const [numPages, setNumPages] = useState(0);
  const [zoom, setZoom] = useState(1.25);
  const [isLoadingPdf, setIsLoadingPdf] = useState(true);
  const [pdfError, setPdfError] = useState('');

  const [currentChapterIndex, setCurrentChapterIndex] = useState(0);
  const [fontSize, setFontSize] = useState<'sm' | 'base' | 'lg' | 'xl'>('base');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);

  const canvasContainerRef = useRef<HTMLDivElement | null>(null);
  const incrementedRef = useRef<string | null>(null);

  // Increment view count once per opened book
  useEffect(() => {
    if (incrementedRef.current !== book.id) {
      incrementedRef.current = book.id;
      incrementBookViews(book.id);
    }
  }, [book.id, incrementBookViews]);

  // Load uploaded PDF from central server API or build generated PDF Blob and parse via pdf.js
  useEffect(() => {
    let active = true;
    let createdObjectUrl: string | null = null;
    let loadingTask: pdfjsLib.PDFDocumentLoadingTask | null = null;

    async function preparePdf() {
      setIsLoadingPdf(true);
      setPdfError('');
      try {
        let blob: Blob | null = null;
        if (book.pdfFileId) {
          const headers: Record<string, string> = {};
          if (authToken) {
            headers['Authorization'] = `Bearer ${authToken}`;
          }
          const resp = await fetch(`/api/files/${encodeURIComponent(book.pdfFileId)}`, { headers });
          if (resp.ok) {
            blob = await resp.blob();
          } else if (resp.status === 401) {
            throw new Error("PDF faylini o'qish uchun tizimga kirish talab qilinadi.");
          }
        }
        if (!blob) {
          blob = buildGeneratedBookPdfBlob(book);
        }

        if (!active) return;
        if (downloadAllowed) {
          createdObjectUrl = URL.createObjectURL(blob);
          setPdfBlobUrl(createdObjectUrl);
        } else {
          setPdfBlobUrl(null);
        }

        const arrayBuffer = await blob.arrayBuffer();
        loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(arrayBuffer) });
        const loadedDoc = await loadingTask.promise;

        if (!active) {
          await loadingTask.destroy();
          return;
        }
        setPdfDoc(loadedDoc);
        setNumPages(loadedDoc.numPages);
      } catch (err) {
        if (active) {
          setPdfError(
            err instanceof Error && err.message
              ? err.message
              : "PDF sahifalarini ko'rsatishda xatolik yuz berdi. Matn rejimidan foydalanishingiz mumkin."
          );
        }
      } finally {
        if (active) setIsLoadingPdf(false);
      }
    }

    preparePdf();

    return () => {
      active = false;
      if (createdObjectUrl) {
        URL.revokeObjectURL(createdObjectUrl);
      }
      if (loadingTask) {
        loadingTask.destroy().catch(() => {});
      }
    };
  }, [book, authToken, downloadAllowed]);

  // Render PDF pages onto crisp canvases inside the modal whenever pdfDoc, zoom, or viewMode changes
  useEffect(() => {
    if (viewMode !== 'pdf' || !pdfDoc || !canvasContainerRef.current) return;

    let cancelled = false;
    const container = canvasContainerRef.current;

    async function renderPages() {
      container.innerHTML = '';
      const dpr = Math.min(window.devicePixelRatio || 1, 2);

      for (let pageNum = 1; pageNum <= pdfDoc!.numPages; pageNum++) {
        if (cancelled) return;
        const page = await pdfDoc!.getPage(pageNum);
        if (cancelled) return;

        const viewport = page.getViewport({ scale: zoom });
        const wrapper = document.createElement('div');
        wrapper.className = 'bg-white rounded-lg shadow-xl overflow-hidden border border-slate-300';

        const canvas = document.createElement('canvas');
        canvas.width = Math.floor(viewport.width * dpr);
        canvas.height = Math.floor(viewport.height * dpr);
        canvas.style.width = `${Math.floor(viewport.width)}px`;
        canvas.style.height = `${Math.floor(viewport.height)}px`;
        canvas.className = 'block';

        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.scale(dpr, dpr);
          await page.render({ canvasContext: ctx, viewport, canvas }).promise;
        }

        wrapper.appendChild(canvas);
        if (!cancelled) {
          container.appendChild(wrapper);
        }
      }
    }

    renderPages();

    return () => {
      cancelled = true;
    };
  }, [pdfDoc, zoom, viewMode]);

  const currentChapter = chapters[currentChapterIndex];

  const fontClasses = {
    sm: 'text-sm leading-relaxed',
    base: 'text-base leading-relaxed',
    lg: 'text-lg leading-loose',
    xl: 'text-xl leading-loose',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div
        className={`w-full max-w-5xl h-[92vh] flex flex-col rounded-2xl shadow-2xl overflow-hidden border transition-colors ${
          isDarkMode ? 'bg-slate-900 text-slate-100 border-slate-700' : 'bg-white text-slate-900 border-slate-200'
        }`}
      >
        {/* Header Bar */}
        <div
          className={`flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 border-b ${
            isDarkMode ? 'bg-slate-800/80 border-slate-700' : 'bg-slate-50 border-slate-200'
          }`}
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-lg bg-blue-600 text-white flex-shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="font-bold text-sm sm:text-base truncate">{liveBook.title}</h2>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <span>
                  {liveBook.author} • {liveBook.category}
                </span>
                {liveBook.pdfFileName && (
                  <span className="px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 font-medium text-[10px]">
                    {liveBook.pdfFileName} ({formatFileSize(liveBook.pdfFileSize)})
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Engagement counters + Favorite */}
            <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-600 dark:text-slate-300">
              <span className="flex items-center gap-1" title="Ko'rishlar soni">
                <Eye className="w-3.5 h-3.5 text-blue-500" />
                {liveBook.viewsCount || 0}
              </span>
              <span>•</span>
              <button
                type="button"
                onClick={() => toggleFavoriteBook(liveBook.id)}
                className={`flex items-center gap-1 transition-colors ${
                  isFavorited ? 'text-rose-600' : 'hover:text-rose-500'
                }`}
                title="Sevimlilarga qo'shish"
              >
                <Heart className={`w-3.5 h-3.5 ${isFavorited ? 'fill-current' : ''}`} />
                {liveBook.favoritesCount || 0}
              </button>
            </div>

            {/* PDF Zoom Controls */}
            {viewMode === 'pdf' && numPages > 0 && (
              <div className="flex items-center border rounded-lg px-1.5 py-0.5 gap-1 border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800">
                <button
                  type="button"
                  onClick={() => setZoom((z) => Math.max(0.75, +(z - 0.15).toFixed(2)))}
                  aria-label="Kichiklashtirish"
                  className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <span className="text-[11px] font-mono font-semibold px-1 text-slate-700 dark:text-slate-200">
                  {Math.round(zoom * 100)}%
                </span>
                <button
                  type="button"
                  onClick={() => setZoom((z) => Math.min(2.2, +(z + 0.15).toFixed(2)))}
                  aria-label="Kattalashtirish"
                  className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* PDF vs Text Mode Switcher */}
            <div className="flex items-center bg-slate-200/70 dark:bg-slate-700 p-0.5 rounded-lg">
              <button
                type="button"
                onClick={() => setViewMode('pdf')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold transition-all ${
                  viewMode === 'pdf'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>PDF ko'rinish</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('text')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold transition-all ${
                  viewMode === 'text'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Matn rejimi</span>
              </button>
            </div>

            {downloadAllowed && pdfBlobUrl ? (
              <a
                href={pdfBlobUrl}
                download={liveBook.pdfFileName || `${liveBook.title.replace(/\s+/g, '_')}.pdf`}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 hover:bg-slate-200/60 dark:hover:bg-slate-700 text-xs font-semibold transition-colors"
                title="PDF faylni yuklab olish"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Yuklab olish</span>
              </a>
            ) : (
              <span
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-200/70 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-medium"
                title="Ushbu kitob faqat sayt ichida o'qish uchun ochiq"
              >
                <Lock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span className="hidden md:inline">Faqat o'qish</span>
              </span>
            )}

            {viewMode === 'text' && (
              <>
                <div className="flex items-center border rounded-lg px-2 py-1 gap-1 border-slate-300 dark:border-slate-700">
                  <Type className="w-3.5 h-3.5 text-slate-400" />
                  <button
                    type="button"
                    onClick={() => setFontSize('sm')}
                    className={`text-xs px-1.5 py-0.5 rounded font-medium ${
                      fontSize === 'sm' ? 'bg-blue-600 text-white' : 'text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    A-
                  </button>
                  <button
                    type="button"
                    onClick={() => setFontSize('base')}
                    className={`text-xs px-1.5 py-0.5 rounded font-medium ${
                      fontSize === 'base' ? 'bg-blue-600 text-white' : 'text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    A
                  </button>
                  <button
                    type="button"
                    onClick={() => setFontSize('lg')}
                    className={`text-xs px-1.5 py-0.5 rounded font-medium ${
                      fontSize === 'lg' ? 'bg-blue-600 text-white' : 'text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    A+
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setIsDarkMode(!isDarkMode)}
                  aria-label="Rang rejimini almashtirish"
                  className="p-2 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
                >
                  {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
                </button>

                <button
                  type="button"
                  onClick={() => setIsBookmarked(!isBookmarked)}
                  aria-label="Xatcho'p qo'yish"
                  className={`p-2 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors ${
                    isBookmarked ? 'text-amber-500 fill-amber-500' : 'text-slate-400'
                  }`}
                >
                  <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
                </button>
              </>
            )}

            <button
              type="button"
              onClick={onClose}
              aria-label="Yopish"
              className="p-2 rounded-lg hover:bg-rose-100 hover:text-rose-600 dark:hover:bg-rose-950/40 text-slate-400 transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        {viewMode === 'pdf' ? (
          <div className="flex-1 bg-slate-700 overflow-y-auto flex flex-col items-center p-6">
            {isLoadingPdf ? (
              <div className="flex-1 flex items-center justify-center text-white text-sm">
                PDF sahifalari yuklanmoqda...
              </div>
            ) : pdfError ? (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-200 p-6 text-center space-y-3">
                <p className="text-sm">{pdfError}</p>
                <button
                  type="button"
                  onClick={() => setViewMode('text')}
                  className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold"
                >
                  Matn rejimiga o'tish
                </button>
              </div>
            ) : (
              <>
                <div className="mb-3 px-3 py-1 rounded-full bg-slate-800/80 text-slate-200 text-xs font-medium">
                  PDF Hujjat • Jami {numPages} sahifa
                </div>
                <div
                  ref={canvasContainerRef}
                  data-testid="pdf-canvas-container"
                  className="flex flex-col items-center gap-5 pb-6"
                />
              </>
            )}
          </div>
        ) : (
          <div className="flex-1 flex overflow-hidden">
            {/* Table of contents sidebar */}
            <div
              className={`w-64 border-r hidden md:block overflow-y-auto p-4 ${
                isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-50/50 border-slate-100'
              }`}
            >
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                Mundarija ({chapters.length} bob)
              </h3>
              <div className="space-y-1">
                {chapters.map((chap, idx) => (
                  <button
                    key={chap.id}
                    type="button"
                    onClick={() => setCurrentChapterIndex(idx)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                      idx === currentChapterIndex
                        ? 'bg-blue-600 text-white shadow-sm'
                        : isDarkMode
                        ? 'hover:bg-slate-800 text-slate-300'
                        : 'hover:bg-slate-200/70 text-slate-700'
                    }`}
                  >
                    {chap.title}
                  </button>
                ))}
              </div>

              <div className="mt-8 pt-4 border-t border-slate-200 dark:border-slate-800">
                <div className="text-[11px] text-slate-400 space-y-1">
                  <div>
                    ISBN: <span className="font-mono text-slate-500">{liveBook.isbn}</span>
                  </div>
                  <div>
                    Joylashuvi: {liveBook.location.shelf}, {liveBook.location.section}
                  </div>
                  <div>
                    Qog'oz nusxalar: {liveBook.availableCopies} / {liveBook.totalCopies}
                  </div>
                </div>
              </div>
            </div>

            {/* Text Reading Area */}
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="flex-1 overflow-y-auto p-8 sm:p-12 max-w-3xl mx-auto w-full">
                <div className="mb-6 pb-4 border-b border-slate-200 dark:border-slate-800">
                  <span className="text-xs font-semibold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                    Bob {currentChapterIndex + 1} / {chapters.length}
                  </span>
                  <h1 className="text-2xl font-bold mt-1">{currentChapter.title}</h1>
                </div>

                <div className={`prose dark:prose-invert max-w-none whitespace-pre-line font-serif ${fontClasses[fontSize]}`}>
                  {currentChapter.content}
                </div>
              </div>

              {/* Bottom Navigation */}
              <div
                className={`flex items-center justify-between px-8 py-3 border-t ${
                  isDarkMode ? 'bg-slate-800/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <button
                  type="button"
                  disabled={currentChapterIndex === 0}
                  onClick={() => setCurrentChapterIndex((prev) => Math.max(0, prev - 1))}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-300 dark:border-slate-700 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Oldingi bob
                </button>

                <span className="text-xs text-slate-400">
                  Sahifa {currentChapterIndex + 1} / {chapters.length}
                </span>

                <button
                  type="button"
                  disabled={currentChapterIndex === chapters.length - 1}
                  onClick={() => setCurrentChapterIndex((prev) => Math.min(chapters.length - 1, prev + 1))}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-300 dark:border-slate-700 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Keyingi bob
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
