import React, { useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import type { BookCategory } from '../../types/library';
import { getCategoryImage } from '../../utils/categoryVisuals';
import { getCategoryBookCounts } from '../../utils/libraryRules';
import { readFileAsDataUrl } from '../../utils/fileStorage';
import {
  FolderPlus,
  Trash2,
  BookOpen,
  AlertCircle,
  Pencil,
  Check,
  X,
  Image as ImageIcon,
} from 'lucide-react';

interface CategoriesManagerProps {
  accentColor?: 'purple' | 'blue';
}

export const CategoriesManager: React.FC<CategoriesManagerProps> = ({ accentColor = 'blue' }) => {
  const { categories, books, createCategory, updateCategory, deleteCategory, uploadServerFile } =
    useLibrary();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [imageFileName, setImageFileName] = useState('');
  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editImageDataUrl, setEditImageDataUrl] = useState<string | null>(null);
  const [editImageFileName, setEditImageFileName] = useState('');

  const categoryCounts = getCategoryBookCounts(categories, books);

  const handleImagePick = async (
    e: React.ChangeEvent<HTMLInputElement>,
    target: 'create' | 'edit'
  ) => {
    const file = e.target.files?.[0];
    if (!file || !file.type.startsWith('image/')) return;
    const dataUrl = await readFileAsDataUrl(file);
    if (target === 'create') {
      setImageDataUrl(dataUrl);
      setImageFileName(file.name);
    } else {
      setEditImageDataUrl(dataUrl);
      setEditImageFileName(file.name);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSaving(true);
    try {
      let uploadedUrl: string | undefined;
      if (imageDataUrl && imageFileName) {
        const up = await uploadServerFile(imageDataUrl, imageFileName, 'image/jpeg');
        if (up) uploadedUrl = up.url;
      }
      const res = await createCategory({ name, description, imageUrl: uploadedUrl });
      if (!res.success) {
        setError(res.message);
        return;
      }
      setName('');
      setDescription('');
      setImageDataUrl(null);
      setImageFileName('');
    } finally {
      setIsSaving(false);
    }
  };

  const startEdit = (cat: BookCategory) => {
    setEditingId(cat.id);
    setEditName(cat.name);
    setEditDescription(cat.description || '');
    setEditImageDataUrl(null);
    setEditImageFileName('');
    setError('');
  };

  const handleSaveEdit = async (id: string) => {
    setError('');
    let uploadedUrl: string | undefined;
    if (editImageDataUrl && editImageFileName) {
      const up = await uploadServerFile(editImageDataUrl, editImageFileName, 'image/jpeg');
      if (up) uploadedUrl = up.url;
    }
    const res = await updateCategory(id, {
      name: editName,
      description: editDescription,
      ...(uploadedUrl ? { imageUrl: uploadedUrl } : {}),
    });
    if (!res.success) {
      setError(res.message);
      return;
    }
    setEditingId(null);
  };

  const btnColor =
    accentColor === 'purple'
      ? 'bg-purple-600 hover:bg-purple-700 shadow-purple-500/20'
      : 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/20';

  const ringColor =
    accentColor === 'purple' ? 'focus:ring-purple-500' : 'focus:ring-blue-500';

  return (
    <div className="space-y-6">
      {/* Create Category Form */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6">
        <div className="flex items-center gap-2.5 mb-4">
          <div
            className={`p-2 rounded-xl ${
              accentColor === 'purple' ? 'bg-purple-100 text-purple-600' : 'bg-blue-100 text-blue-600'
            }`}
          >
            <FolderPlus className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-base text-slate-900">Yangi kitob kategoriyasi yaratish</h2>
            <p className="text-xs text-slate-500">
              Yangi kitob qo'shilganda ushbu kategoriyalardan birini tanlash mumkin bo'ladi
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-4 flex items-center gap-2 p-3 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-medium">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleCreate} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          <div className="md:col-span-3">
            <label htmlFor="cat-name-input" className="block text-xs font-semibold text-slate-700 mb-1">
              Kategoriya nomi *
            </label>
            <input
              id="cat-name-input"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Masalan: Kiberxavfsizlik"
              className={`w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-hidden focus:ring-2 ${ringColor}`}
            />
          </div>

          <div className="md:col-span-4">
            <label htmlFor="cat-desc-input" className="block text-xs font-semibold text-slate-700 mb-1">
              Qisqacha izoh
            </label>
            <input
              id="cat-desc-input"
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Ushbu bo'limga oid darsliklar tavsifi..."
              className={`w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-hidden focus:ring-2 ${ringColor}`}
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1">Kichik rasm (ixtiyoriy)</label>
            <label
              htmlFor="cat-image-upload"
              className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl border border-slate-300 bg-slate-50 hover:bg-slate-100 text-xs font-medium text-slate-700 cursor-pointer truncate"
            >
              <ImageIcon className="w-4 h-4 text-blue-600 flex-shrink-0" />
              <span className="truncate">{imageFileName || 'Rasm tanlash'}</span>
            </label>
            <input
              id="cat-image-upload"
              type="file"
              accept="image/*"
              onChange={(e) => handleImagePick(e, 'create')}
              className="sr-only"
            />
          </div>

          <div className="md:col-span-3">
            <button
              type="submit"
              disabled={isSaving}
              className={`w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-white text-sm font-semibold shadow-md transition-all disabled:opacity-50 ${btnColor}`}
            >
              <FolderPlus className="w-4 h-4" />
              <span>Kategoriya qo'shish</span>
            </button>
          </div>
        </form>
      </div>

      {/* Categories List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-base">
            Mavjud kitob kategoriyalari ({categories.length})
          </h3>
          <span className="text-xs text-slate-500 tabular-nums">Jami {books.length} ta kitob taqsimlangan</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {categories.map((cat, idx) => {
            const bookCount = categoryCounts[cat.name] || 0;
            const isEditing = editingId === cat.id;
            const thumbSrc = getCategoryImage(cat, idx);

            return (
              <div
                key={cat.id}
                className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 bg-slate-50/50 flex flex-col justify-between gap-3 transition-all"
              >
                {isEditing ? (
                  <div className="space-y-2">
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-bold"
                    />
                    <input
                      type="text"
                      value={editDescription}
                      onChange={(e) => setEditDescription(e.target.value)}
                      placeholder="Izoh"
                      className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs"
                    />
                    <div className="flex items-center justify-between gap-2">
                      <label className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-[11px] font-medium text-slate-700 cursor-pointer">
                        <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                        <span>{editImageFileName || 'Rasmni almashtirish'}</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImagePick(e, 'edit')}
                          className="sr-only"
                        />
                      </label>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setEditingId(null)}
                          className="px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-slate-600 text-xs"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveEdit(cat.id)}
                          className={`px-3 py-1 rounded-lg text-white text-xs font-semibold flex items-center gap-1 ${btnColor}`}
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Saqlash</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="flex items-start gap-3">
                      <img
                        src={thumbSrc}
                        alt={cat.name}
                        className="w-12 h-12 rounded-xl object-cover border border-slate-200 flex-shrink-0 bg-white"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <h4 className="font-bold text-sm text-slate-900 leading-snug">{cat.name}</h4>
                          <div className="flex items-center gap-1 flex-shrink-0">
                            <button
                              type="button"
                              onClick={() => startEdit(cat)}
                              aria-label={`Kategoriyani tahrirlash: ${cat.name}`}
                              title="Tahrirlash"
                              className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => deleteCategory(cat.id)}
                              aria-label={`Kategoriyani o'chirish: ${cat.name}`}
                              title="Kategoriyani o'chirish"
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                        {cat.description && (
                          <p className="text-xs text-slate-500 mt-1 line-clamp-2">{cat.description}</p>
                        )}
                      </div>
                    </div>

                    <div className="pt-2.5 border-t border-slate-200/70 flex items-center justify-between text-xs">
                      <span className="flex items-center gap-1 font-semibold text-slate-700 tabular-nums">
                        <BookOpen className="w-3.5 h-3.5 text-slate-400" />
                        {bookCount} ta kitob
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">{cat.createdAt}</span>
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
