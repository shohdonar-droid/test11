import React, { useEffect, useRef } from 'react';
import type { Book } from '../../types/library';
import { useLibrary } from '../../context/LibraryContext';
import { formatFileSize } from '../../utils/fileStorage';
import {
  X,
  BookOpen,
  MapPin,
  Eye,
  Heart,
  LogIn,
  Lock,
  Calendar,
  FileText,
  Layers,
  Building2,
} from 'lucide-react';

interface BookDetailsModalProps {
  book: Book;
  onClose: () => void;
  onLoginClick: () => void;
}

export const BookDetailsModal: React.FC<BookDetailsModalProps> = ({
  book,
  onClose,
  onLoginClick,
}) => {
  const { books, incrementBookViews } = useLibrary();
  const liveBook = books.find((b) => b.id === book.id) || book;
  const incrementedRef = useRef<string | null>(null);

  useEffect(() => {
    if (incrementedRef.current !== book.id) {
      incrementedRef.current = book.id;
      incrementBookViews(book.id);
    }
  }, [book.id, incrementBookViews]);

  const chapters =
    liveBook.ebookChapters && liveBook.ebookChapters.length > 0
      ? liveBook.ebookChapters
      : [
          { id: 'ch-1', title: '1-bob: Kirish va asosiy tushunchalar', content: '' },
          { id: 'ch-2', title: '2-bob: Nazariy asoslar va amaliy tahlil', content: '' },
        ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-linear-to-r from-slate-900 via-indigo-950 to-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/15">
              <BookOpen className="w-5 h-5 text-blue-300" />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg">Kitob haqida batafsil ma'lumot</h2>
              <p className="text-xs text-slate-300">
                Elektron kutubxona katalogi • Ommaviy ko'rish
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Yopish"
            className="p-1.5 rounded-lg hover:bg-white/20 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3.5">
          {/* Book Hero */}
          <div className="flex flex-col sm:flex-row gap-4">
            <img
              src={liveBook.coverUrl}
              alt={liveBook.title}
              className="w-28 h-40 object-cover rounded-xl shadow-md border border-slate-200 flex-shrink-0 mx-auto sm:mx-0"
            />
            <div className="flex-1 space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                  {liveBook.category}
                </span>
                {liveBook.isEbookAvailable && (
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    PDF elektron nusxasi mavjud
                  </span>
                )}
              </div>

              <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 leading-snug">
                {liveBook.title}
              </h3>
              <p className="text-sm font-semibold text-slate-600">{liveBook.author}</p>

              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
                <span className="flex items-center gap-1.5">
                  <Eye className="w-4 h-4 text-blue-500" />
                  <strong className="text-slate-800">{liveBook.viewsCount || 0}</strong> marta ko'rildi
                </span>
                <span className="flex items-center gap-1.5">
                  <Heart className="w-4 h-4 text-rose-500 fill-current" />
                  <strong className="text-slate-800">{liveBook.favoritesCount || 0}</strong> ta sevimli
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">Nashr yili & Betlar</div>
                  <div className="font-semibold text-slate-800 mt-0.5 flex items-center gap-1 tabular-nums">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    {liveBook.year}-yil • {liveBook.pages} bet
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">Kutubxona javoni</div>
                  <div className="font-semibold text-slate-800 mt-0.5 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-blue-600 flex-shrink-0" />
                    <span className="truncate">
                      {liveBook.location.shelf}, {liveBook.location.section}
                    </span>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">Bosma nusxalar</div>
                  <div className="font-semibold text-slate-800 mt-0.5 flex items-center gap-1 tabular-nums">
                    <Layers className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                    {liveBook.availableCopies} / {liveBook.totalCopies} ta mavjud
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">Til & Elektron rejim</div>
                  <div className="font-semibold text-slate-800 mt-0.5 truncate">
                    {liveBook.language}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Kitob annotatsiyasi
            </h4>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              {liveBook.description}
            </p>
            <div className="pt-1.5 flex flex-wrap gap-3 text-[11px] text-slate-500 font-mono">
              <span>ISBN: {liveBook.isbn}</span>
              <span>•</span>
              <span>Inventar: {liveBook.barcode}</span>
              <span>•</span>
              <span className="inline-flex items-center gap-1 font-sans">
                <Building2 className="w-3 h-3" /> {liveBook.location.building}, {liveBook.location.floor}-qavat
              </span>
            </div>
          </div>

          {/* Table of contents preview (titles only) */}
          <div className="space-y-1.5">
            <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Mundarija ({chapters.length} ta bob)
            </h4>
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-y-auto max-h-36">
              {chapters.map((ch) => (
                <div key={ch.id} className="px-3.5 py-2 text-xs font-medium text-slate-700 flex items-center justify-between gap-2">
                  <span>{ch.title}</span>
                  <Lock className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                </div>
              ))}
            </div>
          </div>

          {/* Auth-gated PDF Callout */}
          <div className="p-3.5 rounded-2xl bg-linear-to-r from-blue-50 to-indigo-50 border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-xl bg-blue-600 text-white flex-shrink-0">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-slate-900">
                  Elektron PDF kitobni o'qish uchun tizimga kiring
                </h4>
                <p className="text-xs text-slate-600 mt-0.5">
                  {liveBook.pdfFileName
                    ? `Biriktirilgan fayl: ${liveBook.pdfFileName} (${formatFileSize(liveBook.pdfFileSize)}) — o'qish uchun profilga kirish talab etiladi.`
                    : "Kitobning to'liq PDF matnini o'qish faqat ro'yxatdan o'tgan foydalanuvchilar uchun ochiq."}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onLoginClick}
              className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 flex-shrink-0 transition-all"
            >
              <LogIn className="w-4 h-4" />
              <span>Profilga kirish</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold transition-colors"
          >
            Yopish
          </button>
        </div>
      </div>
    </div>
  );
};
