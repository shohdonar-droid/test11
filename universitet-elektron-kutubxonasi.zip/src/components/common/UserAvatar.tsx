import React, { useEffect, useState } from 'react';

interface UserAvatarProps {
  name?: string;
  avatarUrl?: string;
  sizeClass?: string;
  textClass?: string;
  roundedClass?: string;
  className?: string;
}

const PALETTES = [
  'from-blue-600 to-indigo-700 text-white',
  'from-emerald-600 to-teal-700 text-white',
  'from-purple-600 to-indigo-700 text-white',
  'from-sky-600 to-blue-700 text-white',
  'from-amber-600 to-orange-700 text-white',
  'from-rose-600 to-pink-700 text-white',
];

function getInitials(name?: string): string {
  const clean = (name || '').trim();
  if (!clean) return 'U';
  const parts = clean.split(/\s+/).filter(Boolean);
  if (parts.length === 1) {
    return parts[0].slice(0, 2).toUpperCase();
  }
  return `${parts[0][0] || ''}${parts[1][0] || ''}`.toUpperCase();
}

function getPaletteIndex(name?: string): number {
  const s = (name || '').trim();
  let sum = 0;
  for (let i = 0; i < s.length; i += 1) {
    sum += s.charCodeAt(i);
  }
  return sum % PALETTES.length;
}

export const UserAvatar: React.FC<UserAvatarProps> = ({
  name,
  avatarUrl,
  sizeClass = 'w-9 h-9',
  textClass = 'text-xs',
  roundedClass = 'rounded-xl',
  className = '',
}) => {
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    setHasError(false);
  }, [avatarUrl]);

  const trimmedUrl = (avatarUrl || '').trim();
  if (trimmedUrl && !hasError) {
    return (
      <img
        src={trimmedUrl}
        alt={name || 'Foydalanuvchi'}
        onError={() => setHasError(true)}
        className={`${sizeClass} ${roundedClass} object-cover flex-shrink-0 ${className}`}
      />
    );
  }

  const palette = PALETTES[getPaletteIndex(name)];
  return (
    <div
      aria-label={name || 'Foydalanuvchi'}
      className={`${sizeClass} ${roundedClass} bg-linear-to-br ${palette} flex items-center justify-center font-extrabold tracking-wide select-none flex-shrink-0 shadow-xs ${textClass} ${className}`}
    >
      {getInitials(name)}
    </div>
  );
};
