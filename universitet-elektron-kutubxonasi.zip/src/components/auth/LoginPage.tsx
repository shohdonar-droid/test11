import React, { useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import {
  GraduationCap,
  Lock,
  User,
  Eye,
  EyeOff,
  ArrowRight,
  AlertCircle,
  Home,
} from 'lucide-react';

export const LoginPage: React.FC = () => {
  const { login, setCurrentView, siteSettings } = useLibrary();

  const [loginInput, setLoginInput] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!loginInput.trim() || !password) {
      setErrorMessage("Iltimos, login va parolni to'liq kiriting!");
      return;
    }

    setIsSubmitting(true);
    const result = await login(loginInput, password);
    setIsSubmitting(false);

    if (!result.success) {
      setErrorMessage(result.message);
    }
  };

  return (
    <div className="min-h-screen bg-linear-to-br from-slate-950 via-blue-950 to-indigo-950 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute top-0 -left-40 w-96 h-96 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 -right-40 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

      {/* Top back button */}
      <div className="absolute top-6 left-6 z-10">
        <button
          type="button"
          onClick={() => setCurrentView('landing')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-900/70 hover:bg-blue-700/80 text-white text-xs font-semibold backdrop-blur-md border border-cyan-300/40 shadow-[0_0_16px_rgba(56,189,248,0.28)] transition-all cursor-pointer"
        >
          <Home className="w-4 h-4 text-cyan-300" />
          <span>Kutubxona portaliga qaytish</span>
        </button>
      </div>

      <div className="sm:mx-auto sm:w-full sm:max-w-md z-10 px-4">
        {/* University Crest & Brand */}
        <div className="text-center">
          {siteSettings.header.logoUrl ? (
            <div className="inline-flex w-18 h-18 rounded-full bg-white p-1 ring-2 ring-cyan-300/70 shadow-[0_0_24px_rgba(34,211,238,0.45)] mb-3 overflow-hidden">
              <img
                src={siteSettings.header.logoUrl}
                alt={siteSettings.header.brandName}
                className="w-full h-full rounded-full object-contain"
              />
            </div>
          ) : (
            <div className="inline-flex w-14 h-14 rounded-2xl bg-linear-to-br from-blue-600 to-indigo-600 items-center justify-center text-white shadow-xl shadow-blue-500/25 mb-3">
              <GraduationCap className="w-8 h-8" />
            </div>
          )}
          <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
            {siteSettings.header.brandName}
          </h2>
          <p className="mt-1 text-xs text-cyan-200/90">
            Elektron kutubxona tizimiga yagona avtorizatsiya portali
          </p>
        </div>

        {/* Login Card */}
        <div className="mt-6 bg-white/95 backdrop-blur-xl py-8 px-6 shadow-2xl rounded-3xl border border-white/20 sm:px-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            {errorMessage && (
              <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-2.5">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Login input */}
            <div>
              <label htmlFor="login-identifier" className="block text-xs font-semibold text-slate-700 mb-1">
                Login / Talaba ID / Email
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
                <input
                  id="login-identifier"
                  type="text"
                  required
                  value={loginInput}
                  onChange={(e) => setLoginInput(e.target.value)}
                  placeholder="Talaba ID yoki elektron pochta"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-600 focus:outline-hidden bg-slate-50/50"
                />
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">
                Har bir foydalanuvchi o'zining shaxsiy login va paroli bilan kiradi
              </span>
            </div>

            {/* Password input */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="login-password" className="block text-xs font-semibold text-slate-700">
                  Maxfiy parol
                </label>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
                <input
                  id="login-password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-600 focus:outline-hidden bg-slate-50/50"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label="Parolni ko'rsatish"
                  className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 p-0.5"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Submit button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full mt-2 flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-white font-semibold text-sm bg-linear-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 disabled:opacity-50 shadow-md shadow-blue-500/25 transition-all"
            >
              <span>{isSubmitting ? 'Tekshirilmoqda...' : 'Kabinetga kirish'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-slate-200 text-center text-[11px] text-slate-500">
            Hisobingizga kirishda muammo bo'lsa, universitet kutubxona ma'muriyatiga murojaat qiling.
          </div>
        </div>
      </div>
    </div>
  );
};
