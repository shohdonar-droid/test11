import React, { useEffect, useState } from 'react';
import { useLibrary } from '../../context/LibraryContext';
import { UserAvatar } from '../common/UserAvatar';
import { readFileAsDataUrl } from '../../utils/fileStorage';
import {
  X,
  User,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  Save,
  Lock,
  Shield,
  BookOpen,
  GraduationCap,
  Mail,
  Phone,
  Clock,
  Building2,
  Camera,
  Trash2,
} from 'lucide-react';

async function resizeAvatarToDataUrl(file: File, maxSize = 360): Promise<string> {
  const dataUrl = await readFileAsDataUrl(file);
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
      const w = Math.max(1, Math.round(img.width * scale));
      const h = Math.max(1, Math.round(img.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      } else {
        resolve(dataUrl);
      }
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

export const UserProfileModal: React.FC = () => {
  const {
    currentUser,
    activeRole,
    setShowProfileModal,
    updateProfile,
    uploadServerFile,
    changePassword,
    loans,
    books,
  } = useLibrary();

  const [activeTab, setActiveTab] = useState<'info' | 'security'>('info');

  // Profile edit fields
  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [phone, setPhone] = useState(currentUser?.phone || '+998 ');
  const [avatarPreviewUrl, setAvatarPreviewUrl] = useState(currentUser?.avatarUrl || '');
  const [pendingAvatarDataUrl, setPendingAvatarDataUrl] = useState<string | null>(null);
  const [pendingAvatarName, setPendingAvatarName] = useState('');
  const [infoError, setInfoError] = useState('');
  const [isSavingInfo, setIsSavingInfo] = useState(false);

  // Password fields
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [isSavingPass, setIsSavingPass] = useState(false);

  useEffect(() => {
    if (!currentUser) return;
    setName(currentUser.name || '');
    setEmail(currentUser.email || '');
    setPhone(currentUser.phone || '+998 ');
    setAvatarPreviewUrl(currentUser.avatarUrl || '');
    setPendingAvatarDataUrl(null);
    setPendingAvatarName('');
  }, [currentUser?.id, currentUser?.name, currentUser?.email, currentUser?.phone, currentUser?.avatarUrl]);

  if (!currentUser || !activeRole) {
    return null;
  }

  const handleAvatarFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setInfoError('');
    if (!file.type.startsWith('image/')) {
      setInfoError('Profil rasmi uchun faqat JPG, PNG yoki WEBP rasm faylini tanlang.');
      return;
    }
    try {
      const optimized = await resizeAvatarToDataUrl(file);
      setAvatarPreviewUrl(optimized);
      setPendingAvatarDataUrl(optimized);
      setPendingAvatarName(file.name);
    } catch {
      setInfoError("Profil rasmini o'qishda xatolik yuz berdi.");
    }
  };

  const handleRemoveAvatar = () => {
    setAvatarPreviewUrl('');
    setPendingAvatarDataUrl(null);
    setPendingAvatarName('');
  };

  const handleSaveInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    setInfoError('');
    if (!name.trim()) {
      setInfoError("F.I.Sh. maydoni bo'sh bo'lmasligi kerak.");
      return;
    }

    setIsSavingInfo(true);
    try {
      let finalAvatarUrl = avatarPreviewUrl.trim();
      if (pendingAvatarDataUrl && pendingAvatarName) {
        const uploaded = await uploadServerFile(
          pendingAvatarDataUrl,
          pendingAvatarName,
          'image/jpeg'
        );
        if (!uploaded) {
          setInfoError('Profil rasmini serverga yuklashda xatolik yuz berdi.');
          return;
        }
        finalAvatarUrl = uploaded.url;
      }

      const res = await updateProfile({
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim(),
        avatarUrl: finalAvatarUrl,
      });
      if (!res.success) {
        setInfoError(res.message);
      } else {
        setPendingAvatarDataUrl(null);
        setPendingAvatarName('');
      }
    } finally {
      setIsSavingInfo(false);
    }
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (newPassword !== confirmPassword) {
      setPasswordError('Yangi parollar bir-biriga mos kelmadi!');
      return;
    }

    setIsSavingPass(true);
    try {
      const res = await changePassword(currentPassword, newPassword);
      if (!res.success) {
        setPasswordError(res.message);
      } else {
        setPasswordSuccess('Parolingiz muvaffaqiyatli yangilandi!');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      }
    } finally {
      setIsSavingPass(false);
    }
  };

  const student = currentUser.studentData;
  const librarian = currentUser.librarianData;
  const admin = currentUser.adminData;

  const studentLoans = student ? loans.filter((l) => l.studentId === student.id) : [];
  const activeBooksCount = studentLoans.filter((l) => l.status !== 'returned').length;
  const returnedBooksCount = studentLoans.filter((l) => l.status === 'returned').length;
  const favoriteBooksCount = books.filter((b) => (b.favoritedBy || []).includes(currentUser.id)).length;

  const roleTheme =
    activeRole === 'admin'
      ? {
          headerBg: 'from-slate-900 via-purple-950 to-indigo-950',
          accentText: 'text-purple-700',
          accentBg: 'bg-purple-50 border-purple-200',
          accentBtn: 'bg-purple-600 hover:bg-purple-700',
          tabActive: 'border-purple-600 text-purple-700',
          roleName: 'Administrator',
          roleIcon: <Shield className="w-3.5 h-3.5" />,
        }
      : activeRole === 'librarian'
      ? {
          headerBg: 'from-slate-900 via-blue-950 to-indigo-950',
          accentText: 'text-blue-700',
          accentBg: 'bg-blue-50 border-blue-200',
          accentBtn: 'bg-blue-600 hover:bg-blue-700',
          tabActive: 'border-blue-600 text-blue-700',
          roleName: 'Kutubxonachi',
          roleIcon: <BookOpen className="w-3.5 h-3.5" />,
        }
      : {
          headerBg: 'from-slate-900 via-emerald-950 to-teal-950',
          accentText: 'text-emerald-700',
          accentBg: 'bg-emerald-50 border-emerald-200',
          accentBtn: 'bg-emerald-600 hover:bg-emerald-700',
          tabActive: 'border-emerald-600 text-emerald-700',
          roleName: 'Talaba',
          roleIcon: <GraduationCap className="w-3.5 h-3.5" />,
        };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/65 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Identity Header */}
        <div className={`relative px-6 py-6 bg-linear-to-r ${roleTheme.headerBg} text-white`}>
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-4 min-w-0">
              <UserAvatar
                name={name || currentUser.name}
                avatarUrl={avatarPreviewUrl}
                sizeClass="w-16 h-16 sm:w-18 sm:h-18"
                textClass="text-lg"
                roundedClass="rounded-2xl"
                className="ring-2 ring-white/25 shadow-lg"
              />
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-0.5 rounded-lg bg-white/15 text-white border border-white/15">
                    {roleTheme.roleIcon}
                    <span>{roleTheme.roleName}</span>
                  </span>
                  {student && (
                    <span className="font-mono text-[11px] font-semibold px-2.5 py-0.5 rounded-lg bg-emerald-400/15 text-emerald-200 border border-emerald-400/25">
                      {student.studentId}
                    </span>
                  )}
                </div>
                <h2 className="font-extrabold text-xl tracking-tight mt-1.5 truncate">
                  {name || currentUser.name}
                </h2>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-300 mt-1">
                  <span className="inline-flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    {currentUser.email}
                  </span>
                  {currentUser.phone && (
                    <span className="inline-flex items-center gap-1.5 font-mono">
                      <Phone className="w-3.5 h-3.5 text-slate-400" />
                      {currentUser.phone}
                    </span>
                  )}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowProfileModal(false)}
              aria-label="Yopish"
              className="p-2 rounded-xl hover:bg-white/15 text-white/80 transition-colors flex-shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50/80 px-6 gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('info')}
            className={`py-3.5 px-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'info'
                ? roleTheme.tabActive
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Profil ma'lumotlari</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('security')}
            className={`py-3.5 px-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'security'
                ? roleTheme.tabActive
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>Xavfsizlik va Parol</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeTab === 'info' && (
            <>
              {/* Role Structured Overview */}
              {activeRole === 'student' && student && (
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-3">
                    <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                      <div className="text-[11px] font-semibold text-slate-500">Qo'ldagi kitoblar</div>
                      <div className="text-xl font-extrabold text-slate-900 mt-0.5 tabular-nums">
                        {activeBooksCount} ta
                      </div>
                    </div>
                    <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                      <div className="text-[11px] font-semibold text-slate-500">O'qilgan kitoblar</div>
                      <div className="text-xl font-extrabold text-emerald-700 mt-0.5 tabular-nums">
                        {returnedBooksCount} ta
                      </div>
                    </div>
                    <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                      <div className="text-[11px] font-semibold text-slate-500">Sevimli kitoblar</div>
                      <div className="text-xl font-extrabold text-rose-600 mt-0.5 tabular-nums">
                        {favoriteBooksCount} ta
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl border border-emerald-200/80 bg-emerald-50/40 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-slate-500 block text-[11px]">Fakultet</span>
                      <span className="font-bold text-slate-900 mt-0.5 block">{student.faculty || '—'}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[11px]">Yo'nalish</span>
                      <span className="font-bold text-slate-900 mt-0.5 block">
                        {student.specialtyCode ? `[${student.specialtyCode}] ` : ''}
                        {student.specialty || '—'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[11px]">Guruh va Kurs</span>
                      <span className="font-bold text-slate-900 mt-0.5 block">
                        {student.group}-guruh • {student.course}-kurs
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[11px]">Kutubxona holati</span>
                      <span className="font-bold text-emerald-700 mt-0.5 block">
                        {student.status === 'active' ? "Faol o'quvchi" : 'Bloklangan'}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {activeRole === 'librarian' && librarian && (
                <div className="p-4 rounded-2xl border border-blue-200/80 bg-blue-50/40 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="flex items-start gap-2.5">
                    <Building2 className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="text-slate-500 block text-[11px]">Biriktirilgan bo'lim</span>
                      <span className="font-bold text-slate-900 mt-0.5 block">{librarian.department}</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <Clock className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="text-slate-500 block text-[11px]">Ish smenasi</span>
                      <span className="font-bold text-slate-900 mt-0.5 block">{librarian.shift}</span>
                    </div>
                  </div>
                </div>
              )}

              {activeRole === 'admin' && admin && (
                <div className="p-4 rounded-2xl border border-purple-200/80 bg-purple-50/40 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-500 block text-[11px]">Lavozim</span>
                    <span className="font-bold text-slate-900 mt-0.5 block">{admin.title}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Oxirgi kirish vaqti</span>
                    <span className="font-mono font-semibold text-slate-900 mt-0.5 block">
                      {admin.lastLogin || 'Hozir faol'}
                    </span>
                  </div>
                </div>
              )}

              {/* Editable Profile Form (F.I.Sh., Avatar, Email, Phone) */}
              <form onSubmit={handleSaveInfo} className="space-y-4 pt-2 border-t border-slate-200">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Shaxsiy ma'lumotlar va profil rasmi
                  </h4>
                </div>

                {infoError && (
                  <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    <span>{infoError}</span>
                  </div>
                )}

                {/* Avatar Uploader */}
                <div className="flex flex-col sm:flex-row sm:items-center gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <UserAvatar
                    name={name || currentUser.name}
                    avatarUrl={avatarPreviewUrl}
                    sizeClass="w-16 h-16"
                    textClass="text-lg"
                    roundedClass="rounded-2xl"
                    className="border border-slate-200 shadow-xs"
                  />
                  <div className="flex-1 space-y-1.5">
                    <div className="text-xs font-bold text-slate-800">Profil rasmi (ixtiyoriy)</div>
                    <p className="text-[11px] text-slate-500">
                      Xohlasangiz o'zingizning shaxsiy rasmingizni yuklang yoki o'zgartiring.
                    </p>
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      <label
                        htmlFor="profile-avatar-upload"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 text-xs font-semibold cursor-pointer transition-colors shadow-2xs"
                      >
                        <Camera className="w-3.5 h-3.5 text-blue-600" />
                        <span>{avatarPreviewUrl ? "Rasmni o'zgartirish" : 'Rasm yuklash'}</span>
                      </label>
                      <input
                        id="profile-avatar-upload"
                        type="file"
                        accept="image/*"
                        onChange={handleAvatarFileChange}
                        className="sr-only"
                      />
                      {avatarPreviewUrl && (
                        <button
                          type="button"
                          onClick={handleRemoveAvatar}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-semibold transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>O'chirish</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <div>
                  <label htmlFor="profile-name" className="block text-xs font-semibold text-slate-700 mb-1.5">
                    F.I.Sh. (Familiya, Ism, Sharif) *
                  </label>
                  <input
                    id="profile-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden bg-white"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label htmlFor="profile-email" className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Elektron pochta
                    </label>
                    <input
                      id="profile-email"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden bg-white"
                    />
                  </div>

                  <div>
                    <label htmlFor="profile-phone" className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Telefon raqami
                    </label>
                    <input
                      id="profile-phone"
                      type="text"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-mono focus:ring-2 focus:ring-blue-500 focus:outline-hidden bg-white"
                    />
                  </div>
                </div>

                <div className="pt-2 flex justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setShowProfileModal(false)}
                    className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-colors"
                  >
                    Yopish
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingInfo}
                    className={`flex items-center gap-1.5 px-5 py-2.5 disabled:opacity-50 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors ${roleTheme.accentBtn}`}
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isSavingInfo ? 'Saqlanmoqda...' : "O'zgarishlarni saqlash"}</span>
                  </button>
                </div>
              </form>
            </>
          )}

          {activeTab === 'security' && (
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-start gap-2.5">
                <Lock className="w-4 h-4 text-slate-500 flex-shrink-0 mt-0.5" />
                <span>
                  Hisob xavfsizligini ta'minlash uchun kamida 4 ta belgidan iborat mustahkam parol tanlang.
                </span>
              </div>

              {passwordError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{passwordError}</span>
                </div>
              )}

              {passwordSuccess && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                  <span>{passwordSuccess}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Amaldagi parol *</label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  placeholder="Hozirgi parolingizni kiriting"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">Yangi parol *</label>
                  <input
                    type="password"
                    required
                    minLength={4}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    placeholder="Kamida 4 ta belgi"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">Yangi parolni tasdiqlash *</label>
                  <input
                    type="password"
                    required
                    minLength={4}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    placeholder="Yangi parolni qayta tering"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={isSavingPass}
                  className={`flex items-center gap-1.5 px-5 py-2.5 disabled:opacity-50 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors ${roleTheme.accentBtn}`}
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>{isSavingPass ? 'Yangilanmoqda...' : 'Parolni yangilash'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
