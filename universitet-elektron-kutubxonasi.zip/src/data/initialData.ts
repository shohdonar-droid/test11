import type {
  Book,
  Student,
  Librarian,
  Loan,
  Reservation,
  ActivityLog,
  AdminAccount,
  Specialty,
  BookCategory,
  Faculty,
  SiteSettings,
} from '../types/library';

export const UNIVERSITY_LOGO_PATH = '/assets/aistudio/logo_ae8dbeb8.png';

export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  header: {
    brandName: 'Toshkent Davlat Tibbiyot Universiteti — Chirchiq filiali',
    logoUrl: UNIVERSITY_LOGO_PATH,
    navCatalogLabel: 'Elektron katalog',
    navServicesLabel: 'Xizmatlar',
    navRulesLabel: 'Qoidalar',
    navContactLabel: "Bog'lanish",
    ctaLabel: 'Tizimga kirish',
  },
  footer: {
    brandName: 'Toshkent Davlat Tibbiyot Universiteti Chirchiq filiali',
    description: 'Axborot-Resurs va Elektron Kutubxona Markazi',
    rightNote: 'Admin, Kutubxonachi va Talaba kabinetlari',
    yearText: '2026-yil',
  },
  banner: {
    badgeText: 'Toshkent Davlat Tibbiyot Universiteti — Chirchiq filiali ARM',
    titlePrefix: 'Tibbiyot va ilm-fan uchun',
    titleHighlight: 'yagona elektron kutubxona',
    subtitle:
      "Universitet axborot-resurs markazi fondidagi darsliklar, elektron o'quv qo'llanmalar, ilmiy adabiyotlar va klinik qo'llanmalarni onlayn qidiring, band qiling va PDF shaklida qulay o'qing.",
    searchPlaceholder: "Kitob nomi, muallif yoki fan bo'yicha qidiring...",
    backgroundType: 'gradient',
    backgroundMediaUrl: '',
    overlayOpacity: 60,
  },
  services: {
    kicker: 'Kutubxona xizmatlari',
    title: "Talabalar va professor-o'qituvchilar uchun qulayliklar",
    subtitle:
      "Axborot-resurs markazimiz barcha talabalarga ta'lim jarayonida zamonaviy elektron va bosma resurslarni taqdim etadi",
    items: [
      {
        id: 'srv-1',
        title: "Elektron o'quv zali",
        description:
          "Tizimda barcha darsliklar raqamlashtirilgan. PDF o'quv rejimi, matn qidiruvi va qulay interfeys orqali istalgan qurilmada mutolaa qiling.",
        icon: 'book',
        color: 'blue',
      },
      {
        id: 'srv-2',
        title: 'Shaffof ijara va hisob',
        description:
          "Kitoblarni berish va qaytarish to'liq avtomatlashtirilgan. Muddatlar, qolgan kunlar va muddati o'tgan kitoblar bo'yicha aniq nazorat olib boriladi.",
        icon: 'shield',
        color: 'purple',
      },
      {
        id: 'srv-3',
        title: 'Javonlar navigatsiyasi',
        description:
          "Har bir bosma kitobning bino, qavat, javon va tokcha raqami ko'rsatiladi. Kerakli adabiyotni zallardan soniyalar ichida topishingiz mumkin.",
        icon: 'map',
        color: 'emerald',
      },
    ],
  },
  rules: {
    kicker: 'Kutubxona tartib-qoidalari',
    title: 'Kitoblardan foydalanish va qaytarish qoidalari',
    items: [
      'Darsliklar talabalarga standart 14 kun muddatga beriladi.',
      "Talaba bir vaqtning o'zida maksimal 5 tagacha kitob olish huquqiga ega.",
      "Kitob topshirish muddatini tizim orqali qo'shimcha 7 kunga uzaytirish mumkin.",
      "Muddati o'tgan kitoblar uchun kunlik 2,000 so'm ramziy kechikish to'lovi hisoblanadi.",
    ],
  },
  contact: {
    title: 'Kutubxona ish tartibi va aloqa',
    scheduleLabel: 'Dushanba — Shanba:',
    scheduleValue: '08:30 dan 20:00 gacha (Yakshanba dam olish)',
    addressLabel: 'Manzil:',
    addressValue: 'Chirchiq shahri, Universitet bosh binosi, Axborot-Resurs Markazi',
    phoneLabel: "Kutubxona ma'lumotlar xizmati:",
    phoneValue: '+998 (70) 200-11-22',
    emailLabel: 'Elektron manzil:',
    emailValue: 'arm@tdtu-chirchiq.uz',
    buttonText: 'Kutubxona tizimiga kirish',
  },
};

export const INITIAL_FACULTIES: Faculty[] = [];
export const INITIAL_SPECIALTIES: Specialty[] = [];
export const INITIAL_CATEGORIES: BookCategory[] = [];
export const INITIAL_BOOKS: Book[] = [];
export const INITIAL_STUDENTS: Student[] = [];
export const INITIAL_LIBRARIANS: Librarian[] = [];
export const INITIAL_LOANS: Loan[] = [];
export const INITIAL_RESERVATIONS: Reservation[] = [];
export const INITIAL_LOGS: ActivityLog[] = [];

export const INITIAL_ADMIN: AdminAccount = {
  id: 'admin-1',
  name: 'Bosh Administrator',
  email: 'admin@tdtu-chirchiq.uz',
  phone: '+998 70 000 00 00',
  role: 'admin',
  avatarUrl: '',
  password: 'admin123',
  title: 'Axborot-Resurs Markazi Bosh Administratori',
  lastLogin: '',
};
