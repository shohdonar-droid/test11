export type UserRole = 'admin' | 'librarian' | 'student';

export interface Faculty {
  id: string;
  name: string;
  shortName?: string;
  dean?: string;
  createdAt: string;
}

export interface Specialty {
  id: string;
  code: string; // e.g., "60610600"
  name: string; // e.g., "Dasturiy injiniring"
  faculty: string;
}

export interface BookCategory {
  id: string;
  name: string;
  description?: string;
  imageUrl?: string;
  createdAt: string;
}

export interface Student {
  id: string;
  studentId: string; // e.g. TAL-2024-001
  name: string;
  email: string;
  phone: string;
  faculty: string;
  specialty: string;
  specialtyCode?: string;
  course: number;
  group: string;
  status: 'active' | 'blocked';
  avatarUrl: string;
  registeredAt: string;
  password?: string;
  notes?: string;
}

export interface Librarian {
  id: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  shift: string;
  avatarUrl: string;
  password?: string;
}

export interface AdminAccount {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'admin';
  avatarUrl: string;
  password?: string;
  title: string;
  lastLogin?: string;
}

export interface EBookChapter {
  id: string;
  title: string;
  content: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  barcode: string;
  category: string;
  faculty?: string;
  year: number;
  pages: number;
  totalCopies: number;
  availableCopies: number;
  location: {
    building: string;
    floor: number;
    shelf: string;
    section: string;
  };
  coverUrl: string;
  description: string;
  language: string;
  isEbookAvailable: boolean;
  allowPdfDownload?: boolean; // true = talabalar yuklab olishi mumkin; false/undefined = faqat o'qish
  ebookChapters?: EBookChapter[];
  pdfFileId?: string; // server file ID (/api/files/:id) for uploaded PDFs
  pdfFileName?: string;
  pdfFileSize?: number;
  viewsCount: number;
  favoritesCount: number;
  favoritedBy?: string[]; // user IDs
  rating: number;
}

export interface Loan {
  id: string;
  bookId: string;
  bookTitle: string;
  bookAuthor: string;
  bookCoverUrl: string;
  studentId: string; // references Student.id or studentId
  studentName: string;
  studentGroup: string;
  studentFaculty: string;
  librarianId: string;
  librarianName: string;
  issueDate: string; // YYYY-MM-DD
  dueDate: string;   // YYYY-MM-DD
  returnDate?: string;
  status: 'active' | 'overdue' | 'returned';
  fineAmount: number;
  notes?: string;
  conditionOnReturn?: 'a\'lo' | 'yaxshi' | 'zararlangan' | 'yo\'qolgan';
  renewedCount: number;
}

export interface Reservation {
  id: string;
  bookId: string;
  bookTitle: string;
  studentId: string;
  studentName: string;
  requestDate: string;
  status: 'kutilmoqda' | 'tasdiqlandi' | 'bekor_qilindi';
  expiryDate: string;
}

export interface SiteServiceItem {
  id: string;
  title: string;
  description: string;
  icon: 'book' | 'shield' | 'map' | 'clock' | 'award' | 'bookmark';
  color: 'blue' | 'purple' | 'emerald' | 'amber';
}

export interface SiteSettings {
  header: {
    brandName: string;
    logoUrl: string;
    navCatalogLabel: string;
    navServicesLabel: string;
    navRulesLabel: string;
    navContactLabel: string;
    ctaLabel: string;
  };
  footer: {
    brandName: string;
    description: string;
    rightNote: string;
    yearText: string;
  };
  banner: {
    badgeText: string;
    titlePrefix: string;
    titleHighlight: string;
    subtitle: string;
    searchPlaceholder: string;
    backgroundType: 'gradient' | 'image' | 'video';
    backgroundMediaUrl: string;
    overlayOpacity: number; // 20..85
  };
  services: {
    kicker: string;
    title: string;
    subtitle: string;
    items: SiteServiceItem[];
  };
  rules: {
    kicker: string;
    title: string;
    items: string[];
  };
  contact: {
    title: string;
    scheduleLabel: string;
    scheduleValue: string;
    addressLabel: string;
    addressValue: string;
    phoneLabel: string;
    phoneValue: string;
    emailLabel: string;
    emailValue: string;
    buttonText: string;
  };
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  action:
    | 'TALABA_YARATILDI'
    | 'TALABA_TAHRIRLANDI'
    | 'TALABA_OCHIRILDI'
    | 'TALABALAR_IMPORT_QILINDI'
    | 'KITOB_BERILDI'
    | 'KITOB_QAYTARILDI'
    | 'MUDDAT_UZAYTIRILDI'
    | 'KITOB_QO\'SHILDI'
    | 'KITOB_TAHRIRLANDI'
    | 'KITOB_OCHIRILDI'
    | 'KATEGORIYA_YARATILDI'
    | 'KATEGORIYA_TAHRIRLANDI'
    | 'KATEGORIYA_OCHIRILDI'
    | 'YONALISH_YARATILDI'
    | 'YONALISH_TAHRIRLANDI'
    | 'YONALISH_OCHIRILDI'
    | 'FAKULTET_YARATILDI'
    | 'FAKULTET_TAHRIRLANDI'
    | 'FAKULTET_OCHIRILDI'
    | 'XODIM_YARATILDI'
    | 'XODIM_TAHRIRLANDI'
    | 'XODIM_OCHIRILDI'
    | 'BRON_QILINDI'
    | 'BRON_OCHIRILDI'
    | 'SAYT_SOZLAMALARI_YANGILANDI'
    | 'PROFIL_YANGILANDI';
  performerName: string;
  performerRole: UserRole;
  details: string;
}

