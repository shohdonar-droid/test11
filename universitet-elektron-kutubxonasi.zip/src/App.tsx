import React, { useState } from 'react';
import { LibraryProvider, useLibrary } from './context/LibraryContext';
import { Navbar } from './components/Navbar';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { LibrarianDashboard } from './components/librarian/LibrarianDashboard';
import { StudentDashboard } from './components/student/StudentDashboard';
import { LandingPage } from './components/landing/LandingPage';
import { LoginPage } from './components/auth/LoginPage';
import { UserProfileModal } from './components/profile/UserProfileModal';
import { Toast } from './components/common/Toast';

const MainContent: React.FC = () => {
  const { currentView, activeRole, isAuthenticated, isLoading, showProfileModal, siteSettings } = useLibrary();
  const [overdueJumpKey, setOverdueJumpKey] = useState(0);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-semibold text-slate-500">Kutubxona tizimi yuklanmoqda...</p>
        </div>
      </div>
    );
  }

  // If viewing login page
  if (currentView === 'login' && !isAuthenticated) {
    return (
      <>
        <LoginPage />
        <Toast />
      </>
    );
  }

  // If viewing public landing page or not authenticated
  if (currentView === 'landing' || !isAuthenticated || !activeRole) {
    return (
      <>
        <LandingPage />
        {isAuthenticated && showProfileModal && <UserProfileModal />}
        <Toast />
      </>
    );
  }

  // Authenticated role dashboard
  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      <Navbar onOpenOverdue={() => setOverdueJumpKey((k) => k + 1)} />

      <main className="flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeRole === 'admin' && <AdminDashboard overdueJumpKey={overdueJumpKey} />}
        {activeRole === 'librarian' && <LibrarianDashboard overdueJumpKey={overdueJumpKey} />}
        {activeRole === 'student' && <StudentDashboard />}
      </main>

      {/* Footer Info */}
      <footer className="bg-white border-t border-slate-200 py-4 text-xs text-slate-500 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-center sm:text-left">
            <span className="font-bold text-slate-800">{siteSettings.footer.brandName}</span>
            <span>{siteSettings.footer.description}</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>{siteSettings.footer.rightNote}</span>
            <span>•</span>
            <span>{siteSettings.footer.yearText}</span>
          </div>
        </div>
      </footer>

      {showProfileModal && <UserProfileModal />}
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <LibraryProvider>
      <MainContent />
    </LibraryProvider>
  );
}
