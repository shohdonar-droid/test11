import type { Book, BookCategory, SiteSettings, Specialty, Student, UserRole } from '../types/library';

/**
 * Pure business logic rules for the University Library System.
 * Decoupled from UI components for unit testing.
 */

export const FINE_PER_DAY_UZS = 2000;
export const MAX_ACTIVE_LOANS_PER_STUDENT = 5;
export const STANDARD_LOAN_DAYS = 14;

/**
 * Calculates whether a loan is active, overdue, or returned.
 */
export function calculateLoanStatus(
  dueDate: string,
  returnDate?: string,
  referenceDate?: string
): 'returned' | 'overdue' | 'active' {
  if (returnDate) {
    return 'returned';
  }

  const now = referenceDate ? new Date(referenceDate) : new Date();
  const due = new Date(dueDate);

  // Normalize to start of day for comparison
  const nowDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const dueDay = new Date(due.getFullYear(), due.getMonth(), due.getDate()).getTime();

  if (nowDay > dueDay) {
    return 'overdue';
  }
  return 'active';
}

/**
 * Calculates how many days a loan is overdue. Returns 0 if not overdue.
 */
export function calculateDaysOverdue(dueDate: string, referenceDate?: string): number {
  const now = referenceDate ? new Date(referenceDate) : new Date();
  const due = new Date(dueDate);

  const nowDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const dueDay = new Date(due.getFullYear(), due.getMonth(), due.getDate()).getTime();

  if (nowDay <= dueDay) {
    return 0;
  }

  const diffMs = nowDay - dueDay;
  return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Calculates fine amount in Uzbek So'm based on overdue days.
 */
export function calculateFine(daysOverdue: number, ratePerDay = FINE_PER_DAY_UZS): number {
  if (daysOverdue <= 0) return 0;
  return daysOverdue * ratePerDay;
}

/**
 * Validates whether a student can borrow a specific book.
 */
export function canIssueBook(
  book: { availableCopies: number; title: string },
  student: { status: 'active' | 'blocked'; name: string },
  studentActiveLoansCount: number,
  studentHasOverdueLoans: boolean,
  maxLoans = MAX_ACTIVE_LOANS_PER_STUDENT
): { allowed: boolean; reason?: string } {
  if (student.status === 'blocked') {
    return {
      allowed: false,
      reason: `Talaba "${student.name}" ma'muriyat tomonidan bloklangan.`,
    };
  }

  if (studentHasOverdueLoans) {
    return {
      allowed: false,
      reason: `Talabada muddati o'tgan topshirilmagan kitob(lar) mavjud. Avval ularni topshirishi shart.`,
    };
  }

  if (studentActiveLoansCount >= maxLoans) {
    return {
      allowed: false,
      reason: `Talaba ruxsat etilgan maksimal miqdordagi (${maxLoans} ta) kitoblarni olgan.`,
    };
  }

  if (book.availableCopies <= 0) {
    return {
      allowed: false,
      reason: `"${book.title}" kitobining barcha nusxalari band. Kutubxona fondida bo'sh nusxa yo'q.`,
    };
  }

  return { allowed: true };
}

/**
 * Generates an institutional student ID string, e.g. TAL-2026-007
 */
export function generateStudentId(existingCount: number, year = new Date().getFullYear()): string {
  const nextNum = existingCount + 1;
  const padded = nextNum.toString().padStart(3, '0');
  return `TAL-${year}-${padded}`;
}

/**
 * Formats ISO date to readable Uzbek format (e.g., "12-Noyabr, 2026")
 */
export function formatUzbekDate(isoDate: string): string {
  if (!isoDate) return '';
  const months = [
    'Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'Iyun',
    'Iyul', 'Avgust', 'Sentabr', 'Oktabr', 'Noyabr', 'Dekabr'
  ];
  const d = new Date(isoDate);
  if (isNaN(d.getTime())) return isoDate;
  const day = d.getDate();
  const month = months[d.getMonth()];
  const year = d.getFullYear();
  return `${day}-${month}, ${year}`;
}

/**
 * Formats number to Uzbek currency string (e.g., "14,000 so'm")
 */
export function formatUzbekCurrency(amount: number): string {
  return `${amount.toLocaleString('uz-UZ')} so'm`;
}

/**
 * Finds a Specialty by its shifr (code), case-insensitive & trimmed.
 */
export function findSpecialtyByCode(
  specialties: Specialty[],
  code: string | number | undefined | null
): Specialty | undefined {
  if (code === undefined || code === null) return undefined;
  const normalized = String(code).trim().toLowerCase();
  if (!normalized) return undefined;
  return specialties.find(s => s.code.trim().toLowerCase() === normalized);
}

export interface ParsedImportStudentRow {
  rowNumber: number;
  name: string;
  studentId: string;
  specialtyCode: string;
  specialtyName: string;
  faculty: string;
  course: number;
  group: string;
  phone: string;
  email: string;
  password: string;
  matchedSpecialty: boolean;
  error?: string;
}

/**
 * Maps raw Excel JSON rows to structured student preview objects,
 * automatically resolving specialty name & faculty from the specialty code (shifr).
 */
export function mapExcelRowsToStudents(
  rows: Record<string, unknown>[],
  specialties: Specialty[],
  existingStudents: Pick<Student, 'studentId'>[],
  defaultFaculty = 'Axborot texnologiyalari va dasturiy injiniring'
): ParsedImportStudentRow[] {
  const existingIds = new Set(existingStudents.map(s => s.studentId.trim().toLowerCase()));
  const seenIds = new Set<string>();

  return rows
    .filter(row => {
      // Skip completely empty rows
      return Object.values(row).some(v => String(v ?? '').trim() !== '');
    })
    .map((raw, index) => {
      // Normalize keys (case-insensitive, trim)
      const normalized: Record<string, string> = {};
      for (const [k, v] of Object.entries(raw)) {
        normalized[k.trim().toLowerCase()] = String(v ?? '').trim();
      }

      const name =
        normalized['ism familiya'] ||
        normalized['ism'] ||
        normalized['fio'] ||
        normalized['fish'] ||
        normalized['name'] ||
        normalized['talaba'] ||
        '';

      const rawId =
        normalized['talaba id'] ||
        normalized['id'] ||
        normalized['studentid'] ||
        normalized['bilet'] ||
        '';

      const specialtyCode =
        normalized['yonalish shifri'] ||
        normalized["yo'nalish shifri"] ||
        normalized['shifr'] ||
        normalized['code'] ||
        normalized['kod'] ||
        '';

      const fallbackSpecialtyName =
        normalized['yonalish'] ||
        normalized["yo'nalish"] ||
        normalized['specialty'] ||
        '';

      const group =
        normalized['guruh'] ||
        normalized['group'] ||
        '';

      const courseRaw = parseInt(normalized['kurs'] || normalized['course'] || '1', 10);
      const course = isNaN(courseRaw) || courseRaw < 1 || courseRaw > 6 ? 1 : courseRaw;

      const phone = normalized['telefon'] || normalized['phone'] || '+998 ';
      const emailInput = normalized['email'] || normalized['pochta'] || '';
      const password = normalized['parol'] || normalized['password'] || 'student123';

      const studentId = rawId || generateStudentId(existingStudents.length + index);
      const idLower = studentId.toLowerCase();

      const matched = findSpecialtyByCode(specialties, specialtyCode);
      const specialtyName = matched
        ? matched.name
        : (fallbackSpecialtyName || (specialtyCode ? `Topilmagan shifr (${specialtyCode})` : 'Umumiy yo\'nalish'));
      const faculty = matched
        ? matched.faculty
        : (normalized['fakultet'] || normalized['faculty'] || defaultFaculty);

      const email =
        emailInput ||
        `${(name || studentId).toLowerCase().replace(/[^a-z0-9]/g, '.').replace(/\.+/g, '.')}@univ.uz`;

      let error: string | undefined;
      if (!name) {
        error = 'Ism familiya kiritilmagan';
      } else if (!group) {
        error = 'Guruh raqami kiritilmagan';
      } else if (existingIds.has(idLower) || seenIds.has(idLower)) {
        error = `ID "${studentId}" takrorlangan`;
      } else if (specialtyCode && !matched) {
        error = `"${specialtyCode}" shifrli yo'nalish tizimda topilmadi`;
      }

      seenIds.add(idLower);

      return {
        rowNumber: index + 2, // +1 for 1-based, +1 for header row
        name,
        studentId,
        specialtyCode: matched ? matched.code : specialtyCode,
        specialtyName,
        faculty,
        course,
        group,
        phone,
        email,
        password,
        matchedSpecialty: Boolean(matched),
        error,
      };
    });
}

/**
 * Escapes ASCII text for PDF literal strings.
 */
function sanitizePdfText(input: string): string {
  return input
    .replace(/[ʻʼ’‘`]/g, "'")
    .replace(/[—–]/g, '-')
    .replace(/[^\x20-\x7E]/g, ' ')
    .replace(/\\/g, '\\\\')
    .replace(/\(/g, '\\(')
    .replace(/\)/g, '\\)');
}

/**
 * Generates a real valid minimal PDF (PDF-1.4) Blob URL for any Book so
 * students can open and read it in the built-in browser PDF viewer inside the app.
 */
export function buildGeneratedBookPdfBlob(book: Book): Blob {
  const wrapLine = (text: string, maxChars = 78): string[] => {
    const words = text.split(/\s+/);
    const out: string[] = [];
    let current = '';
    for (const w of words) {
      if ((current + ' ' + w).trim().length > maxChars) {
        if (current) out.push(current.trim());
        current = w;
      } else {
        current = (current + ' ' + w).trim();
      }
    }
    if (current) out.push(current.trim());
    return out;
  };

  const lines: { text: string; size: number; bold?: boolean }[] = [];
  lines.push({ text: 'UNIVERSITET ELEKTRON KUTUBXONASI (UniLib)', size: 10, bold: true });
  lines.push({ text: '--------------------------------------------------------------------------', size: 10 });
  lines.push({ text: book.title, size: 16, bold: true });
  lines.push({ text: `Muallif: ${book.author}`, size: 12 });
  lines.push({ text: `Kategoriya: ${book.category} | Nashr yili: ${book.year}`, size: 10 });
  lines.push({ text: `ISBN: ${book.isbn} | Inventar: ${book.barcode}`, size: 10 });
  lines.push({ text: '--------------------------------------------------------------------------', size: 10 });

  for (const dLine of wrapLine(book.description, 80)) {
    lines.push({ text: dLine, size: 11 });
  }
  lines.push({ text: '', size: 10 });

  const chapters = book.ebookChapters && book.ebookChapters.length > 0
    ? book.ebookChapters
    : [
        {
          id: 'default-1',
          title: '1-bob: Oquv qollanma mazmuni',
          content: book.description,
        },
      ];

  for (const ch of chapters) {
    lines.push({ text: ch.title, size: 13, bold: true });
    for (const para of ch.content.split('\n')) {
      if (!para.trim()) {
        lines.push({ text: '', size: 8 });
      } else {
        for (const wLine of wrapLine(para, 80)) {
          lines.push({ text: wLine, size: 11 });
        }
      }
    }
    lines.push({ text: '', size: 10 });
  }

  // Split lines into PDF pages (~42 lines per page)
  const pagesLines: typeof lines[] = [];
  for (let i = 0; i < lines.length; i += 42) {
    pagesLines.push(lines.slice(i, i + 42));
  }
  if (pagesLines.length === 0) pagesLines.push([{ text: book.title, size: 14 }]);

  // Build PDF objects
  const objects: string[] = [];
  // 1: Catalog
  objects.push('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj');
  // 2: Pages placeholder (will fill Kids later)
  objects.push('');
  // 3: Font Regular
  objects.push('3 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj');
  // 4: Font Bold
  objects.push('4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj');

  const pageObjectIds: number[] = [];
  pagesLines.forEach((pLines, pageIdx) => {
    const contentStreamParts: string[] = ['BT'];
    let y = 760;
    for (const l of pLines) {
      const fontRef = l.bold ? '/F2' : '/F1';
      contentStreamParts.push(`${fontRef} ${l.size} Tf`);
      contentStreamParts.push(`1 0 0 1 50 ${y} Tm (${sanitizePdfText(l.text)}) Tj`);
      y -= l.size + 5;
    }
    contentStreamParts.push(`/F1 9 Tf 1 0 0 1 270 30 Tm (Sahifa ${pageIdx + 1} / ${pagesLines.length}) Tj`);
    contentStreamParts.push('ET');

    const streamStr = contentStreamParts.join('\n');
    const contentObjId = objects.length + 1;
    objects.push(
      `${contentObjId} 0 obj\n<< /Length ${streamStr.length} >>\nstream\n${streamStr}\nendstream\nendobj`
    );

    const pageObjId = objects.length + 1;
    pageObjectIds.push(pageObjId);
    objects.push(
      `${pageObjId} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentObjId} 0 R >>\nendobj`
    );
  });

  objects[1] = `2 0 obj\n<< /Type /Pages /Kids [${pageObjectIds.map(id => `${id} 0 R`).join(' ')}] /Count ${pageObjectIds.length} >>\nendobj`;

  let pdf = '%PDF-1.4\n';
  const offsets: number[] = [0];
  for (const obj of objects) {
    offsets.push(pdf.length);
    pdf += obj + '\n';
  }
  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= objects.length; i++) {
    pdf += `${offsets[i].toString().padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;

  return new Blob([pdf], { type: 'application/pdf' });
}

/**
 * Determines whether a user role is permitted to download a book's PDF file.
 * Admins and librarians can always download; students can only download when allowPdfDownload is enabled.
 */
export function canDownloadBookPdf(
  book: Pick<Book, 'allowPdfDownload'>,
  role: UserRole | null | undefined
): boolean {
  if (!role) return false;
  if (role === 'admin' || role === 'librarian') return true;
  return Boolean(book.allowPdfDownload);
}

/**
 * Counts how many books exist in each category by category name.
 */
export function getCategoryBookCounts(
  categories: Pick<BookCategory, 'name'>[],
  books: Pick<Book, 'category'>[]
): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const cat of categories) {
    counts[cat.name] = 0;
  }
  for (const book of books) {
    if (book.category) {
      counts[book.category] = (counts[book.category] || 0) + 1;
    }
  }
  return counts;
}

/**
 * Validates whether a student can borrow one or more books in a single issue transaction.
 */
export function canIssueMultipleBooks(
  selectedBooks: Array<{ id: string; availableCopies: number; title: string }>,
  student: { status: 'active' | 'blocked'; name: string },
  studentActiveLoansCount: number,
  studentHasOverdueLoans: boolean,
  maxLoans = MAX_ACTIVE_LOANS_PER_STUDENT
): { allowed: boolean; reason?: string } {
  if (selectedBooks.length === 0) {
    return {
      allowed: false,
      reason: 'Iltimos, kamida bitta kitobni tanlang!',
    };
  }

  if (student.status === 'blocked') {
    return {
      allowed: false,
      reason: `Talaba "${student.name}" ma'muriyat tomonidan bloklangan.`,
    };
  }

  if (studentHasOverdueLoans) {
    return {
      allowed: false,
      reason: `Talabada muddati o'tgan topshirilmagan kitob(lar) mavjud. Avval ularni topshirishi shart.`,
    };
  }

  if (studentActiveLoansCount + selectedBooks.length > maxLoans) {
    const remaining = Math.max(0, maxLoans - studentActiveLoansCount);
    return {
      allowed: false,
      reason: `Talaba jami ko'pi bilan ${maxLoans} ta kitob olishi mumkin. Hozir yana ${remaining} ta kitob berish mumkin.`,
    };
  }

  for (const book of selectedBooks) {
    if (book.availableCopies <= 0) {
      return {
        allowed: false,
        reason: `"${book.title}" kitobining barcha nusxalari band. Kutubxona fondida bo'sh nusxa yo'q.`,
      };
    }
  }

  return { allowed: true };
}

/**
 * Deep-merges partial SiteSettings updates with complete defaults so missing nested keys never break rendering.
 */
export function mergeSiteSettings(
  defaults: SiteSettings,
  incoming?: Partial<SiteSettings> | null
): SiteSettings {
  if (!incoming) return defaults;
  return {
    header: { ...defaults.header, ...(incoming.header || {}) },
    footer: { ...defaults.footer, ...(incoming.footer || {}) },
    banner: { ...defaults.banner, ...(incoming.banner || {}) },
    services: {
      ...defaults.services,
      ...(incoming.services || {}),
      items: Array.isArray(incoming.services?.items)
        ? incoming.services.items
        : defaults.services.items,
    },
    rules: {
      ...defaults.rules,
      ...(incoming.rules || {}),
      items: Array.isArray(incoming.rules?.items)
        ? incoming.rules.items
        : defaults.rules.items,
    },
    contact: { ...defaults.contact, ...(incoming.contact || {}) },
  };
}


