import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateLoanStatus,
  calculateDaysOverdue,
  calculateFine,
  canIssueBook,
  generateStudentId,
  formatUzbekCurrency,
  findSpecialtyByCode,
  mapExcelRowsToStudents,
  buildGeneratedBookPdfBlob,
  canDownloadBookPdf,
  getCategoryBookCounts,
  canIssueMultipleBooks,
  mergeSiteSettings,
  FINE_PER_DAY_UZS
} from './libraryRules';
import { DEFAULT_SITE_SETTINGS } from '../data/initialData';
import type { Book, Specialty } from '../types/library';

test('calculateLoanStatus returns "returned" if returnDate is present', () => {
  const status = calculateLoanStatus('2026-11-01', '2026-11-05', '2026-11-12');
  assert.equal(status, 'returned');
});

test('calculateLoanStatus returns "overdue" if due date has passed without return', () => {
  const status = calculateLoanStatus('2026-11-05', undefined, '2026-11-12');
  assert.equal(status, 'overdue');
});

test('calculateLoanStatus returns "active" if due date is in the future', () => {
  const status = calculateLoanStatus('2026-11-20', undefined, '2026-11-12');
  assert.equal(status, 'active');
});

test('calculateDaysOverdue correctly counts overdue days', () => {
  const days = calculateDaysOverdue('2026-11-05', '2026-11-12');
  assert.equal(days, 7);

  const zeroDays = calculateDaysOverdue('2026-11-20', '2026-11-12');
  assert.equal(zeroDays, 0);
});

test('calculateFine calculates correct penalty according to daily tariff', () => {
  const fine = calculateFine(5);
  assert.equal(fine, 5 * FINE_PER_DAY_UZS);

  const zeroFine = calculateFine(0);
  assert.equal(zeroFine, 0);
});

test('canIssueBook blocks borrowing if availableCopies is 0', () => {
  const result = canIssueBook(
    { availableCopies: 0, title: 'Oliy Matematika' },
    { status: 'active', name: 'Alisher Navoiy' },
    1,
    false
  );
  assert.equal(result.allowed, false);
  assert.match(result.reason || '', /bo'sh nusxa yo'q/);
});

test('canIssueBook blocks borrowing if student is blocked', () => {
  const result = canIssueBook(
    { availableCopies: 5, title: 'Algoritmlar' },
    { status: 'blocked', name: 'Javohir Zokirov' },
    1,
    false
  );
  assert.equal(result.allowed, false);
  assert.match(result.reason || '', /bloklangan/);
});

test('canIssueBook blocks borrowing if student has overdue loans', () => {
  const result = canIssueBook(
    { availableCopies: 5, title: 'Algoritmlar' },
    { status: 'active', name: 'Javohir Zokirov' },
    2,
    true
  );
  assert.equal(result.allowed, false);
  assert.match(result.reason || '', /muddati o'tgan/);
});

test('canIssueBook allows borrowing when book is available and student is in good standing', () => {
  const result = canIssueBook(
    { availableCopies: 3, title: 'Falsafa' },
    { status: 'active', name: 'Madina Karimova' },
    2,
    false
  );
  assert.equal(result.allowed, true);
});

test('generateStudentId generates correctly formatted ID', () => {
  const id1 = generateStudentId(0, 2026);
  assert.equal(id1, 'TAL-2026-001');

  const id12 = generateStudentId(11, 2026);
  assert.equal(id12, 'TAL-2026-012');
});

test('formatUzbekCurrency formats amount correctly', () => {
  const formatted = formatUzbekCurrency(10000);
  assert.match(formatted, /10.*000.*so'm/);
});

const SAMPLE_SPECIALTIES: Specialty[] = [
  {
    id: 'sp-1',
    code: '60610600',
    name: 'Dasturiy injiniring',
    faculty: 'Axborot texnologiyalari va dasturiy injiniring',
  },
  {
    id: 'sp-2',
    code: '60410100',
    name: 'Iqtisodiyot (tarmoqlar bo\'yicha)',
    faculty: 'Iqtisodiyot va moliya',
  },
];

test('findSpecialtyByCode matches specialty ignoring whitespace and case', () => {
  const found = findSpecialtyByCode(SAMPLE_SPECIALTIES, ' 60610600 ');
  assert.equal(found?.name, 'Dasturiy injiniring');
  assert.equal(findSpecialtyByCode(SAMPLE_SPECIALTIES, '99999999'), undefined);
});

test('mapExcelRowsToStudents maps specialty code (shifr) to exact specialty name and faculty', () => {
  const rows = [
    {
      'Ism Familiya': 'Kamoliddin Tursunov',
      'Talaba ID': 'TAL-2026-101',
      "Yo'nalish shifri": '60610600',
      'Kurs': 2,
      'Guruh': '920-25',
      'Telefon': '+998 90 111 22 33',
    },
    {
      'Ism Familiya': 'Malika Tursunova',
      "Yo'nalish shifri": '60410100',
      'Kurs': 1,
      'Guruh': '810-26',
    },
    {
      'Ism Familiya': 'Xato Shifrli Talaba',
      "Yo'nalish shifri": '00000000',
      'Kurs': 1,
      'Guruh': '101-26',
    },
  ];

  const mapped = mapExcelRowsToStudents(rows, SAMPLE_SPECIALTIES, [{ studentId: 'TAL-2024-001' }]);
  assert.equal(mapped.length, 3);

  assert.equal(mapped[0].matchedSpecialty, true);
  assert.equal(mapped[0].specialtyName, 'Dasturiy injiniring');
  assert.equal(mapped[0].faculty, 'Axborot texnologiyalari va dasturiy injiniring');
  assert.equal(mapped[0].error, undefined);

  assert.equal(mapped[1].matchedSpecialty, true);
  assert.equal(mapped[1].specialtyName, 'Iqtisodiyot (tarmoqlar bo\'yicha)');
  assert.equal(mapped[1].faculty, 'Iqtisodiyot va moliya');
  assert.match(mapped[1].studentId, /^TAL-/);

  assert.equal(mapped[2].matchedSpecialty, false);
  assert.match(mapped[2].error || '', /topilmadi/);
});

test('buildGeneratedBookPdfBlob produces a valid PDF header and EOF marker', async () => {
  const mockBook: Book = {
    id: 'b-1',
    title: 'Test Kitob',
    author: 'Prof. Test',
    isbn: '123-456',
    barcode: 'INV-001',
    category: 'Dasturlash va IT',
    faculty: 'AT',
    year: 2026,
    pages: 120,
    totalCopies: 5,
    availableCopies: 5,
    location: { building: 'A', floor: 1, shelf: 'J1', section: 'T1' },
    coverUrl: '',
    description: 'Qisqa tavsif',
    language: 'Uzbek',
    isEbookAvailable: true,
    viewsCount: 0,
    favoritesCount: 0,
    rating: 5,
  };
  const blob = buildGeneratedBookPdfBlob(mockBook);
  assert.equal(blob.type, 'application/pdf');
  const text = await blob.text();
  assert.ok(text.startsWith('%PDF-1.4'));
  assert.ok(text.trim().endsWith('%%EOF'));
});

test('canDownloadBookPdf enforces read-only vs downloadable PDF permissions by role', () => {
  assert.equal(canDownloadBookPdf({ allowPdfDownload: false }, 'student'), false);
  assert.equal(canDownloadBookPdf({ allowPdfDownload: undefined }, 'student'), false);
  assert.equal(canDownloadBookPdf({ allowPdfDownload: true }, 'student'), true);
  assert.equal(canDownloadBookPdf({ allowPdfDownload: false }, 'librarian'), true);
  assert.equal(canDownloadBookPdf({ allowPdfDownload: false }, 'admin'), true);
  assert.equal(canDownloadBookPdf({ allowPdfDownload: true }, null), false);
});

test('getCategoryBookCounts returns accurate book counts per category including empty ones', () => {
  const counts = getCategoryBookCounts(
    [{ name: 'IT' }, { name: 'Matematika' }, { name: 'Huquq' }],
    [
      { category: 'IT' },
      { category: 'IT' },
      { category: 'Matematika' },
    ]
  );
  assert.equal(counts['IT'], 2);
  assert.equal(counts['Matematika'], 1);
  assert.equal(counts['Huquq'], 0);
});

test('canIssueMultipleBooks enforces empty list, overdue, max loan limit, and stock checks', () => {
  const emptyRes = canIssueMultipleBooks([], { status: 'active', name: 'Ali' }, 0, false);
  assert.equal(emptyRes.allowed, false);

  const blockedRes = canIssueMultipleBooks(
    [{ id: 'b1', availableCopies: 2, title: 'Kitob 1' }],
    { status: 'blocked', name: 'Ali' },
    0,
    false
  );
  assert.equal(blockedRes.allowed, false);
  assert.match(blockedRes.reason || '', /bloklangan/);

  const overdueRes = canIssueMultipleBooks(
    [{ id: 'b1', availableCopies: 2, title: 'Kitob 1' }],
    { status: 'active', name: 'Ali' },
    1,
    true
  );
  assert.equal(overdueRes.allowed, false);
  assert.match(overdueRes.reason || '', /muddati o'tgan/);

  const limitRes = canIssueMultipleBooks(
    [
      { id: 'b1', availableCopies: 2, title: 'Kitob 1' },
      { id: 'b2', availableCopies: 2, title: 'Kitob 2' },
      { id: 'b3', availableCopies: 2, title: 'Kitob 3' },
    ],
    { status: 'active', name: 'Ali' },
    3,
    false
  );
  assert.equal(limitRes.allowed, false);
  assert.match(limitRes.reason || '', /2 ta kitob/);

  const stockRes = canIssueMultipleBooks(
    [
      { id: 'b1', availableCopies: 2, title: 'Kitob 1' },
      { id: 'b2', availableCopies: 0, title: 'Kitob 2' },
    ],
    { status: 'active', name: 'Ali' },
    1,
    false
  );
  assert.equal(stockRes.allowed, false);
  assert.match(stockRes.reason || '', /bo'sh nusxa yo'q/);

  const okRes = canIssueMultipleBooks(
    [
      { id: 'b1', availableCopies: 2, title: 'Kitob 1' },
      { id: 'b2', availableCopies: 1, title: 'Kitob 2' },
    ],
    { status: 'active', name: 'Ali' },
    2,
    false
  );
  assert.equal(okRes.allowed, true);
});

test('mergeSiteSettings preserves nested defaults when partial updates are applied', () => {
  const merged = mergeSiteSettings(DEFAULT_SITE_SETTINGS, {
    header: { ...DEFAULT_SITE_SETTINGS.header, brandName: 'Toshkent Axborot Kutubxonasi' },
    banner: { ...DEFAULT_SITE_SETTINGS.banner, backgroundType: 'image', backgroundMediaUrl: '/api/files/img-1' },
  });
  assert.equal(merged.header.brandName, 'Toshkent Axborot Kutubxonasi');
  assert.equal(merged.header.ctaLabel, DEFAULT_SITE_SETTINGS.header.ctaLabel);
  assert.equal(merged.banner.backgroundType, 'image');
  assert.equal(merged.banner.backgroundMediaUrl, '/api/files/img-1');
  assert.equal(merged.services.items.length, DEFAULT_SITE_SETTINGS.services.items.length);
  assert.equal(merged.rules.items.length, DEFAULT_SITE_SETTINGS.rules.items.length);
  assert.equal(merged.contact.emailValue, DEFAULT_SITE_SETTINGS.contact.emailValue);
});

