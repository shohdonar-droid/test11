import type { BookCategory } from '../types/library';
import itImg from '../assets/images/cat_it_programming_1794562872581.jpg';
import scienceImg from '../assets/images/cat_exact_sciences_1794562872980.jpg';
import econImg from '../assets/images/cat_economics_1794562872812.jpg';
import lawImg from '../assets/images/cat_law_1794562873781.jpg';
import humanitiesImg from '../assets/images/cat_humanities_1794562874475.jpg';
import litImg from '../assets/images/cat_literature_1794562874330.jpg';
import langImg from '../assets/images/cat_languages_1794562874309.jpg';

const CATEGORY_IMAGE_BY_NAME: Record<string, string> = {
  'Dasturlash va IT': itImg,
  'Aniq fanlar (Matematika, Fizika)': scienceImg,
  'Iqtisodiyot va Biznes': econImg,
  'Huquqshunoslik': lawImg,
  'Gumanitar va Falsafa': humanitiesImg,
  'Badiiy adabiyot': litImg,
  "Xorijiy tillar va Lug'atlar": langImg,
};

const FALLBACK_IMAGES = [itImg, scienceImg, econImg, lawImg, humanitiesImg, litImg, langImg];

/**
 * Returns the custom uploaded thumbnail or a matched curated illustration for a category.
 */
export function getCategoryImage(category: Pick<BookCategory, 'name' | 'imageUrl'>, index = 0): string {
  if (category.imageUrl && category.imageUrl.trim()) {
    return category.imageUrl;
  }
  const exact = CATEGORY_IMAGE_BY_NAME[category.name];
  if (exact) return exact;

  const lower = category.name.toLowerCase();
  if (lower.includes('it') || lower.includes('dastur') || lower.includes('kiber') || lower.includes('kompyuter')) {
    return itImg;
  }
  if (lower.includes('matemat') || lower.includes('fizik') || lower.includes('kimyo') || lower.includes('fan')) {
    return scienceImg;
  }
  if (lower.includes('iqtisod') || lower.includes('biznes') || lower.includes('moliya') || lower.includes('bank')) {
    return econImg;
  }
  if (lower.includes('huquq') || lower.includes('yuris') || lower.includes('qonun')) {
    return lawImg;
  }
  if (lower.includes('falsaf') || lower.includes('tarix') || lower.includes('gumanitar') || lower.includes('psix')) {
    return humanitiesImg;
  }
  if (lower.includes('badiiy') || lower.includes('adabiyot') || lower.includes('roman') || lower.includes('sher')) {
    return litImg;
  }
  if (lower.includes('til') || lower.includes('lug') || lower.includes('ingliz')) {
    return langImg;
  }
  return FALLBACK_IMAGES[index % FALLBACK_IMAGES.length];
}
