import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import type {
  Book,
  Student,
  Librarian,
  Loan,
  Reservation,
  ActivityLog,
  UserRole,
  AdminAccount,
  Specialty,
  BookCategory,
  Faculty,
  SiteSettings,
} from '../types/library';
import { DEFAULT_SITE_SETTINGS } from '../data/initialData';
import { mergeSiteSettings } from '../utils/libraryRules';

export interface CurrentUser {
  role: UserRole;
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatarUrl: string;
  studentData?: Student;
  librarianData?: Librarian;
  adminData?: AdminAccount;
}

interface ActionResult {
  success: boolean;
  message: string;
  role?: UserRole;
}

interface LibraryContextType {
  books: Book[];
  students: Student[];
  studentsCount: number;
  librarians: Librarian[];
  adminAccount: AdminAccount | null;
  faculties: Faculty[];
  specialties: Specialty[];
  categories: BookCategory[];
  loans: Loan[];
  reservations: Reservation[];
  logs: ActivityLog[];
  siteSettings: SiteSettings;
  activeRole: UserRole | null;
  currentUser: CurrentUser | null;
  authToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  currentView: 'landing' | 'login' | 'dashboard';
  showProfileModal: boolean;
  toast: { message: string; type: 'success' | 'error' | 'info' } | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  setCurrentView: (view: 'landing' | 'login' | 'dashboard') => void;
  setShowProfileModal: (show: boolean) => void;
  refreshState: (overrideToken?: string | null) => Promise<void>;
  login: (loginIdOrEmail: string, password: string) => Promise<ActionResult>;
  logout: () => void;
  // Faculties CRUD (Admin)
  createFaculty: (data: { name: string; shortName?: string; dean?: string }) => Promise<ActionResult>;
  updateFaculty: (id: string, data: { name: string; shortName?: string; dean?: string }) => Promise<ActionResult>;
  deleteFaculty: (id: string) => Promise<ActionResult>;
  // Specialties CRUD (Admin)
  createSpecialty: (data: Omit<Specialty, 'id'>) => Promise<ActionResult>;
  updateSpecialty: (id: string, data: Omit<Specialty, 'id'>) => Promise<ActionResult>;
  deleteSpecialty: (id: string) => Promise<ActionResult>;
  // Categories CRUD (Admin / Librarian)
  createCategory: (data: { name: string; description?: string; imageUrl?: string }) => Promise<ActionResult>;
  updateCategory: (id: string, data: { name: string; description?: string; imageUrl?: string }) => Promise<ActionResult>;
  deleteCategory: (id: string) => Promise<ActionResult>;
  // Students CRUD + Import (Admin)
  createStudent: (data: Omit<Student, 'id' | 'registeredAt'> & { password?: string }) => Promise<ActionResult>;
  bulkCreateStudents: (items: Array<Omit<Student, 'id' | 'registeredAt'>>) => Promise<number>;
  updateStudent: (id: string, updates: Partial<Student>) => Promise<ActionResult>;
  toggleStudentStatus: (id: string) => Promise<void>;
  deleteStudent: (id: string) => Promise<void>;
  // Librarians CRUD (Admin)
  createLibrarian: (data: Omit<Librarian, 'id' | 'avatarUrl'> & { password?: string }) => Promise<ActionResult>;
  updateLibrarian: (id: string, updates: Partial<Librarian>) => Promise<ActionResult>;
  deleteLibrarian: (id: string) => Promise<ActionResult>;
  // Books CRUD & Engagement
  uploadServerFile: (dataUrl: string, fileName: string, mimeType: string) => Promise<{ id: string; url: string; fileName: string; size: number } | null>;
  addBook: (data: Omit<Book, 'id' | 'viewsCount' | 'favoritesCount' | 'favoritedBy'>) => Promise<ActionResult>;
  updateBook: (id: string, updates: Partial<Book>) => Promise<ActionResult>;
  deleteBook: (id: string) => Promise<ActionResult>;
  incrementBookViews: (bookId: string) => Promise<void>;
  toggleFavoriteBook: (bookId: string) => Promise<void>;
  // Loans & Reservations
  issueBook: (params: { bookId: string; studentId: string; days: number; notes?: string }) => Promise<ActionResult>;
  issueMultipleBooks: (params: { bookIds: string[]; studentId: string; days: number; notes?: string }) => Promise<ActionResult>;
  returnBook: (params: { loanId: string; condition: 'a\'lo' | 'yaxshi' | 'zararlangan' | 'yo\'qolgan'; notes?: string }) => Promise<ActionResult>;
  prolongLoan: (loanId: string, extraDays?: number) => Promise<ActionResult>;
  reserveBook: (bookId: string, studentId: string) => Promise<ActionResult>;
  cancelReservation: (reservationId: string) => Promise<void>;
  // Site Settings (Admin)
  updateSiteSettings: (updates: Partial<SiteSettings>) => Promise<ActionResult>;
  // Profile
  updateProfile: (updates: { name?: string; email?: string; phone?: string; avatarUrl?: string }) => Promise<ActionResult>;
  changePassword: (oldPass: string, newPass: string) => Promise<ActionResult>;
}

const LibraryContext = createContext<LibraryContextType | undefined>(undefined);

const TOKEN_KEY = 'unilib_auth_token_v1';

export const LibraryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [books, setBooks] = useState<Book[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [studentsCount, setStudentsCount] = useState<number>(0);
  const [librarians, setLibrarians] = useState<Librarian[]>([]);
  const [adminAccount, setAdminAccount] = useState<AdminAccount | null>(null);
  const [faculties, setFaculties] = useState<Faculty[]>([]);
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [categories, setCategories] = useState<BookCategory[]>([]);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(DEFAULT_SITE_SETTINGS);

  const [authToken, setAuthToken] = useState<string | null>(() => {
    try {
      return sessionStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  });
  const [currentUser, setCurrentUser] = useState<CurrentUser | null>(null);
  const [currentView, setCurrentView] = useState<'landing' | 'login' | 'dashboard'>('landing');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const tokenRef = useRef<string | null>(authToken);
  tokenRef.current = authToken;

  const toastTimerRef = useRef<number | null>(null);
  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    if (toastTimerRef.current) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToast(null);
    }, 4000);
  }, []);

  const apiFetch = useCallback(async (url: string, options: RequestInit = {}, explicitToken?: string | null) => {
    const token = explicitToken !== undefined ? explicitToken : tokenRef.current;
    const headers: Record<string, string> = {
      ...(options.headers as Record<string, string> | undefined),
    };
    if (options.body && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const resp = await fetch(url, { ...options, headers });
    const text = await resp.text();
    let json: Record<string, unknown> = {};
    try {
      json = text ? JSON.parse(text) : {};
    } catch {
      json = {};
    }
    if (!resp.ok) {
      throw new Error((json.error as string) || 'Server bilan bog\'lanishda xatolik yuz berdi');
    }
    return json;
  }, []);

  const refreshState = useCallback(async (overrideToken?: string | null) => {
    const data = await apiFetch('/api/state', {}, overrideToken);
    setBooks((data.books as Book[]) || []);
    setFaculties((data.faculties as Faculty[]) || []);
    setSpecialties((data.specialties as Specialty[]) || []);
    setCategories((data.categories as BookCategory[]) || []);
    setStudents((data.students as Student[]) || []);
    setLibrarians((data.librarians as Librarian[]) || []);
    setAdminAccount((data.adminAccount as AdminAccount | null) || null);
    setLoans((data.loans as Loan[]) || []);
    setReservations((data.reservations as Reservation[]) || []);
    setLogs((data.logs as ActivityLog[]) || []);
    setSiteSettings(
      mergeSiteSettings(DEFAULT_SITE_SETTINGS, (data.siteSettings as Partial<SiteSettings>) || null)
    );
    const stats = data.stats as { studentsCount?: number } | undefined;
    setStudentsCount(stats?.studentsCount ?? ((data.students as Student[]) || []).length);
  }, [apiFetch]);

  // Keep currentUser fresh when underlying state changes
  useEffect(() => {
    if (!currentUser) return;
    if (currentUser.role === 'admin' && adminAccount) {
      setCurrentUser({
        role: 'admin',
        id: adminAccount.id,
        name: adminAccount.name,
        email: adminAccount.email,
        phone: adminAccount.phone,
        avatarUrl: adminAccount.avatarUrl,
        adminData: adminAccount,
      });
    } else if (currentUser.role === 'librarian') {
      const lib = librarians.find((l) => l.id === currentUser.id);
      if (lib) {
        setCurrentUser({
          role: 'librarian',
          id: lib.id,
          name: lib.name,
          email: lib.email,
          phone: lib.phone,
          avatarUrl: lib.avatarUrl,
          librarianData: lib,
        });
      }
    } else if (currentUser.role === 'student') {
      const stu = students.find((s) => s.id === currentUser.id);
      if (stu) {
        setCurrentUser({
          role: 'student',
          id: stu.id,
          name: stu.name,
          email: stu.email,
          phone: stu.phone,
          avatarUrl: stu.avatarUrl,
          studentData: stu,
        });
      }
    }
  }, [adminAccount, librarians, students]);

  // Initial session restore + state load
  useEffect(() => {
    let active = true;
    async function bootstrap() {
      setIsLoading(true);
      const savedToken = tokenRef.current;
      let validToken: string | null = null;
      if (savedToken) {
        try {
          const meResp = await apiFetch('/api/auth/me', {}, savedToken);
          if (active && meResp.user) {
            setCurrentUser(meResp.user as CurrentUser);
            setCurrentView('dashboard');
            validToken = savedToken;
          }
        } catch {
          try {
            sessionStorage.removeItem(TOKEN_KEY);
          } catch {
            // ignore
          }
          if (active) {
            setAuthToken(null);
            setCurrentUser(null);
            setCurrentView('landing');
          }
        }
      }
      try {
        await refreshState(validToken);
      } catch {
        // ignore transient boot error
      } finally {
        if (active) setIsLoading(false);
      }
    }
    bootstrap();
    return () => {
      active = false;
    };
  }, [apiFetch, refreshState]);

  // Real-time WebSocket subscription for automatic updates across all clients
  useEffect(() => {
    let ws: WebSocket | null = null;
    let reconnectTimer: number | null = null;
    let closedByCleanup = false;
    let retryMs = 1000;

    const connect = () => {
      if (closedByCleanup) return;
      const wsProto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${wsProto}//${window.location.host}/ws`;
      try {
        ws = new WebSocket(wsUrl);
        ws.onopen = () => {
          retryMs = 1000;
        };
        ws.onmessage = (evt) => {
          try {
            const msg = JSON.parse(evt.data);
            if (msg?.type === 'STATE_UPDATED') {
              refreshState().catch(() => {});
            }
          } catch {
            // ignore malformed message
          }
        };
        ws.onclose = () => {
          if (closedByCleanup) return;
          reconnectTimer = window.setTimeout(() => {
            retryMs = Math.min(retryMs * 1.5, 10000);
            connect();
          }, retryMs);
        };
        ws.onerror = () => {
          ws?.close();
        };
      } catch {
        // retry
      }
    };

    connect();

    const syncWhenVisible = () => {
      if (document.visibilityState === 'visible') {
        refreshState().catch(() => {});
      }
    };

    const pollTimer = window.setInterval(syncWhenVisible, 10000);
    window.addEventListener('focus', syncWhenVisible);
    document.addEventListener('visibilitychange', syncWhenVisible);

    return () => {
      closedByCleanup = true;
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      window.clearInterval(pollTimer);
      window.removeEventListener('focus', syncWhenVisible);
      document.removeEventListener('visibilitychange', syncWhenVisible);
      ws?.close();
    };
  }, [refreshState]);

  const login = async (loginIdOrEmail: string, password: string): Promise<ActionResult> => {
    try {
      const data = await apiFetch('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ login: loginIdOrEmail, password }),
      }, null);

      const token = data.token as string;
      const user = data.user as CurrentUser;
      try {
        sessionStorage.setItem(TOKEN_KEY, token);
      } catch {
        // ignore
      }
      tokenRef.current = token;
      setAuthToken(token);
      setCurrentUser(user);
      await refreshState(token);
      setCurrentView('dashboard');

      const roleTitle =
        user.role === 'admin'
          ? 'Administrator paneli ochildi.'
          : user.role === 'librarian'
          ? 'Kutubxonachi paneli ochildi.'
          : 'Talaba kabinetingiz ochildi.';
      showToast(`Xush kelibsiz, ${user.name}! ${roleTitle}`, 'success');
      return { success: true, message: 'Muvaffaqiyatli kirildi', role: user.role };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Login yoki parol noto\'g\'ri!';
      return { success: false, message };
    }
  };

  const logout = () => {
    try {
      sessionStorage.removeItem(TOKEN_KEY);
    } catch {
      // ignore
    }
    tokenRef.current = null;
    setAuthToken(null);
    setCurrentUser(null);
    setShowProfileModal(false);
    setCurrentView('landing');
    refreshState(null).catch(() => {});
    showToast('Tizimdan muvaffaqiyatli chiqildi', 'info');
  };

  // Faculties
  const createFaculty = async (data: { name: string; shortName?: string; dean?: string }): Promise<ActionResult> => {
    try {
      await apiFetch('/api/faculties', { method: 'POST', body: JSON.stringify(data) });
      await refreshState();
      showToast(`"${data.name}" fakulteti yaratildi!`, 'success');
      return { success: true, message: 'Yaratildi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik yuz berdi';
      return { success: false, message };
    }
  };

  const updateFaculty = async (id: string, data: { name: string; shortName?: string; dean?: string }): Promise<ActionResult> => {
    try {
      await apiFetch(`/api/faculties/${id}`, { method: 'PATCH', body: JSON.stringify(data) });
      await refreshState();
      showToast('Fakultet ma\'lumotlari yangilandi!', 'success');
      return { success: true, message: 'Yangilandi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik yuz berdi';
      return { success: false, message };
    }
  };

  const deleteFaculty = async (id: string): Promise<ActionResult> => {
    try {
      await apiFetch(`/api/faculties/${id}`, { method: 'DELETE' });
      await refreshState();
      showToast('Fakultet o\'chirildi', 'info');
      return { success: true, message: 'O\'chirildi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'O\'chirib bo\'lmadi';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  // Specialties
  const createSpecialty = async (data: Omit<Specialty, 'id'>): Promise<ActionResult> => {
    try {
      await apiFetch('/api/specialties', { method: 'POST', body: JSON.stringify(data) });
      await refreshState();
      showToast(`"${data.code} — ${data.name}" yo'nalishi yaratildi!`, 'success');
      return { success: true, message: 'Yaratildi' };
    } catch (err) {
      return { success: false, message: err instanceof Error ? err.message : 'Xatolik' };
    }
  };

  const updateSpecialty = async (id: string, data: Omit<Specialty, 'id'>): Promise<ActionResult> => {
    try {
      await apiFetch(`/api/specialties/${id}`, { method: 'PATCH', body: JSON.stringify(data) });
      await refreshState();
      showToast('Yo\'nalish yangilandi!', 'success');
      return { success: true, message: 'Yangilandi' };
    } catch (err) {
      return { success: false, message: err instanceof Error ? err.message : 'Xatolik' };
    }
  };

  const deleteSpecialty = async (id: string): Promise<ActionResult> => {
    try {
      await apiFetch(`/api/specialties/${id}`, { method: 'DELETE' });
      await refreshState();
      showToast('Yo\'nalish o\'chirildi', 'info');
      return { success: true, message: 'O\'chirildi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  // Categories
  const createCategory = async (data: { name: string; description?: string; imageUrl?: string }): Promise<ActionResult> => {
    try {
      await apiFetch('/api/categories', { method: 'POST', body: JSON.stringify(data) });
      await refreshState();
      showToast(`"${data.name}" kategoriyasi yaratildi!`, 'success');
      return { success: true, message: 'Yaratildi' };
    } catch (err) {
      return { success: false, message: err instanceof Error ? err.message : 'Xatolik' };
    }
  };

  const updateCategory = async (id: string, data: { name: string; description?: string; imageUrl?: string }): Promise<ActionResult> => {
    try {
      await apiFetch(`/api/categories/${id}`, { method: 'PATCH', body: JSON.stringify(data) });
      await refreshState();
      showToast('Kategoriya yangilandi!', 'success');
      return { success: true, message: 'Yangilandi' };
    } catch (err) {
      return { success: false, message: err instanceof Error ? err.message : 'Xatolik' };
    }
  };

  const deleteCategory = async (id: string): Promise<ActionResult> => {
    try {
      await apiFetch(`/api/categories/${id}`, { method: 'DELETE' });
      await refreshState();
      showToast('Kategoriya o\'chirildi', 'info');
      return { success: true, message: 'O\'chirildi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  // Students
  const createStudent = async (data: Omit<Student, 'id' | 'registeredAt'> & { password?: string }): Promise<ActionResult> => {
    try {
      const stu = await apiFetch('/api/students', { method: 'POST', body: JSON.stringify(data) });
      await refreshState();
      showToast(`Talaba ${(stu as unknown as Student).name} muvaffaqiyatli ro'yxatga olindi!`, 'success');
      return { success: true, message: 'Yaratildi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  const bulkCreateStudents = async (items: Array<Omit<Student, 'id' | 'registeredAt'>>): Promise<number> => {
    try {
      const res = await apiFetch('/api/students/bulk', { method: 'POST', body: JSON.stringify({ items }) });
      await refreshState();
      const count = Number(res.count || 0);
      showToast(`${count} nafar talaba Exceldan muvaffaqiyatli yaratildi!`, 'success');
      return count;
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Import xatoligi', 'error');
      return 0;
    }
  };

  const updateStudent = async (id: string, updates: Partial<Student>): Promise<ActionResult> => {
    try {
      await apiFetch(`/api/students/${id}`, { method: 'PATCH', body: JSON.stringify(updates) });
      await refreshState();
      showToast('Talaba ma\'lumotlari yangilandi', 'success');
      return { success: true, message: 'Yangilandi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  const toggleStudentStatus = async (id: string) => {
    try {
      const res = await apiFetch(`/api/students/${id}/status`, { method: 'PATCH' });
      await refreshState();
      showToast(`Talaba statusi: ${res.status === 'active' ? 'Faollashtirildi' : 'Bloklandi'}`, 'info');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Xatolik', 'error');
    }
  };

  const deleteStudent = async (id: string) => {
    try {
      await apiFetch(`/api/students/${id}`, { method: 'DELETE' });
      await refreshState();
      showToast('Talaba tizimdan o\'chirildi', 'info');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'O\'chirib bo\'lmadi', 'error');
    }
  };

  // Librarians
  const createLibrarian = async (data: Omit<Librarian, 'id' | 'avatarUrl'> & { password?: string }): Promise<ActionResult> => {
    try {
      await apiFetch('/api/librarians', { method: 'POST', body: JSON.stringify(data) });
      await refreshState();
      showToast(`Kutubxonachi ${data.name} qo'shildi!`, 'success');
      return { success: true, message: 'Yaratildi' };
    } catch (err) {
      return { success: false, message: err instanceof Error ? err.message : 'Xatolik' };
    }
  };

  const updateLibrarian = async (id: string, updates: Partial<Librarian>): Promise<ActionResult> => {
    try {
      await apiFetch(`/api/librarians/${id}`, { method: 'PATCH', body: JSON.stringify(updates) });
      await refreshState();
      showToast('Kutubxonachi ma\'lumotlari yangilandi', 'success');
      return { success: true, message: 'Yangilandi' };
    } catch (err) {
      return { success: false, message: err instanceof Error ? err.message : 'Xatolik' };
    }
  };

  const deleteLibrarian = async (id: string): Promise<ActionResult> => {
    try {
      await apiFetch(`/api/librarians/${id}`, { method: 'DELETE' });
      await refreshState();
      showToast('Kutubxonachi o\'chirildi', 'info');
      return { success: true, message: 'O\'chirildi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  // Files & Books
  const uploadServerFile = async (dataUrl: string, fileName: string, mimeType: string) => {
    try {
      const res = await apiFetch('/api/files', {
        method: 'POST',
        body: JSON.stringify({ dataUrl, fileName, mimeType }),
      });
      return {
        id: res.id as string,
        url: res.url as string,
        fileName: res.fileName as string,
        size: res.size as number,
      };
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Fayl yuklashda xatolik', 'error');
      return null;
    }
  };

  const addBook = async (data: Omit<Book, 'id' | 'viewsCount' | 'favoritesCount' | 'favoritedBy'>): Promise<ActionResult> => {
    try {
      await apiFetch('/api/books', { method: 'POST', body: JSON.stringify(data) });
      await refreshState();
      showToast(`"${data.title}" kitobi fondga qo'shildi!`, 'success');
      return { success: true, message: 'Kitob qo\'shildi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  const updateBook = async (id: string, updates: Partial<Book>): Promise<ActionResult> => {
    try {
      await apiFetch(`/api/books/${id}`, { method: 'PATCH', body: JSON.stringify(updates) });
      await refreshState();
      showToast('Kitob ma\'lumotlari yangilandi', 'success');
      return { success: true, message: 'Yangilandi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  const deleteBook = async (id: string): Promise<ActionResult> => {
    try {
      await apiFetch(`/api/books/${id}`, { method: 'DELETE' });
      await refreshState();
      showToast('Kitob fonddan o\'chirildi', 'info');
      return { success: true, message: 'O\'chirildi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'O\'chirib bo\'lmadi';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  const incrementBookViews = useCallback(async (bookId: string) => {
    try {
      const res = await apiFetch(`/api/books/${bookId}/view`, { method: 'POST' });
      const viewsCount = Number(res.viewsCount);
      if (!isNaN(viewsCount)) {
        setBooks((prev) => prev.map((b) => (b.id === bookId ? { ...b, viewsCount } : b)));
      }
    } catch {
      // ignore
    }
  }, [apiFetch]);

  const toggleFavoriteBook = async (bookId: string) => {
    if (!currentUser) {
      showToast('Sevimli kitoblarga saqlash uchun profilingizga kiring!', 'info');
      setCurrentView('login');
      return;
    }
    try {
      await apiFetch(`/api/books/${bookId}/favorite`, { method: 'POST' });
      await refreshState();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Xatolik', 'error');
    }
  };

  // Loans & Reservations
  const issueBook = async (params: { bookId: string; studentId: string; days: number; notes?: string }): Promise<ActionResult> => {
    try {
      const loan = (await apiFetch('/api/loans/issue', {
        method: 'POST',
        body: JSON.stringify(params),
      })) as unknown as Loan;
      await refreshState();
      showToast(`Kitob muvaffaqiyatli ijaraga berildi! Muddat: ${loan.dueDate}`, 'success');
      return { success: true, message: 'Muvaffaqiyatli berildi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Kitob berish rad etildi';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  const issueMultipleBooks = async (params: {
    bookIds: string[];
    studentId: string;
    days: number;
    notes?: string;
  }): Promise<ActionResult> => {
    try {
      const resp = (await apiFetch('/api/loans/issue', {
        method: 'POST',
        body: JSON.stringify(params),
      })) as { loans?: Loan[]; dueDate?: string; loan?: Loan };
      await refreshState();
      const count = Array.isArray(resp.loans) ? resp.loans.length : params.bookIds.length;
      const dueDate = resp.loan?.dueDate || resp.dueDate || '';
      showToast(
        `${count} ta kitob muvaffaqiyatli ijaraga berildi!${dueDate ? ` Muddat: ${dueDate}` : ''}`,
        'success'
      );
      return { success: true, message: 'Muvaffaqiyatli berildi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Kitob berish rad etildi';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  const returnBook = async (params: { loanId: string; condition: 'a\'lo' | 'yaxshi' | 'zararlangan' | 'yo\'qolgan'; notes?: string }): Promise<ActionResult> => {
    try {
      await apiFetch(`/api/loans/${params.loanId}/return`, {
        method: 'POST',
        body: JSON.stringify({ condition: params.condition, notes: params.notes }),
      });
      await refreshState();
      showToast(`Kitob qabul qilindi! Holati: ${params.condition}`, 'success');
      return { success: true, message: 'Kitob qabul qilindi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  const prolongLoan = async (loanId: string, extraDays = 7): Promise<ActionResult> => {
    try {
      const loan = (await apiFetch(`/api/loans/${loanId}/prolong`, {
        method: 'POST',
        body: JSON.stringify({ extraDays }),
      })) as unknown as Loan;
      await refreshState();
      showToast(`Topshirish muddati yana ${extraDays} kunga (${loan.dueDate} gacha) uzaytirildi`, 'success');
      return { success: true, message: 'Muddat uzaytirildi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  const reserveBook = async (bookId: string, studentId: string): Promise<ActionResult> => {
    try {
      await apiFetch('/api/reservations', {
        method: 'POST',
        body: JSON.stringify({ bookId, studentId }),
      });
      await refreshState();
      showToast('Kitob 3 kunga band qilindi!', 'success');
      return { success: true, message: 'Band qilindi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  const cancelReservation = async (reservationId: string) => {
    try {
      await apiFetch(`/api/reservations/${reservationId}`, { method: 'DELETE' });
      await refreshState();
      showToast('Buyurtma bekor qilindi', 'info');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Xatolik', 'error');
    }
  };

  const updateSiteSettings = async (updates: Partial<SiteSettings>): Promise<ActionResult> => {
    try {
      const updated = (await apiFetch('/api/site-settings', {
        method: 'PATCH',
        body: JSON.stringify(updates),
      })) as unknown as SiteSettings;
      setSiteSettings(mergeSiteSettings(DEFAULT_SITE_SETTINGS, updated));
      await refreshState();
      showToast('Sayt sozlamalari muvaffaqiyatli saqlandi!', 'success');
      return { success: true, message: 'Sozlamalar saqlandi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Saqlashda xatolik yuz berdi';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  const updateProfile = async (updates: { name?: string; email?: string; phone?: string; avatarUrl?: string }): Promise<ActionResult> => {
    try {
      await apiFetch('/api/profile', { method: 'PATCH', body: JSON.stringify(updates) });
      await refreshState();
      setCurrentUser((prev) => (prev ? { ...prev, ...updates } : prev));
      showToast('Profil ma\'lumotlari muvaffaqiyatli saqlandi!', 'success');
      return { success: true, message: 'Saqlandi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik';
      showToast(message, 'error');
      return { success: false, message };
    }
  };

  const changePassword = async (oldPass: string, newPass: string): Promise<ActionResult> => {
    try {
      await apiFetch('/api/profile/password', {
        method: 'POST',
        body: JSON.stringify({ oldPass, newPass }),
      });
      showToast('Parol muvaffaqiyatli o\'zgartirildi!', 'success');
      return { success: true, message: 'Parol muvaffaqiyatli yangilandi' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Xatolik';
      return { success: false, message };
    }
  };

  return (
    <LibraryContext.Provider
      value={{
        books,
        students,
        studentsCount,
        librarians,
        adminAccount,
        faculties,
        specialties,
        categories,
        loans,
        reservations,
        logs,
        siteSettings,
        activeRole: currentUser?.role || null,
        currentUser,
        authToken,
        isAuthenticated: Boolean(currentUser && authToken),
        isLoading,
        currentView,
        showProfileModal,
        toast,
        showToast,
        setCurrentView,
        setShowProfileModal,
        refreshState,
        login,
        logout,
        createFaculty,
        updateFaculty,
        deleteFaculty,
        createSpecialty,
        updateSpecialty,
        deleteSpecialty,
        createCategory,
        updateCategory,
        deleteCategory,
        createStudent,
        bulkCreateStudents,
        updateStudent,
        toggleStudentStatus,
        deleteStudent,
        createLibrarian,
        updateLibrarian,
        deleteLibrarian,
        uploadServerFile,
        addBook,
        updateBook,
        deleteBook,
        incrementBookViews,
        toggleFavoriteBook,
        issueBook,
        issueMultipleBooks,
        returnBook,
        prolongLoan,
        reserveBook,
        cancelReservation,
        updateSiteSettings,
        updateProfile,
        changePassword,
      }}
    >
      {children}
    </LibraryContext.Provider>
  );
};

export const useLibrary = () => {
  const context = useContext(LibraryContext);
  if (!context) {
    throw new Error('useLibrary must be used within a LibraryProvider');
  }
  return context;
};
